<template>
  <div class="test">
    <h1>vue3.0 初体验</h1>
    <p>少年的头发可还好,??? 哈哈哈哈哈</p>
    <h1>test count: {{ count }}</h1>
    <div>count*2={{ doubleCount }}</div>
    <div>state from vuex {{ a }}</div>
    <button @click="add">add</button>
    <button @click="update">update a</button>
    <button @click="toOrderNum('19980')">trans num</button>
  </div>
  <div class="chartNum">
    <h3 class="box-item">
      <li
        :class="{ 'number-item': !isNaN(item), 'mark-item': isNaN(item) }"
        v-for="(item, index) in orderNum"
        :key="index"
      >
        <span v-if="!isNaN(item)">
          <i ref="numberItem">0123456789</i>
        </span>
        <span class="comma" v-else>{{ item }}</span>
      </li>
    </h3>
  </div>
</template>

<script>
import { ref, computed, watch, getCurrentInstance } from "vue";
export default {
  setup() {
    const count = ref(0);
    const add = () => {
      count.value++;
    };
    watch(
      () => count.value,
      (val) => {
        console.log(`count is ${val}`);
      }
    );
    const doubleCount = computed(() => count.value * 2);
    const { ctx } = getCurrentInstance();
    console.log(ctx.$router.currentRoute.value);
    const a = computed(() => ctx.$store.state.test.a);
    const update = () => {
      ctx.$store.commit("setTestA", count);
    };
    const orderNum = ref(["0", "0", ",", "0", "0", "0", ",", "0", "0", "0"]);
    //设置文字滚动
    const setNumberTransform = () => {
      const numberItems = ctx.$refs.numberItem;
      const numberArr = ctx.orderNum.filter((item) => !isNaN(item));
      alert(numberItems.length)
      for (let index = 0; index < ctx.$refs.numberItem.length; index++) {
        const elem = numberItems[index];
        elem.style.transform = `translate(-50%,-${numberArr[index] * 10}%)`;
      }
    };
    //处理总订单数字
    const toOrderNum = (num) => {
      num = num.toString();
      //把订单变成字符串
      if (num.length < 8) {
        num = "0" + num;
        ctx.toOrderNum(num);
        ctx.setNumberTransform()
      } else if (num.length === 8) {
        num = num.slice(0, 2) + "," + num.slice(2, 5) + "," + num.slice(5, 8);
        ctx.toOrderNum = num.split("");
      } else {
        alert("订单总量数字过大,显示异常,请联系客服");
      }
    };
    return {
      count,
      add,
      doubleCount,
      a,
      update,
      orderNum,
      toOrderNum,
      setNumberTransform,
    };
  },
};
</script>
<style lang="scss" scoped>
.test {
  color: red;
}
/*订单总量滚动数字设置*/
.box-item {
  position: relative;
  height: 100px;
  font-size: 54px;
  line-height: 41px;
  text-align: center;
  list-style: none;
  color: #2d7cff;
  writing-mode: vertical-lr;
  text-orientation: upright;
  /*文字禁止编辑*/
  -moz-user-select: none; /*火狐*/
  -webkit-user-select: none; /*webkit浏览器*/
  -ms-user-select: none; /*IE10*/
  -khtml-user-select: none; /*早期浏览器*/
  user-select: none;
  /* overflow: hidden; */
}
/* 默认逗号设置 */
.mark-item {
  width: 10px;
  height: 100px;
  margin-right: 5px;
  line-height: 10px;
  font-size: 48px;
  position: relative;
  & > span {
    position: absolute;
    width: 100%;
    bottom: 0;
    writing-mode: vertical-rl;
    text-orientation: upright;
  }
}
/*滚动数字设置*/
.number-item {
  width: 41px;
  height: 75px;
  background: #ccc;
  list-style: none;
  margin-right: 5px;
  background: rgba(250, 250, 250, 1);
  border-radius: 4px;
  border: 1px solid rgba(221, 221, 221, 1);
  & > span {
    position: relative;
    display: inline-block;
    margin-right: 10px;
    width: 100%;
    height: 100%;
    writing-mode: vertical-rl;
    text-orientation: upright;
    overflow: hidden;
    & > i {
      font-style: normal;
      position: absolute;
      top: 11px;
      left: 50%;
      transform: translate(-50%, 0);
      transition: transform 1s ease-in-out;
      letter-spacing: 10px;
    }
  }
}
.number-item:last-child {
  margin-right: 0;
}
</style>