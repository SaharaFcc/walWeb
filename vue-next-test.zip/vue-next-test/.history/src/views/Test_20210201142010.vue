<template>
  <div class="test">
      <h1>vue3.0 初体验</h1>
      <p>少年的头发可还好,??? 哈哈哈哈哈</p>
  </div>
</template>

<script>
export default {

}
</script>
<style lang="scss" scoped>
.test{
    color: red;
}
</style>