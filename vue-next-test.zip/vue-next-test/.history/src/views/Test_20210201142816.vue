<template>
  <div class="test">
      <h1>vue3.0 初体验</h1>
      <p>少年的头发可还好,??? 哈哈哈哈哈</p>
      <h1>test count: {{count}}</h1>
      <div>count*2={{doubleCount}}</div>
      <button @click="add">add</button>
  </div>
</template>

<script>
import { ref,computed,watch } from 'vue'
export default {
  setup(){
    const count = ref(0)
    const add = ()=> {
      count.value++;
    }
    watch(()=> count.value,val=>{
      console.log(`count is ${val}`)
    })
    const doubleCount = computed(()=> count.value*2)
    return {
      count,
      add,
      doubleCount
    }
  }
}
</script>
<style lang="scss" scoped>
.test{
    color: red;
}
</style>