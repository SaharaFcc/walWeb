<template>
  <div class="test">
    <h1>vue3.0 初体验</h1>
    <p>少年的头发可还好,??? 哈哈哈哈哈</p>
    <h1>test count: {{ count }}</h1>
    <div>count*2={{ doubleCount }}</div>
    <div>state from vuex {{ a }}</div>
    <button @click="add">add</button>
    <button @click="update">update a</button>
  </div>
  <div>
    <button class="head" @click="numFun(0, 5000)">点击金额变动</button>
    <div>{{ amount }}</div>
  </div>
</template>

<script>
import { ref, computed, watch, getCurrentInstance } from "vue";
export default {
  setup() {
    const count = ref(0);
    const add = () => {
      count.value++;
    };
    watch(
      () => count.value,
      (val) => {
        console.log(`count is ${val}`);
      }
    );
    const doubleCount = computed(() => count.value * 2);
    const { ctx } = getCurrentInstance();
    console.log(ctx.$router.currentRoute.value);
    const a = computed(() => ctx.$store.state.test.a);
    const update = () => {
      ctx.$store.commit("setTestA", count);
    };
    const amount = ref(0);
    //金额变动动画
    const numFun = async (startNum, maxNum) => {
      let numText = startNum;
      let golb; // 为了清除requestAnimationFrame
      await ctx.numSlideFun(numText, maxNum, golb);
      ctx.numSlideFun()
    };
    // 数字动画
    const numSlideFun = (numText, maxNum, golb) => {
      numText += 5; // 速度的计算可以为小数 。数字越大，滚动越快
      if (numText >= maxNum) {
        numText = maxNum;
        cancelAnimationFrame(golb);
      } else {
        golb = requestAnimationFrame(numSlideFun);
      }
      ctx.amount.value = numText;
    };

    return {
      count,
      add,
      doubleCount,
      a,
      update,
      amount,
      numFun,
      numSlideFun
    };
  },
};
</script>
<style lang="scss" scoped>
.test {
  color: red;
}
</style>