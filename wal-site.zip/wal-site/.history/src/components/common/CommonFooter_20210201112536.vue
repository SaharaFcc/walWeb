<template>
  <div class="commonFooter"></div>
</template>

<script>
export default {
    name: 'CommonFooter'
}
</script>