<template>
  <div class="commonHeader"></div>
</template>

<script>
export default {
  name: "CommonHeader",
};
</script>