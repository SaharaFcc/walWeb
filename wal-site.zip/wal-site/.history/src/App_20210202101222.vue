<template>
  <div id="app">
    <div id="nav">
      <router-link to="/">Home</router-link> |
      <router-link to="/about">About</router-link>
    </div>
    <router-view />
  </div>
</template>

<style lang="scss">
div {
  box-sizing: border-box;
}
#app {
  font-family: "PingFang SC", "Helvetica Neue", Helvetica, "Microsoft YaHei",
    "微软雅黑", Tahoma, Arial, Raleway, sans-serif;
  font-size: 14px;
  color: #000 !important;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
}
#nav {
  padding: 30px;

  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
.content-mainTitle {
  color: #8200ff;
  border-left: 5px solid #8200ff;
  padding-left: 15px;
  font-size: 24px;
  margin-bottom: 50px;
}
.content-subTitle {
  color: #8200ff;
  border-left: 5px solid #8200ff;
  padding-left: 15px;
  font-size: 18px;
  font-weight: 600;
  margin-bottom: 20px;
}
.content-tipTitle {
  margin-bottom: 20px;
}
.tag-list {
  display: flex;
  justify-content: space-around;
  flex-wrap: wrap;
  margin-bottom: 30px;
  & > div {
    width: 49%;
    text-align: center;
    padding: 0 5px;
    margin-bottom: 10px;
    border: 1px solid #8200ff;
    height: 40px;
    line-height: 40px;
    color: #8200ff;
  }
}
</style>
