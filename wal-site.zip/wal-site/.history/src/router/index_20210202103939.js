import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('@/views/Home.vue')
  },
  {
    path: '/about',
    name: 'About',
    component: () => import('@/views/About.vue')
  },
  {
    path: 'cn',
    component: () => import('@/views/cn/index.vue'),
    children: []
  },
  {
    path: '/en',
    component: () => import('@/views/en/index.vue'),
    children: [
      {
        path: 'wta',
        component: () => import('@/views/en/wta/index.vue'),
        children: [
          {
            path: 'bluePaper',
            name: 'BluePaper',
            component: () => import('@/views/en/wta/bluePaper.vue'),
          },
          {
            path: 'appDownload',
            name: 'AppDownload',
            component: () => import('@/views/en/wta/appDownload.vue'),
          }
        ]
      },{
        path: 'solution',
        component: () => import('@/views/en/solution/index.vue'),
        children: [
          {
            path: 'traceSystem',
            name: 'TraceSystem',
            component: () => import('@/views/en/solution/traceSystem.vue')
          },
          {
            path: 'collectSystem',
            name: 'CollectSystem',
            component: () => import('@/views/en/solution/collectSystem.vue')
          },
          {
            path: 'warrantSystem',
            name: 'WarrantSystem',
            component: () => import('@/views/en/solution/warrantSystem.vue')
          },
          {
            path: 'foodSystem',
            name: 'FoodSystem',
            component: () => import('@/views/en/solution/foodSystem.vue')
          }
        ]
      }
    ]
  },
  {
    path: 'kr',
    component: () => import('@/views/kr/index.vue'),
    children: []
  }
]

const router = new VueRouter({
  routes
})

export default router
