<template>
  <div class="communite">
    <div class="container"></div>
  </div>
</template>

<script>
export default {
  name: "Communite",
  data() {
    return {
      imgList: [],
    };
  },
};
</script>
<style lang="scss" scoped>
.communite {
}
</style>