<template>
  <div class="communite"></div>
</template>

<script>
export default {
  name: "Communite",
};
</script>
<style lang="scss" scoped>
.communite {
}
</style>