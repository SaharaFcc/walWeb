<template>
  <div class="communite">
    <div class="container">
      <div v-for="(img, index) in imgList" :key="index">
        <a>
          <img
            v-lazy="'http://www.waltonchain.org/en/Uploads/' + img"
            :key="'http://www.waltonchain.org/en/Uploads/' + img"
          />
        </a>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Communite",
  data() {
    return {
      imgList: [
        "2019-03-06/5c7f64b4e068f.jpg",
        "2019-04-25/5cc15feef016f.png",
        "2019-04-25/5cc1603452ee3.png",
        "2019-04-04/5ca5cfc8321f3.jpg",
        "2019-04-04/5ca5cfd5e3cf8.jpg",
        "2019-04-04/5ca5cfe230f85.jpg",
        "2019-04-04/5ca5cfebbd2f0.jpg",
        "2019-04-04/5ca5cff870217.jpg",
        "2019-04-04/5ca5d0052300c.jpg",
        "2019-04-04/5ca5d01027200.jpg",
        "2019-04-04/5ca5d01c3cb19.jpg",
        "2019-04-04/5ca5d02813ecd.jpg",
        "2019-04-04/5ca5d0316d893.jpg",
        "2019-04-04/5ca5d03c4d86d.jpg",
        "2019-04-04/5ca5d04597309.jpg",
        "2019-04-04/5ca5d06471d46.jpg",
        "2019-04-04/5ca5d087129cf.jpg",
        "2019-04-04/5ca5d09106edd.jpg",
        "2019-04-04/5ca5d09e6693a.jpg",
        "2019-04-04/5ca5d0a941444.jpg",
        "2019-04-04/5ca5d0b293e0d.jpg",
        "2019-04-04/5ca5d0c42a29c.jpg",
        "2019-04-04/5ca5d0d01828b.jpg",
        "2019-04-04/5ca5d0da8ae5c.jpg",
        "2019-05-17/5cde800c7b14c.png",
        "2019-04-04/5ca5d0ef4e029.jpg",
        "2019-04-04/5ca5d0f9633bb.jpg",
        "2019-04-04/5ca5d10f9350f.jpg",
        "2019-04-04/5ca5d119783e8.jpg",
        "2019-04-04/5ca5d122e1c7c.jpg",
        "2019-04-04/5ca5d14d9cc9c.jpg",
        "2019-04-10/5cadb034ac81e.png",
        "2019-04-04/5ca5d14fec23d.jpg",
        "2019-04-04/5ca5d1511ecd2.jpg",
        "2019-04-04/5ca5d15215290.jpg",
        "2019-07-08/5d22e5a8c619f.jpg",
        "2019-03-06/5c7f652733738.jpg",
      ],
    };
  },
};
</script>
<style lang="scss" scoped>
.communite {
  & > .container {
    max-width: 100%;
    & > div {
      &:not(:nth-of-type(2)) {
        margin-bottom: 50px;
      }
    }
  }
}
</style>