<template>
  <div class="foodSystem">
    <div class="icon-list">
      <div>
        <div>
          <img
            v-lazy="
              'http://www.waltonchain.org/en/Uploads/2018-12-20/5c1b8104c0285.png'
            "
            :key="'http://www.waltonchain.org/en/Uploads/2018-12-20/5c1b8104c0285.png'"
          />
        </div>
        <div class="font-weight-bold">Automatic monitoring</div>
      </div>
      <div>
        <div>
          <img
            v-lazy="
              'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b4889dc736.png'
            "
            :key="'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b4889dc736.png'"
          />
        </div>
        <div class="font-weight-bold">
          Automatic data uploading to blockchain
        </div>
      </div>
      <div>
        <div>
          <img
            v-lazy="
              'http://www.waltonchain.org/en/Uploads/2018-12-20/5c1b8102997e4.png'
            "
            :key="'http://www.waltonchain.org/en/Uploads/2018-12-20/5c1b8102997e4.png'"
          />
        </div>
        <div class="font-weight-bold">Two-way traceability</div>
      </div>
    </div>
    <div>
      <div class="container">
        <div class="content-mainTitle font-weight-bold">WTC-Food System</div>
        <div>
          <div class="tag-list">
            <div>Powerful and flexible data collection</div>
            <div>Process information traceability</div>
            <div>High credibility</div>
            <div>Food safety assurance</div>
          </div>
          <div class="text-center">
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2018-12-20/5c1b810ca37a6.jpg'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2018-12-20/5c1b810ca37a6.jpg'"
            />
          </div>
        </div>
      </div>
    </div>
    <div
      v-lazy:background-image="{
        src:
          'http://www.waltonchain.org/en/Theme/wed/Public/images/solutionbj1.jpg',
      }"
    >
      <div class="container">
        <div class="content-mainTitle font-weight-bold">Case Presentation</div>
        <div>
          <div class="media-video position-relative">
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b48ec6f79b.jpg'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b48ec6f79b.jpg'"
            />
            <a class="position-absolute">
              <img
                v-lazy="
                  'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/video2.png'
                "
                :key="'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/video2.png'"
              />
              <p>Watch a Video</p>
            </a>
          </div>
          <div class="font-weight-bold">
            WTC-Food System adds up the Internet, cloud computing and big data
            to the IoT + blockchain core for IoT collection and automatic
            uploading of food safety, production and circulation data to
            blockchain, global distribution management and traceability.
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "FoodSystem",
};
</script>
<style lang="scss" scoped>
.foodSystem {
  .content-mainTitle {
    font-size: 28px;
    margin-bottom: 30px;
    padding: 0px;
    border: 0px;
    & + div {
      border-radius: 30px;
      overflow: hidden;
      box-shadow: 5.5px 9.526px 59px 0px rgba(0, 0, 0, 0.24);
      padding: 50px;
    }
  }
  & > div {
    text-align: left;
    &.icon-list {
      margin: 80px 0px 60px;
      display: flex;
      justify-content: space-around;
      & > div {
        text-align: center;
        font-size: 22px;
        color: #000;
        & > div {
          &:last-of-type {
            margin-top: 20px;
          }
        }
      }
    }
    &:last-of-type {
      color: #555;
      background-repeat: no-repeat;
      background-size: cover;
      padding: 80px 0px;
      margin-top: 80px;
      .content-mainTitle {
        font-size: 34px;
        margin-bottom: 60px;
        & + div {
          box-shadow: none;
          padding: 0px;
          border-radius: 0px;
          font-size: 18px;
          display: flex;
          & > div {
            &.media-video {
              width: 58%;
              border-radius: 10px;
              &::before {
                content: "";
                display: block;
                position: absolute;
                top: 0px;
                left: 0px;
                height: 100%;
                width: 100%;
                background: rgba(0, 0, 0, 0.7);
              }
              img {
                max-width: 100%;
              }
            }
            &:last-of-type {
              width: 42%;
            }
          }
        }
      }
    }
  }
}
</style>