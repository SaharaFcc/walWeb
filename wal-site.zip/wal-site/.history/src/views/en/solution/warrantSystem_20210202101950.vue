<template>
  <div class="warrantSystem">
      
  </div>
</template>

<script>
export default {
    name: 'WarrantSystem'
}
</script>

<style>

</style>