<template>
  <div class="solution">
    <router-view />
  </div>
</template>

<script>
export default {
  name: "Solution",
};
</script>