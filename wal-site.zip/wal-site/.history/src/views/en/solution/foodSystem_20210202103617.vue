<template>
  <div class="foodSystem">
      
  </div>
</template>

<script>
export default {
    name: 'FoodSystem'
}
</script>
<style lang="scss" scoped>
.foodSystem{

}
</style>