<template>
  <div class="traceSystem">
    <div class="container">
      <div>
        <div class="content-mainTitle font-weight-bold">
          Liquor/Pharmaceuticals/Oil & Gas Traceability System
        </div>
        <div>
          <div class="tag-list">
            <div>Full process monitoring</div>
            <div>On-chain data stamps</div>
            <div>Fast on-chain data calling</div>
            <div>Data comparison for authenticity</div>
          </div>
          <div>
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2019-07-16/5d2d8665002a8.jpg'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2019-07-16/5d2d8665002a8.jpg'"
            />
          </div>
        </div>
      </div>
      <div></div>
    </div>
  </div>
</template>

<script>
export default {
  name: "TraceSystem",
};
</script>
<style lang="scss" scoped>
.traceSystem {
  & > .container {
  }
}
</style>