<template>
  <div class="warrantSystem">
      
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>