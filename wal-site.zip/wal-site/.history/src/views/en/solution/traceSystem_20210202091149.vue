<template>
  <div class="traceSystem">
    <div class="container"></div>
  </div>
</template>

<script>
export default {
  name: "TraceSystem",
};
</script>