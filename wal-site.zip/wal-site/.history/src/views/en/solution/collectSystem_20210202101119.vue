<template>
  <div class="collectSystem">
      
  </div>
</template>

<script>
export default {
    name: 'CollectSystem'
}
</script>