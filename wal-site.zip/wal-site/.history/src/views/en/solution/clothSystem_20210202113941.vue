<template>
  <div class="clothSystem"></div>
</template>

<script>
export default {
    name: 'ClothSystem'
}
</script>