<template>
  <div class="traceSystem">
    <div class="container">
      <div>
        <div class="content-mainTitle font-weight-bold">
          Liquor/Pharmaceuticals/Oil & Gas Traceability System
        </div>
        <div>
          <div class="tag-list">
            <div>Full process monitoring</div>
            <div>On-chain data stamps</div>
            <div>Fast on-chain data calling</div>
            <div>Data comparison for authenticity</div>
          </div>
          <div>
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2019-07-16/5d2d8665002a8.jpg'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2019-07-16/5d2d8665002a8.jpg'"
            />
          </div>
        </div>
      </div>
      <div></div>
    </div>
  </div>
</template>

<script>
export default {
  name: "TraceSystem",
};
</script>
<style lang="scss" scoped>
.traceSystem {
  & > .container {
    & > div {
      text-align: left;
    }
    .content-mainTitle {
      font-size: 28px;
      margin-bottom: 30px;
      padding: 0px;
      border: 0px;
      & + div {
        border-radius: 30px;
        overflow: hidden;
        box-shadow: 5.5px 9.526px 59px 0px rgba(0, 0, 0, 0.24);
        padding: 50px;
      }
    }
    .tag-list {
      display: flex;
      justify-content: space-around;
      flex-wrap: wrap;
      & > div {
        width: 50%;
        padding: 0 5px;
        margin-bottom: 10px;
        border: 1px solid #8200ff;
        height: 40px;
        line-height: 40px;
        color: #8200ff;
      }
    }
  }
}
</style>