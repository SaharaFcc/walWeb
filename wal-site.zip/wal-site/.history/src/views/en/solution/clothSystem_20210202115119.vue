<template>
  <div class="clothSystem">
    <div class="icon-list">
      <div class="container">
        <div>
          <div>
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b488299b2e.png'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b488299b2e.png'"
            />
          </div>
          <div class="font-weight-bold">Smart store</div>
        </div>
        <div>
          <div>
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b4889dc736.png'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b4889dc736.png'"
            />
          </div>
          <div class="font-weight-bold">Big data uploading to blockchain</div>
        </div>
        <div>
          <div>
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b488f96f35.png'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b488f96f35.png'"
            />
          </div>
          <div class="font-weight-bold">Luxury goods authentication</div>
        </div>
      </div>
    </div>
    <div>
      <div class="container">
        <div class="content-mainTitle font-weight-bold">WTC-Garment System</div>
        <div>
          <div class="tag-list">
            <div>Full intelligentization of the management process</div>
            <div>Immersive shopping experience</div>
            <div>Brand value maintenance via authentication</div>
            <div>Enrichment of consumer profiles</div>
          </div>
          <div class="text-center">
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b48a90a6fb.jpg'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b48a90a6fb.jpg'"
            />
          </div>
        </div>
      </div>
    </div>
    <div
      v-lazy:background-image="{
        src:
          'http://www.waltonchain.org/en/Theme/wed/Public/images/solutionbj1.jpg',
      }"
    >
      <div class="container">
        <div class="content-mainTitle font-weight-bold">Case Presentation</div>
        <div>
          <div class="media-video position-relative">
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b48ec6f79b.jpg'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b48ec6f79b.jpg'"
            />
            <a class="position-absolute cursor-btn">
              <img
                v-lazy="
                  'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/video2.png'
                "
                :key="'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/video2.png'"
              />
              <p>Watch a Video</p>
            </a>
          </div>
          <div>
            <p class="font-weight-bold">
              Having trouble with long and costly supply chains?
            </p>
            <p>
              Unable to control various SKUs and error rate in logistics and
              warehousing?<br />
              The world’s first blockchain-based clothing authenticity system
              WTC-Garment by Waltonchain is applied to all links of the clothing
              industry, such as supply chain optimization, warehousing and
              logistics management, and consumer big data extraction to
              fundamentally solve the common industry pain points.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "ClothSystem",
};
</script>
<style lang="scss" scoped>
.clothSystem {
  .content-mainTitle {
    font-size: 28px;
    margin-bottom: 30px;
    padding: 0px;
    border: 0px;
    & + div {
      border-radius: 30px;
      overflow: hidden;
      box-shadow: 5.5px 9.526px 59px 0px rgba(0, 0, 0, 0.24);
      padding: 50px;
    }
  }
  & > div {
    text-align: left;
    &.icon-list {
      margin: 80px 0px 60px;
      .container {
        display: flex;
        justify-content: space-around;
        & > div {
          text-align: center;
          font-size: 22px;
          color: #000;
          & > div {
            &:last-of-type {
              margin-top: 20px;
            }
          }
        }
      }
    }
    &:last-of-type {
      color: #555;
      background-repeat: no-repeat;
      background-size: cover;
      padding: 80px 0px;
      margin-top: 80px;
      .content-mainTitle {
        font-size: 34px;
        margin-bottom: 60px;
        & + div {
          box-shadow: none;
          padding: 0px;
          border-radius: 0px;
          display: flex;
          & > div {
            &.media-video {
              width: 58%;
              &::before {
                content: "";
                display: block;
                position: absolute;
                top: 0px;
                left: 0px;
                height: 100%;
                width: 100%;
                background: rgba(0, 0, 0, 0.7);
                border-radius: 10px;
              }
              img {
                max-width: 100%;
                border-radius: 10px;
              }
              a {
                text-decoration: none;
                text-align: center;
                color: #fff;
                font-size: 16px;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                p {
                  margin-top: 8px;
                  &.font-weight-bold {
                    font-size: 24px;
                  }
                }
              }
            }
            &:last-of-type {
              width: 42%;
              padding: 60px 40px 0px;
            }
          }
        }
      }
    }
  }
}
</style>