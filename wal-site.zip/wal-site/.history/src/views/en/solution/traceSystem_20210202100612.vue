<template>
  <div class="traceSystem">
    <div>
      <div class="container">
        <div class="content-mainTitle font-weight-bold">
          Liquor/Pharmaceuticals/Oil & Gas Traceability System
        </div>
        <div>
          <div class="tag-list">
            <div>Full process monitoring</div>
            <div>On-chain data stamps</div>
            <div>Fast on-chain data calling</div>
            <div>Data comparison for authenticity</div>
          </div>
          <div class="text-center">
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2019-07-16/5d2d8665002a8.jpg'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2019-07-16/5d2d8665002a8.jpg'"
            />
          </div>
        </div>
      </div>
    </div>
    <div
      v-lazy:background-image="{
        src:
          'http://www.waltonchain.org/en/Theme/wed/Public/images/solutionbj1.jpg',
      }"
    >
      <div class="container">
        <div class="content-mainTitle font-weight-bold">Case Presentation</div>
        <div>
          <p>
            · The system includes Production Management, Warehousing & Logistics and Consumer End of the production flow
          </p>
          <p>
            · Production End: sensors/devices collect production environment data (temperature, humidity, process), encrypted data/extracted data stamps are uploaded to blockchain and written into the product-bound RFID tag
          </p>
          <p>
            · Logistics & Warehousing deploys RFID reader-writers; product status at each link is recorded in the back-end management system and written into the RFID tag; system data is encrypted and uploaded to blockchain regularly
          </p>
          <p>
            · Consumer End: users scan product tags with RFID readers in stores to view product information and check authenticity
          </p>
          <p>
            Powerful and flexible data collection, information traceability and credit endorsement are beneficial for consumers, enterprises and technology development. It has wide application prospects for health products, liquor and other industries
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "TraceSystem",
};
</script>
<style lang="scss" scoped>
.traceSystem {
  .content-mainTitle {
    font-size: 28px;
    margin-bottom: 30px;
    padding: 0px;
    border: 0px;
    & + div {
      border-radius: 30px;
      overflow: hidden;
      box-shadow: 5.5px 9.526px 59px 0px rgba(0, 0, 0, 0.24);
      padding: 50px;
    }
  }
  .tag-list {
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
    margin-bottom: 30px;
    & > div {
      width: 49%;
      text-align: center;
      padding: 0 5px;
      margin-bottom: 10px;
      border: 1px solid #8200ff;
      height: 40px;
      line-height: 40px;
      color: #8200ff;
    }
  }
  & > div {
    text-align: left;
    &:last-of-type {
      font-size: 16px;
      color: #555;
      background-repeat: no-repeat;
      background-size: cover;
      padding: 80px 0px;
      .content-mainTitle {
        margin-bottom: 60px;
        & + div {
          box-shadow: none;
          padding: 0px;
          border-radius: 0px;
        }
      }
      p {
        margin-bottom: 30px;
      }
    }
  }
}
</style>