<template>
  <div class="collectSystem">
    <div>
      <div class="container">
        <div class="content-mainTitle font-weight-bold">
          Blockchain + Cloud Video Collection System
        </div>
        <div>
          <div class="tag-list">
            <div>Blockchain + Cloud</div>
          </div>
          <div class="text-center">
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2020-06-11/5ee1c7023b37e.png'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2020-06-11/5ee1c7023b37e.png'"
            />
          </div>
        </div>
      </div>
    </div>
    <div
      v-lazy:background-image="{
        src:
          'http://www.waltonchain.org/en/Theme/wed/Public/images/solutionbj1.jpg',
      }"
    >
      <div class="container">
        <div class="content-mainTitle font-weight-bold">Case Presentation</div>
        <div>
          <p>
            · Blockchain Video Collection System includes Data End, System End
            and Application End.
          </p>
          <p>
            · Data end collects video. Camera terminals feature video collection
            devices connected to a cloud server.
          </p>
          <p>
            · System End includes servers, processors and storage. Processors
            segment videos, collect stamps and upload to blockchain at specified
            time periods. The information uploaded to blockchain includes: video
            file name, camera location, camera No., shooting time, video
            fingerprint, etc.
          </p>
          <p>
            · In the application end, users can query related videos by multiple
            parameters on a centralized system, compare video information with
            on-chain data instantly for authenticity and integrity
          </p>
          <p>
            Blockchain + Cloud Architecture can accelerate construction of
            campus/city monitoring system, improve district security work and
            reduce information authenticity disputes of completely centralized
            systems
          </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "CollectSystem",
};
</script>
<style lang="scss" scoped>
.collectSystem {
  .content-mainTitle {
    font-size: 28px;
    margin-bottom: 30px;
    padding: 0px;
    border: 0px;
    & + div {
      border-radius: 30px;
      overflow: hidden;
      box-shadow: 5.5px 9.526px 59px 0px rgba(0, 0, 0, 0.24);
      padding: 50px;
    }
  }
  & > div {
    text-align: left;
    margin-top: 140px;
    &:last-of-type {
      font-size: 16px;
      color: #555;
      background-repeat: no-repeat;
      background-size: cover;
      padding: 80px 0px;
      margin-top: 80px;
      .content-mainTitle {
        font-size: 34px;
        margin-bottom: 60px;
        & + div {
          box-shadow: none;
          padding: 0px;
          border-radius: 0px;
        }
      }
      p {
        margin-bottom: 30px;
      }
    }
  }
}
</style>