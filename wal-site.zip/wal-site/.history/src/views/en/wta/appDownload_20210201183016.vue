<template>
  <div class="appDownload">
    <div class="container">

    </div>
  </div>
</template>

<script>
export default {
    name: 'AppDownload'
}
</script>
<style lang="scss" scoped>
.appDownload{
  
}
</style>