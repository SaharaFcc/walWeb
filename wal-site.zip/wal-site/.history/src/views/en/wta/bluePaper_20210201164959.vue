<template>
  <div class="bluePaper">
      <div class="container">
          <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[0]+'.png'" :key="imgItems[0]">
      </div>
  </div>
</template>

<script>
export default {
    name: 'BluePaper',
    data(){
        return{
            imgItems: ['2019-10-22/5daebe2618532']
        }
    }
}
</script>