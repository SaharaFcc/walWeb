<template>
  <div class="bluePaper">
      <div class="container">
          <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[0]+'.png'" :key="imgItems[0]">
          <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[1]+'.png'" :key="imgItems[1]">
      </div>
  </div>
</template>

<script>
export default {
    name: 'BluePaper',
    data(){
        return{
            imgItems: ['2019-10-22/5daebe2618532','2019-10-22/5daeb59081404']
        }
    }
}
</script>