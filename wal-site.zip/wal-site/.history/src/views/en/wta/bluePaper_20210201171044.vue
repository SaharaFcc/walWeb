<template>
  <div class="bluePaper">
    <div class="container">
      <!-- <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[0]+'.png'" :key="imgItems[0]">
          <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[1]+'.png'" :key="imgItems[1]">
          <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[2]+'.png'" :key="imgItems[2]">
          <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[3]+'.png'" :key="imgItems[3]">
          <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[4]+'.png'" :key="imgItems[4]">
          <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[5]+'.png'" :key="imgItems[5]">
          <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[6]+'.png'" :key="imgItems[6]">
          <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[7]+'.png'" :key="imgItems[7]"> -->
      <div>
        <div class="content-mainTitle font-weight-bold">I. Waltonchain Profile</div>
      </div>
      <div>
        <div class="content-mainTitle font-weight-bold">II. Autonomous Ecosystem</div>
        
      </div>
      <div>
        <div class="content-mainTitle font-weight-bold">III. Waltonchain Autonomy Token</div>
      </div>
      <div>
        <div class="content-mainTitle font-weight-bold">IV. Autonomous Foundation</div>
      </div>
      <div>
        <div class="content-mainTitle font-weight-bold">V. Q&A</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "BluePaper",
  data() {
    return {
      imgItems: [
        "2019-10-22/5daebe2618532",
        "2019-10-22/5daeb59081404",
        "2019-10-22/5daeb5c1e403e",
        "2019-10-22/5daeb5d3963fa",
        "2019-10-22/5daeb5f297a4d",
        "2019-10-22/5daeb6132c3ae",
        "2019-10-22/5daeb78875f99",
        "2019-10-22/5daebd383650e",
        "2019-10-22/5daebd443f406",
      ],
    };
  },
};
</script>
<style lang="scss">
.content-mainTitle {
  color: #8200ff;
  border-left: 5px solid #8200ff;
  padding-left: 15px;
  font-size: 24px;
  margin-bottom: 50px;
}
</style>