<template>
  <div class="bluePaper">
      <div class="container"></div>
  </div>
</template>

<script>
export default {
    name: 'BluePaper'
}
</script>