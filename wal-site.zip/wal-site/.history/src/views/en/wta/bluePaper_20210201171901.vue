<template>
  <div class="bluePaper">
    <div class="container">
      <!-- <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[0]+'.png'" :key="imgItems[0]">
          <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[1]+'.png'" :key="imgItems[1]">
          <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[2]+'.png'" :key="imgItems[2]">
          <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[3]+'.png'" :key="imgItems[3]">
          <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[4]+'.png'" :key="imgItems[4]">
          <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[5]+'.png'" :key="imgItems[5]">
          <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[6]+'.png'" :key="imgItems[6]">
          <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[7]+'.png'" :key="imgItems[7]"> -->
      <div>
        <div class="content-mainTitle font-weight-bold">
          I. Waltonchain Profile
        </div>
        <div>
          <img
            v-lazy="
              'http://www.waltonchain.org/en/Uploads/' + imgItems[0] + '.png'
            "
            :key="imgItems[0]"
          />
        </div>
        <div>
          <p>
            Waltonchain is an open-source underlying public business ecochain.
            As the leader of blockchain + the IoT, Waltonchain uniquely
            integrates blockchain and RFID technology to promote industry
            transformation and upgrading by serving the real economy with
            blockchain technology.
          </p>
          <p>
            Waltonchain combines the decentralization and immutability of
            blockchain with RFID chips developed in-house to provide
            traceability and certification solutions for various industries as
            well as encryption services and distributed database building for
            industrial data.
          </p>
          <p>
            Waltonchain aims to create a fair, transparent, traceable and
            credible new-generation business ecosystem. Based on the blockchain
            technology, Waltonchain constructs a VIoT (Value Internet of Things)
            ecosystem where blockchain merges with the IoT relying on devices,
            network, value and data. Its business applications include food
            traceability, luxury goods identification, seafood transportation
            tracking, logistics tracking and will be further diversified.
          </p>
          <p>Waltonchain Ecosystem Development Process:</p>
          <p>
            1. After the launch and open source of the Fully Operational
            Mainnet, Waltonchain has realized cross-chain data endorsement and
            has started token swap;
          </p>
          <p>
            2. Hardware products developed by Waltonchain in-house, including
            KIRINMINER, Bamboo Wallet, blockchain + RFID chips and Blockchain
            Data Collection Terminal, have been gradually applied in the
            ecosystem.
          </p>
          <p>
            3. Steady ecosystem development and active cooperation with various
            industries to implement child chains and relevant projects in
            logistics, liquor, agriculture traceability and other fields.
          </p>
          <p>
            In the course of the ecosystem development, we have realized that
            only when community supporters become the leaders and decision
            makers can an unprecedented new business ecosystem be created.
          </p>
        </div>
      </div>
      <div>
        <div class="content-mainTitle font-weight-bold">
          II. Autonomous Ecosystem
        </div>
        <div>
          <p>
            The vision of Waltonchain is to lead people into a reliable digital
            life using the blockchain technology and thus achieve consensus,
            co-governance, sharing and connection of IoT data and services in
            the information era. Currently, the Waltonchain ecosystem is under
            steady development. Next, we wish community supporters can become
            the leaders and decision makers to gather innovative ideas and
            initiatives from the community and expand the Waltonchain ecosystem
            massively.
          </p>
          <p>
            In order make WTC application more stable in the cross-chain IoT
            ecosystem and reduce the impact of market behavior on the WTC price
            fluctuation, Walton Chain Foundation issues Waltonchain Autonomy
            token (WTA) on the Waltonchain mainnet and establishes the
            Autonomous Foundation.
          </p>
          <p>
            Waltonchain Autonomous Foundation will exert the strengths of global
            supporters to jointly build the Waltonchain ecosystem and further
            promote and expand its application in various fields around the
            world to make it truly decentralized.
          </p>
          <p>
            This Community Autonomy Blue Paper outlines a detailed plan for
            Waltonchain community autonomy and covers its constitution as well
            as benefits, rights and obligations of the participants. All
            Waltonchain community autonomy members have the right to enjoy
            Waltonchain ecosystem benefits and must also fulfill their
            obligations in accordance with the requirements specified herein to
            contribute to the development of the Waltonchain ecosystem.
          </p>
        </div>
      </div>
      <div>
        <div class="content-mainTitle font-weight-bold">
          III. Waltonchain Autonomy Token
        </div>
        <div>
          <div class="content-subTitle font-weight-bold">3.1 WTA Mechanism</div>
          <p>
              <span>Token name: </span>WTA (Waltonchain Autonomy)
          </p>
          <p>
              <span>Total supply: </span>500,000,000
          </p>
        </div>
        <div>
          <div class="content-subTitle font-weight-bold">3.2 WTA Utilization</div>
        </div>
      </div>
      <div>
        <div class="content-mainTitle font-weight-bold">
          IV. Autonomous Foundation
        </div>
      </div>
      <div>
        <div class="content-mainTitle font-weight-bold">V. Q&A</div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "BluePaper",
  data() {
    return {
      imgItems: [
        "2019-10-22/5daebe2618532",
        "2019-10-22/5daeb59081404",
        "2019-10-22/5daeb5c1e403e",
        "2019-10-22/5daeb5d3963fa",
        "2019-10-22/5daeb5f297a4d",
        "2019-10-22/5daeb6132c3ae",
        "2019-10-22/5daeb78875f99",
        "2019-10-22/5daebd383650e",
        "2019-10-22/5daebd443f406",
      ],
    };
  },
};
</script>
<style lang="scss">
.content-mainTitle {
  color: #8200ff;
  border-left: 5px solid #8200ff;
  padding-left: 15px;
  font-size: 24px;
  margin-bottom: 50px;
}
.content-subTitle {
  color: #8200ff;
  border-left: 5px solid #8200ff;
  padding-left: 15px;
  font-size: 18px;
  font-weight: 600;
  margin-bottom: 50px;
}
</style>