<template>
  <div
    class="appDownload"
    v-lazy:background-image="{
      src: 'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b45bae6acc.jpg',
    }"
  >
    <div class="container">
      <div class="download-link">
        <a>DOWNLOAD</a>
      </div>
      <div>
        <img
          v-lazy="
            'http://www.waltonchain.org/en/Uploads/2020-10-09/5f802f1e9337a.png'
          "
          :key="'http://www.waltonchain.org/en/Uploads/2020-10-09/5f802f1e9337a.png'"
        />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "AppDownload",
};
</script>
<style lang="scss" scoped>
.appDownload {
  background-repeat: no-repeat;
  background-position: center right;
  & > .container {
    padding: 80px 0px;
    a {
      display: inline-block;
      padding: 0 30px;
      border-radius: 30px;
      border: 2px solid #8200ff;
      color: #8200ff;
      height: 35px;
      line-height: 31px;
      text-transform: uppercase;
    }
    .download-link {
      margin-bottom: 80px;
    }
    &>div{
      text-align: left;
    }
  }
}
</style>