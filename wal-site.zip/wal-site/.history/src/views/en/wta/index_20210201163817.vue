<template>
  <div class="wta">
      <router-view/>
  </div>
</template>

<script>
export default {
    name: 'Wta'
}   
</script>