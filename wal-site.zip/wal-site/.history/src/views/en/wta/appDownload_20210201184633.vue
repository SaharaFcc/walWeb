<template>
  <div class="appDownload" v-lazy:background-image="{src:'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b45bae6acc.jpg'}">
    <div class="container">
      <div></div>
      <div></div>
    </div>
  </div>
</template>

<script>
export default {
    name: 'AppDownload'
}
</script>
<style lang="scss" scoped>
.appDownload{
  background-repeat: no-repeat;
  background-position: center right;
  &.container{
    padding: 80px 0px;
  }
}
</style>