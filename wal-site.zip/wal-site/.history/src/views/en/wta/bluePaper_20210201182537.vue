<template>
  <div class="bluePaper">
    <div class="container">
      <div>
        <div class="content-mainTitle font-weight-bold">
          I. Waltonchain Profile
        </div>
        <div>
          <img
            v-lazy="
              'http://www.waltonchain.org/en/Uploads/' + imgItems[0] + '.png'
            "
            :key="imgItems[0]"
          />
        </div>
        <div>
          <p>
            Waltonchain is an open-source underlying public business ecochain.
            As the leader of blockchain + the IoT, Waltonchain uniquely
            integrates blockchain and RFID technology to promote industry
            transformation and upgrading by serving the real economy with
            blockchain technology.
          </p>
          <p>
            Waltonchain combines the decentralization and immutability of
            blockchain with RFID chips developed in-house to provide
            traceability and certification solutions for various industries as
            well as encryption services and distributed database building for
            industrial data.
          </p>
          <p>
            Waltonchain aims to create a fair, transparent, traceable and
            credible new-generation business ecosystem. Based on the blockchain
            technology, Waltonchain constructs a VIoT (Value Internet of Things)
            ecosystem where blockchain merges with the IoT relying on devices,
            network, value and data. Its business applications include food
            traceability, luxury goods identification, seafood transportation
            tracking, logistics tracking and will be further diversified.
          </p>
          <p>Waltonchain Ecosystem Development Process:</p>
          <p>
            1. After the launch and open source of the Fully Operational
            Mainnet, Waltonchain has realized cross-chain data endorsement and
            has started token swap;
          </p>
          <p>
            2. Hardware products developed by Waltonchain in-house, including
            KIRINMINER, Bamboo Wallet, blockchain + RFID chips and Blockchain
            Data Collection Terminal, have been gradually applied in the
            ecosystem.
          </p>
          <p>
            3. Steady ecosystem development and active cooperation with various
            industries to implement child chains and relevant projects in
            logistics, liquor, agriculture traceability and other fields.
          </p>
          <p>
            In the course of the ecosystem development, we have realized that
            only when community supporters become the leaders and decision
            makers can an unprecedented new business ecosystem be created.
          </p>
        </div>
      </div>
      <div>
        <div class="content-mainTitle font-weight-bold">
          II. Autonomous Ecosystem
        </div>
        <div>
          <p>
            The vision of Waltonchain is to lead people into a reliable digital
            life using the blockchain technology and thus achieve consensus,
            co-governance, sharing and connection of IoT data and services in
            the information era. Currently, the Waltonchain ecosystem is under
            steady development. Next, we wish community supporters can become
            the leaders and decision makers to gather innovative ideas and
            initiatives from the community and expand the Waltonchain ecosystem
            massively.
          </p>
          <p>
            In order make WTC application more stable in the cross-chain IoT
            ecosystem and reduce the impact of market behavior on the WTC price
            fluctuation, Walton Chain Foundation issues Waltonchain Autonomy
            token (WTA) on the Waltonchain mainnet and establishes the
            Autonomous Foundation.
          </p>
          <p>
            Waltonchain Autonomous Foundation will exert the strengths of global
            supporters to jointly build the Waltonchain ecosystem and further
            promote and expand its application in various fields around the
            world to make it truly decentralized.
          </p>
          <p>
            This Community Autonomy Blue Paper outlines a detailed plan for
            Waltonchain community autonomy and covers its constitution as well
            as benefits, rights and obligations of the participants. All
            Waltonchain community autonomy members have the right to enjoy
            Waltonchain ecosystem benefits and must also fulfill their
            obligations in accordance with the requirements specified herein to
            contribute to the development of the Waltonchain ecosystem.
          </p>
        </div>
      </div>
      <div>
        <div class="content-mainTitle font-weight-bold">
          III. Waltonchain Autonomy Token
        </div>
        <div>
          <div class="content-subTitle font-weight-bold">3.1 WTA Mechanism</div>
          <p>
              <span class="font-weight-bold">Token name:</span>WTA (Waltonchain Autonomy)
          </p>
          <p>
              <span class="font-weight-bold">Total supply:</span>500,000,000
          </p>
          <p>
              <span class="font-weight-bold">Distribution rules:</span>
              <p>Pre-mining (pre-staking) (7%): 35,000,000</p>
              <p>Reward Pool (3%): 15,000,000</p>
              <p>Staking (90%): 450,000,000</p>
              <p class="text-center">
                  <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[1]+'.png'" :key="imgItems[1]">
              </p>
          </p>
          <div>
              <div class="content-subTitle font-weight-bold">Pre-mining (pre-staking): 7%, 35,000,000 WTA</div>
              <p class="font-weight-bold">
                  The pre-mining period is 7 days. Walton Chain Foundation commits to buy back the pre-mined WTA at the ratio of 1 WTC = 9 WTA one year after the issuance of WTA.
              </p>
              <p>
                  Users participating in pre-mining will have an equivalent WTA buyback quota. All the WTA mined in the pre-mining period will be bought back.
              </p>
              <div>
                  <div class="font-weight-bold content-tipTitle">1. Pre-mining for SMN and GMN Users</div>
                  <p>
                      <span class="font-weight-bold">Total amount: 25,000,000 WTA.</span>
                      SMN and GMN users will not lose their corresponding identity by participating in the pre-mining; instead, they will receive WTA airdrops. After the pre-mining period ends,
                    <span>the remaining not pre-mined portion shall be added to the Autonomous Ecosystem Reward Pool.</span>
                  </p>
                  <p>
                      <span class="font-weight-bold">SMN participation method:</span>
                        During the pre-mining period, SMN users can participate in 360-day lock-up staking to obtain WTA airdrop at a ratio of 1:1 (WTC:WTA). 2% of the WTA airdrop will be released after the pre-mining period ends, and the remaining 98% will be completely released in 7 months after 3 months of formal staking, i.e. 14% each month (distributed daily). The minimum lock-up amount shall be 100,000 WTC. The WTC participating in the 360-day lock-up staking will be unlocked on day 361.
                  </p>
                  <p class="text-center">
                      <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[2]+'.png'" :key="imgItems[2]">
                  </p>
                  <p>
                      <span class="font-weight-bold">GMN participation method:</span>
                      During the pre-mining period, GMN users holding 10,000 WTC or more can participate in 360-day lock-up staking to obtain WTA airdrop at the ratio shown in the table below. 2% of the WTA airdrop will be released after the pre-mining period ends, and the remaining 98% will be completely released in 7 months after 3 months of formal staking, i.e. 14% each month (distributed daily). The minimum lock-up amount shall be 10,000 WTC. The WTC participating in the 360-day lock-up staking will be unlocked on day 361.
                  </p>
                  <p class="text-center">
                      <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[3]+'.png'" :key="imgItems[3]">
                  </p>
              </div>
              <div>
                  <div class="font-weight-bold content-tipTitle">2. Pre-mining for All Users</div>
                  <p>
                      Total 10,000,000 WTA.
                      <span class="font-weight-bold">The remaining not pre-mined portion shall be added to the Autonomous Ecosystem Reward Pool.</span>
                  </p>
                  <p>
                      All WTC holders can exchange WTC for WTA at the ratio shown in the table below. 2% of this portion will be released after the pre-mining period ends, and the remaining 98% will be completely released in 7 months after 3 months of formal staking, i.e. 14% each month (distributed daily).
                  </p>
                  <p class="text-center">
                      <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[4]+'.png'" :key="imgItems[4]">
                  </p>
              </div>
          </div>
          <div>
              <div class="content-subTitle font-weight-bold">Reward Pool: 3%, total 15,000,000 WTA to reward community autonomy contributors.</div>
          </div>
          <div>
              <div class="content-subTitle font-weight-bold">Staking: 90%, total 450,000,000 WTA</div>
              <p>
                  Staking means lock-up of WTC to receive WTA. The minimum lock-up amount shall be 200 WTC. Each day, 20,000 WTA can be received for staking in the pool and withdrawn after release. The pool can be staked for about 60 years.
              </p>
              <p>
                  <span class="font-weight-bold">Staking rewards formula:</span>
                  <p>
                      My Hash Rate = Lock-up Amount × Time Coefficient
                  </p>
                  <p>
                      Daily Rewards = My Hash Rate / Total Hash Rate × 20,000 WTA
                  </p>
                  <p class="text-center">
                      <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[5]+'.png'" :key="imgItems[5]">
                  </p>
                  <p>
                      Each user can have several simultaneous lock-up staking orders.
                  </p>
                  <p>
                      For orders with lock-up period of 15, 30, 60, 90 and 180 days, early exit is not allowed.
                  </p>
                  <p>
                      For orders with lock-up period of 270 and 360 days, early exit is allowed only after the orders have been locked for at least 180 days and a service fee is charged.
                  </p>
                  <p>
                      For pre-mining orders, early exit is not allowed.
                  </p>
                  <p>
                      Service Fee = (Remaining Days / Lock-up Period) × Lock-up Amount × 0.2
                  </p>
                  <p>
                      Example: If a user locked up 5,000 WTC for a period of 360 days, then 180/360 × 5,000 WTC × 0.2 = 500 WTC will be charged as service fee if the user exits early on day 181.
                  </p>
              </p>
          </div>
        </div>
        <div>
          <div class="content-subTitle font-weight-bold">3.2 WTA Utilization</div>
          <div>
              <div class="font-weight-bold content-tipTitle">3.2.1 Do Tasks, Earn Points</div>
              <p>
                  Waltonchain Global Autonomous Foundation will irregularly launch tasks for the community; and community members can earn points by completing these tasks. The points can be converted into WTA at a certain ratio. Board of Directors and project managers of the Autonomous Foundation can post public bids on the task platform of the Autonomous Foundation (including task requirements, time requirement and rewards amount, etc.). The tasks will be open to the whole community; and their performance by the Members of the Autonomous Foundation will be preferred. After completing the tasks, task performers shall submit the corresponding reports to earn points. Community members who have completed a certain amount of tasks will receive additional rewards from the Autonomous Foundation or will become project managers and long-term partners under the Board of Directors.
              </p>
          </div>
          <div>
              <div class="font-weight-bold content-tipTitle">3.2.2 Discounts</div>
              <p>
                  The upcoming public Child Chain Platform will support exchange between child chain tokens and WTC as well as exchange between child chain tokens on the Waltonchain mainnet. WTA will be used to deduct service fee during the token exchange.
              </p>
              <p>
                  WTA can be used to deduct partial service fees for trading on the exchange or OTC platform under the Waltonchain Ecosystem. Details will be announced further by the respective platforms.
              </p>
          </div>
          <div>
              <div class="font-weight-bold content-tipTitle">3.2.3 Child Chain Platform</div>
              <p>
                  <span class="font-weight-bold">WTA will be used as support funds to launch child chains and obtain child chain tokens.</span>
                  Top three child chains that receive the highest amount of WTA support each month will be given priority to launch on the Child Chain Platform, and will have the opportunity to receive financial and resource support from the Walton Chain Foundation. Details will be further announced when the Child Chain Platform is launched.
              </p>
          </div>
          <div>
              <div class="font-weight-bold content-tipTitle">3.2.4 Waltymall</div>
              <p>
                  WTA can be used to deduct the price of commodities on Waltymall. Details will be further announced on the Mall.
              </p>
              <p>
                  Autonomous Foundation Members also have the right to list commodities on the Mall through WTA collateral.
              </p>
          </div>
        </div>
      </div>
      <div>
        <div class="content-mainTitle font-weight-bold">
          IV. Autonomous Foundation
        </div>
        <div>
            <div class="content-subTitle font-weight-bold">4.1 Constitution</div>
            <p>
                1. This Constitution is formulated to standardize the operation of the Waltonchain Global Autonomous Foundation (hereinafter referred to as the “Autonomous Foundation”), effectively exert the decision-making and supervision functions of the Autonomous Foundation, maintain the secure and stable operation of the Waltonchain mainnet, and jointly establish the Waltonchain global ecosystem community.
            </p>
            <p>
                2. The Autonomous Foundation is composed of Members and the Board of Directors. Both shall be responsible for the operation and management of the Autonomous Foundation and perform corresponding responsibilities.
            </p>
            <p>
                3. Users with WTA hash rate will automatically become the Members of the Autonomous Foundation. Members have the right to propose, vote and comment issues posted on the Waltonchain Autonomous Platform in relation to the development of the Waltonchain ecosystem.
            </p>
            <p>
                4. Members of the Autonomous Foundation must perform their obligations with integrity and diligence to ensure abiding by the Constitution of the Autonomous Foundation as well as focus on safeguarding the interests of the Waltonchain global community and interested parties.
            </p>
            <p>
                5. Board of Directors of the Autonomous Foundation shall be elected by voting from the Members of the Autonomous Foundation for a term of one year. Board of Directors shall have the final voting right on proposals. Members who have 360-day lock-up staking orders can participate in the election. Each Member of the Autonomous Foundation only has one vote which can only be given to one candidate. Top 15 candidates with the highest votes shall be appointed Directors of the Autonomous Foundation.
            </p>
            <p>
                6. All the Members of the Autonomous Foundation shall have the right and obligation to raise and spread proposals that are conducive to the development of Waltonchain. After a round of voting by all the Members, the proposals passed shall be submitted to the Board of Directors for final voting.
            </p>
            <p>
                7. The Board of Directors shall bear the final responsibility of cost management of the Autonomous Foundation and make sure that voting is performed properly according to cost calculation consistent with the current ecosystem development.
            </p>
            <p>
                8. Resignation of Directors. When a Director of the Autonomous Foundation resigns from the Board out of personal reasons, it shall be supplemented from the Members of the Autonomous Foundation.
            </p>
            <p>
                9. Removal of Directors. If behavior of a Director of the Autonomous Foundation is harmful to the interests of Waltonchain and the Waltonchain community, any member of the Autonomous Foundation may provide evidence and initiate voting to remove the Director from the Autonomous Foundation and recover the losses incurred by the Autonomous Foundation.
            </p>
            <p>
                10. Walton Chain Foundation shall keep the fund of the Autonomous Foundation and allocate it to execute proposals. All the Members of the Autonomous Foundation and Walton Chain Foundation shall jointly supervise the execution and effect of the proposals.
            </p>
        </div>
        <div>
            <div class="content-subTitle font-weight-bold">4.2 Members</div>
            <div>
                <div class="font-weight-bold content-tipTitle">4.2.1 Benefits</div>
                <p>
                    1. Members can raise proposals on the development of the Waltonchain ecosystem and obtain rewards once the proposals pass the voting by all Members and Directors. Rewards shall be 500 to 10,000 WTA; the exact amount shall be determined by the Board of Directors as appropriate.
                </p>
                <p>
                    2. WTA and child chain token airdrops shall be distributed once every three months as per the community participation of Members (community participation includes number of votes, number of proposals, number of executed proposals, membership period, etc.).
                </p>
            </div>
            <div>
                <div class="font-weight-bold content-tipTitle">4.2.2 Rights</div>
                <p>
                    Members are the core of the Autonomous Foundation. They shall have the right to raise proposals, vote and supervise the Board of Directors of the Autonomous Foundation.
                </p>
            </div>
            <div>
                <div class="font-weight-bold content-tipTitle">4.2.3 Obligations</div>
                <p>
                    Members shall continuously have WTA hash rate. Once a member has no hash rate, it shall lose the membership.
                </p>
            </div>
            <div>
                <div class="font-weight-bold content-tipTitle">4.2.4 How to Become a Member?</div>
                <p>
                    Applicants shall lock WTC for staking to become a Member. After the Member identity is activated on the Autonomous Foundation Platform, WTA staking rewards shall be distributed to the Member.
                </p>
            </div>
        </div>
        <div>
            <div class="content-subTitle font-weight-bold">4.3 Board of Directors</div>
            <p>
                Board of Directors is the core representative of the Autonomous Foundation. It shall have the final voting and decision right on child chains, Mall, exchanges, DApps and technical development under the Waltonchain ecosystem, as well as on the future ecosystem constitution.
            </p>
            <div>
                <div class="font-weight-bold content-tipTitle">4.3.1 Election of Directors</div>
                <p>
                    Directors shall be elected once a year for term of one year. Before each election, Members of the Autonomous Foundation can apply to become candidates. Candidates shall submit the required election documents to the Autonomous Community. After the application period ends, each Member shall give its vote to one candidate. Top 15 candidates with the highest votes shall be appointed Directors of the Autonomous Foundation.
                </p>
            </div>
            <div>
                <div class="font-weight-bold content-tipTitle">4.3.2 Benefits of Directors</div>
                <p>
                    <span class="font-weight-bold">WTC rewards </span>
                    shall be distributed to Directors of the Autonomous Foundation every 6 months as per their contribution to the community.
                    <span class="font-weight-bold">The total reward pool shall be 30,000 WTC.</span>
                    Directors can also enjoy higher WTA deduction when buying KIRINMINER.
                </p>
            </div>
            <div>
                <div class="font-weight-bold content-tipTitle">4.3.3 Obligations of Directors</div>
                <p>
                    Directors shall continuously have WTA hash rate during their one-year term of office, otherwise their qualification shall be cancelled automatically. If a Director waives his qualification, the vacancy shall be filled by the candidate who ranks No. 16.
                </p>
            </div>
            <div>
                <div class="font-weight-bold content-tipTitle">4.3.4 Rights of Directors</div>
                <p>
                    <span>Ecosystem Decision-making</span>
                    <p class="text-center">
                        <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[6]+'.png'" :key="imgItems[6]">
                    </p>
                    <p>
                        All the Members of the Autonomous Foundation shall have the right to decide on and provide capital support for child chains, Mall, exchanges, DApps, technology development and the future ecosystem components.
                    </p>
                    <p class="font-weight-bold">Note: Waltonchain team shall have the right of final interpretation of the Blue Paper.</p>
                </p>
            </div>
        </div>
      </div>
      <div>
        <div class="content-mainTitle font-weight-bold">V. Q&A</div>
        <div>
            <div class="font-weight-bold">1. What is WTA and why is WTA needed?</div>
            <p>
                WTA is the new Waltonchain Autonomy token issued on the Waltonchain mainnet.
                <span class="font-weight-bold">It does not replace WTC as the mainnet/parent-chain coin.</span>
                WTA is a child-chain token for a specific, within-ecosystem purpose, namely to facilitate the Waltonchain Autonomous Foundation and introduce a dynamic form of Proof of Stake (PoS) to WTC.
            </p>
        </div>
        <div>
            <div class="font-weight-bold">2. What's the value of WTA?</div>
            <p>
                Within the pre-mining period, 1 WTC equals 12 to 10 WTA. At the official issuance, 1 WTC equals 10 WTA. After listing on exchanges, the market value of WTA will fluctuate. Walton Chain Foundation commits to buy back the 35,000,000 pre-mined WTA at the ratio of 9 WTA = 1 WTC one year after the issuance of WTA.
            </p>
        </div>
        <div>
            <div class="font-weight-bold">3. Is the WTA code secure?</div>
            <p>
                Yes! The smart contract has been fully audited and approved by CertiK as part of the recent comprehensive mainnet audit.
            </p>
        </div>
        <div>
            <div class="font-weight-bold">4. Does the Blue Paper affect the previously announced SMN cross-chain rewards, GMN and PoS rewards?</div>
            <p>
                Not in the least. Walton Chain Foundation commits to provision of the previously announced GMN and PoS rewards (see
                <a> Waltonchain Progressive Mining Reward Program</a>
                ) and SMN cross-chain rewards.
            </p>
        </div>
        <div>
            <div class="font-weight-bold">5. Can holders of ERC-20 WTC participate in WTA staking?</div>
            <p>
                They sure can. WTA pre-mining and staking supports both ERC-20 WTC tokens and mainnet Waltoncoin. When WTA are bought back after the lock-up period ends, holders will receive mainnet WTC.
            </p>
        </div>
        <div>
            <div class="font-weight-bold">6. Does a GMN with 15,000 WTC benefit from the WTC Pre-lockup (for one year locked in total) more than one with 10,000 WTC?</div>
            <p>
                Yes! The ratio increases from [1:0.4] to [1:0.5] when you have more than 15,000. That’s a 10% increase from 40% to 50%. If you have 5,000 WTC only, you need to obtain 5,000 more WTC to participate as a GMN. If you are an owner of multiple GMNs or wish to join hands with another GMN owner, you are eligible for the pre-lockup. More details are to be announced separately.
            </p>
            <p class="text-center">
                <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[7]+'.png'" :key="imgItems[7]">
            </p>
            <p class="text-center">
                <img v-lazy="'http://www.waltonchain.org/en/Uploads/'+imgItems[8]+'.png'" :key="imgItems[8]">
            </p>
        </div>
        <div>
            <div class="font-weight-bold">7. Why lock WTC? How does that benefit the ecosystem?</div>
            <p>
                Locking coins adds a key structural component in the ecosystem by allowing the Autonomous Foundation’s Directors and members to prove a stake in the ecosystem while completing tasks such as electing Directors, executing proposals, voting and rewarding community initiatives. As a secondary tokenomics benefit, locked coins mean lower selling pressure on the markets. Lower selling pressure + normal buying pressure + increased real ecosystem usage (requiring parent chain WTC) = increased valuation of WTC. However, this is not guaranteed to occur as markets are unpredictable and should be assessed on an individual basis. In other words, this is not financial advice.
            </p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "BluePaper",
  data() {
    return {
      imgItems: [
        "2019-10-22/5daebe2618532",
        "2019-10-22/5daeb59081404",
        "2019-10-22/5daeb5c1e403e",
        "2019-10-22/5daeb5d3963fa",
        "2019-10-22/5daeb5f297a4d",
        "2019-10-22/5daeb6132c3ae",
        "2019-10-22/5daeb78875f99",
        "2019-10-22/5daebd383650e",
        "2019-10-22/5daebd443f406",
      ],
    };
  },
};
</script>
<style lang="scss">
.content-mainTitle {
  color: #8200ff;
  border-left: 5px solid #8200ff;
  padding-left: 15px;
  font-size: 24px;
  margin-bottom: 50px;
}
.content-subTitle {
  color: #8200ff;
  border-left: 5px solid #8200ff;
  padding-left: 15px;
  font-size: 18px;
  font-weight: 600;
  margin-bottom: 20px;
}
.content-tipTitle{
    margin-bottom: 20px;
}
</style>
<style lang="scss" scoped>
.bluePaper {
  & > .container {
    img {
      max-width: 100% !important;
    }
    P{
        margin-bottom: 20px;
        line-height: 30px;
    }
    & > div {
      text-align: left;
      background: #fff;
      box-shadow: 6px 10.392px 62px 0px rgba(0, 0, 0, 0.07);
      padding: 90px;
      border-radius: 30px;
      &:not(:first-of-type) {
        margin-top: 30px;
      }
    }
  }
}
</style>