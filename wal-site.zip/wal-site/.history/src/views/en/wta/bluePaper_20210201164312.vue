<template>
  <div class="bluePaper">
      <div class="container">
          <img src="http://www.waltonchain.org/en/Uploads/2019-10-22/5daebe2618532.png" alt="">
      </div>
  </div>
</template>

<script>
export default {
    name: 'BluePaper'
}
</script>