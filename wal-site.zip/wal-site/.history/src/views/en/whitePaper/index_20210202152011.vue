<template>
  <div class="whitePaper">
    <div>
      <div class="container">
        <div>
          The Innovation Redesigned: Waltonchain 101 What exactly is
          Waltonchain?
        </div>
        <div>
          <div class="media-video position-relative">
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2018-12-10/5c0dd5c1d91b8.jpg'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2018-12-10/5c0dd5c1d91b8.jpg'"
            />
            <a class="position-absolute">
              <img
                v-lazy="
                  'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/video2.png'
                "
                :key="'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/video2.png'"
              />
              <p>
                  Watch a Video Introduction
              </p>
            </a>
          </div>
          <div></div>
        </div>
        <div>
          <a>Browse the white paper</a>
        </div>
      </div>
    </div>
    <div>
      <div class="container"></div>
    </div>
  </div>
</template>

<script>
export default {
  name: "WhitePaper",
};
</script>
<style lang="scss" scoped>
.whitePaper {
}
</style>