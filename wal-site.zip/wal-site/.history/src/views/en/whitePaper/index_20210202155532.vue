<template>
  <div class="whitePaper">
    <div>
      <div class="container">
        <div class="font-weight-bold text-center">
          The Innovation Redesigned: Waltonchain 101 What exactly is
          Waltonchain?
        </div>
        <div>
          <div class="media-video position-relative">
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2018-12-10/5c0dd5c1d91b8.jpg'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2018-12-10/5c0dd5c1d91b8.jpg'"
            />
            <a class="position-absolute">
              <img
                v-lazy="
                  'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/video2.png'
                "
                :key="'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/video2.png'"
              />
              <p>Watch a Video Introduction</p>
            </a>
          </div>
          <div>
            <div class="font-weight-bold">Waltonchain White Paper V 2.0</div>
            <div>
              <p>
                On September 4, 2018, Waltonchain officially released White
                Paper V2.0. It is not only a periodic report on the business
                ecosystem construction progress, but also a deep interpretation
                of the future vision of Waltonchain. It presents the most
                sincere, valuable and imaginative consensus mechanism available
                today, WPoC (Waltonchain Proof of Contribution), and puts
                forward the unprecedented Chain Cluster concept.
              </p>
              <p>
                The various projects Waltonchain has been working on have one
                simple idea at their core: to lead humanity into a reliable
                digital life, establish a brand new sustainable business
                ecosystem with all things interconnected via the blockchain
                technology. With our trust mechanism, human life will become
                more productive. We invite everyone to read our white paper and
                discover the potential of Waltonchain!
              </p>
            </div>
          </div>
        </div>
        <div class="text-center">
          <a>Browse the white paper</a>
        </div>
      </div>
    </div>
    <div>
      <div class="container">
        <div class="font-weight-bold">Read</div>
        <div>
          <a class="cursor-btn">
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2018-12-20/5c1b20d1a8ad2.jpg'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2018-12-20/5c1b20d1a8ad2.jpg'"
            />
            <p class="text-center font-weight-bold">English</p>
            <p>Update date 2018-10-17</p>
          </a>
          <a class="cursor-btn">
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b9bddb5a8e.jpg'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b9bddb5a8e.jpg'"
            />
            <p class="text-center font-weight-bold">Chinese</p>
            <p>Update date 2018-10-17</p>
          </a>
          <a class="cursor-btn">
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b9bddb5a8e.jpg'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b9bddb5a8e.jpg'"
            />
            <p class="text-center font-weight-bold">Chinese Traditional</p>
            <p>Update date 2018-10-17</p>
          </a>
          <a class="cursor-btn">
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2019-01-04/5c2ef65563fc0.jpg'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2019-01-04/5c2ef65563fc0.jpg'"
            />
            <p class="text-center font-weight-bold">Korean</p>
            <p>Update date 2018-10-17</p>
          </a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "WhitePaper",
};
</script>
<style lang="scss" scoped>
.whitePaper {
  & > div {
    padding: 80px 0px;
    text-align: left;
    &:first-of-type {
      .container {
        & > div {
          &:first-of-type {
            font-size: 24px;
            margin-bottom: 60px;
          }
          &:nth-of-type(2) {
            display: flex;
            & > div {
              width: 50%;
              &.media-video {
                &::before {
                  content: "";
                  display: block;
                  position: absolute;
                  top: 0px;
                  left: 0px;
                  height: 100%;
                  width: 100%;
                  background: rgba(0, 0, 0, 0.7);
                  border-radius: 10px;
                }
                img {
                  max-width: 100%;
                  border-radius: 10px;
                }
                a {
                  text-decoration: none;
                  text-align: center;
                  color: #fff;
                  font-size: 16px;
                  top: 50%;
                  left: 50%;
                  transform: translate(-50%, -50%);
                  p {
                    margin-top: 8px;
                  }
                }
              }
              &:last-of-type {
                padding: 0px 22px;
                & > div {
                  &:first-of-type {
                    font-size: 30px;
                    color: #8200ff;
                    margin-bottom: 20px;
                  }
                  p {
                    font-size: 15px;
                    color: #555;
                  }
                }
              }
            }
          }
          &:last-of-type {
            margin-top: 50px;
            a {
              color: #8200ff;
              border-radius: 30px;
              border: 2px solid #8200ff;
              font-size: 15px;
              height: 35px;
              line-height: 31px;
              padding: 0 30px;
              text-transform: uppercase;
              display: inline-block;
            }
          }
        }
      }
    }
    &:last-of-type {
      background: #e9e9e9;
      .container {
        & > div {
          &:first-of-type {
            margin-bottom: 60px;
            color: #8200ff;
            font-size: 34px;
            & + div {
              display: flex;
              justify-content: space-between;
              a {
                text-decoration: none;
                p {
                  color: #000;
                  &:first-of-type {
                    font-size: 18px;
                    padding: 20px 0 8px;
                    border-bottom: 5px solid #8200ff;
                    margin-bottom: 5px;
                  }
                  &:last-of-type {
                    font-size: 12px;
                  }
                }
              }
            }
          }
          img {
            border-radius: 27px;
          }
        }
      }
    }
  }
}
</style>