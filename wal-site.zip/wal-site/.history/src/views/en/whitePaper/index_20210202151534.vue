<template>
  <div class="whitePaper">
    <div>
      <div class="container">
        <div>
          The Innovation Redesigned: Waltonchain 101 What exactly is
          Waltonchain?
        </div>
        <div>
            <div class="media-video"></div>
            <div></div>
        </div>
        <div>
            <a>Browse the white paper</a>
        </div>
      </div>
    </div>
    <div>
      <div class="container"></div>
    </div>
  </div>
</template>

<script>
export default {
  name: "WhitePaper",
};
</script>
<style lang="scss" scoped>
.whitePaper {
}
</style>