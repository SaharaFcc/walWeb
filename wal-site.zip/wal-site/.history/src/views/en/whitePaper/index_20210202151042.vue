<template>
  <div class="whitePaper"></div>
</template>

<script>
export default {
    name: 'WhitePaper'
}
</script>
<style lang="scss" scoped>
.whitePaper{

}
</style>