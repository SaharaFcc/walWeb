<template>
  <div class="whitePaper">
    <div>
      <div class="container">
        <div class="font-weight-bold">
          The Innovation Redesigned: Waltonchain 101 What exactly is
          Waltonchain?
        </div>
        <div>
          <div class="media-video position-relative">
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2018-12-10/5c0dd5c1d91b8.jpg'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2018-12-10/5c0dd5c1d91b8.jpg'"
            />
            <a class="position-absolute">
              <img
                v-lazy="
                  'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/video2.png'
                "
                :key="'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/video2.png'"
              />
              <p>Watch a Video Introduction</p>
            </a>
          </div>
          <div>
            <div>Waltonchain White Paper V 2.0</div>
            <div>
              <p>
                On September 4, 2018, Waltonchain officially released White
                Paper V2.0. It is not only a periodic report on the business
                ecosystem construction progress, but also a deep interpretation
                of the future vision of Waltonchain. It presents the most
                sincere, valuable and imaginative consensus mechanism available
                today, WPoC (Waltonchain Proof of Contribution), and puts
                forward the unprecedented Chain Cluster concept.
              </p>
              <p>
                The various projects Waltonchain has been working on have one
                simple idea at their core: to lead humanity into a reliable
                digital life, establish a brand new sustainable business
                ecosystem with all things interconnected via the blockchain
                technology. With our trust mechanism, human life will become
                more productive. We invite everyone to read our white paper and
                discover the potential of Waltonchain!
              </p>
            </div>
          </div>
        </div>
        <div>
          <a>Browse the white paper</a>
        </div>
      </div>
    </div>
    <div>
      <div class="container"></div>
    </div>
  </div>
</template>

<script>
export default {
  name: "WhitePaper",
};
</script>
<style lang="scss" scoped>
.whitePaper {
  & > div {
    text-align: left;
    .container {
      & > div {
        &:first-of-type {
          text-align: center;
          font-size: 24px;
          margin-bottom: 60px;
        }
      }
    }
  }
}
</style>