<template>
  <div class="whitePaper">
    <div>
        <div class="container">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
    <div>
        <div class="container"></div>
    </div>
  </div>
</template>

<script>
export default {
    name: 'WhitePaper'
}
</script>
<style lang="scss" scoped>
.whitePaper{

}
</style>