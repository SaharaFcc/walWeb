<template>
  <div class="wtc">
    <router-view />
  </div>
</template>

<script>
export default {
  name: "Wtc",
};
</script>