<template>
  <div class="childChain">
      <div>
          <div class="container">
              <div class="content-mainTitle font-weight-bold">Public Child Chains Introduction</div>
              <div>
                  <p>
                      Waltonchain is a cross-chain ecosystem where the parent chain and child chains serve as the framework. In this cross-chain ecosystem, data circulation and value transfer can be realized between child chains.
                  </p>
                  <p>
                      In general, data in a blockchain + IoT ecosystem is a simple ecosystem. Parts of the ecosystem are fragmented. Different domains build their own data ecosystem around their data, or build their own blockchain architecture. Blockchains may even adopt different structure and technical systems.
                  </p>
                  <p>
                      The main aim of Waltonchain is to connect data. In the Waltonchain ecosystem, the multi-chain architecture formed by the parent chain and child chains follows the development trend of cross-industry coverage in the blockchain technology. The innovative child chains for various industries utilize the encrypted and secure IoT data acquisition hardware to deeply integrate the business logic of specific industries and form an open industry expansion mechanism with strong vitality. Waltonchain is committed to incubation of 50 outstanding global child chain projects to build a massive cross-industry blockchain ecosystem.
                  </p>
              </div>
          </div>
      </div>
      <div>
          <div class="container"></div>
      </div>
  </div>
</template>

<script>
export default {
    name: 'ChildChain'
}
</script>
<style lang="scss" scoped>
.childChain{
    &>div{
        text-align: left;
        p{
            font-size: 16px;
            color: #555;
            margin-bottom: 20px;
        }
    }
}
</style>