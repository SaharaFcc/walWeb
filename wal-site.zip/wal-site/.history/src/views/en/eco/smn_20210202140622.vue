<template>
  <div class="smn">
      <div class="container">
          <div>
              <div class="content-mainTitle font-weight-bold">Recruitment Program Introduction</div>
          </div>
          <div>
              <div class="content-mainTitle font-weight-bold">Recruitment Type</div>
          </div>
          <div>
              <div class="content-mainTitle font-weight-bold">SMN Permissions/Capabilities</div>
          </div>
          <div>
              <div class="content-mainTitle font-weight-bold">SMN Qualification</div>
          </div>
          <div>
              <div class="content-mainTitle font-weight-bold">Distribution of SMN Rewards</div>
          </div>
          <div>
              <div class="content-mainTitle font-weight-bold">SMN List</div>
          </div>
      </div>
  </div>
</template>

<script>
export default {
    name: 'Smn'
}
</script>
<style lang="scss" scoped>
.smn{
    &>.container{
        &>div{
            text-align: left;
        }
    }
}
</style>