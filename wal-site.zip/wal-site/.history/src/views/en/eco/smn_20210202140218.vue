<template>
  <div class="smn">

  </div>
</template>

<script>
export default {
    name: 'Smn'
}
</script>