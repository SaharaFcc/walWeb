<template>
  <div class="eco">
    <router-view/>
  </div>
</template>

<script>
export default {
    name: 'Eco'
}
</script>