<template>
  <div class="kirinminer">
    <div class="container">
      <img
        v-lazy="
          'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b488299b2e.png'
        "
        :key="'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b488299b2e.png'"
      />
    </div>
  </div>
</template>

<script>
export default {
  name: "Kirinminer",
  data(){
      return{
          
      }
  }
};
</script>
<style lang="scss" scoped>
.kirinminer {
  & > .container {
    img {
      max-width: 100%;
    }
  }
}
</style>