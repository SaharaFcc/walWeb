<template>
  <div class="kirinminer">
      <div class="container">

      </div>
  </div>
</template>

<script>
export default {
    name: 'Kirinminer'
}
</script>
<style lang="scss" scoped>
.kirinminer{
    &>.container{
        
    }
}
</style>