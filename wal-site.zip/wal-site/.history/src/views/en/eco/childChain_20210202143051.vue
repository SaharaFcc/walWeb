<template>
  <div class="childChain">
      <div>
          <div class="container"></div>
      </div>
      <div>
          <div class="container"></div>
      </div>
  </div>
</template>

<script>
export default {
    name: 'ChildChain'
}
</script>
<style lang="scss" scoped>
.childChain{
    
}
</style>