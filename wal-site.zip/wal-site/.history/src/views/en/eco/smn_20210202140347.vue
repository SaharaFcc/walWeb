<template>
  <div class="smn">
      <div class="container">
          <div>
              <div class="content-mainTitle"></div>
          </div>
          <div></div>
          <div></div>
          <div></div>
          <div></div>
          <div></div>
      </div>
  </div>
</template>

<script>
export default {
    name: 'Smn'
}
</script>
<style lang="scss" scoped>
.smn{
    &>.container{

    }
}
</style>