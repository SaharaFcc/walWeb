<template>
  <div class="smn">
      <div class="container">
          <div>
              <div class="content-mainTitle font-weight-bold">Recruitment Program Introduction</div>
              <div>
                  <p>
                      To enrich and improve the business ecology of Waltonchain, Waltonchain Foundation is about to recruit 99 Super Master Nodes worldwide to mobilize the global community for incubation and selection of high-quality child chains. To assist the development of the Waltonchain technology, this plan provides a set of incentive rules and an autonomous management mechanism aiming to accelerate the construction of the open and expansive child chain ecology and cross-chain ecology, attract more public attention to the Value IoT and related application implementation services and lead the humanity and lead human to enter the reliable digital life.
                  </p>
                  <p>
                      In the Waltonchain ecosystem, the parent chain + child chains architecture with cross-industry expansion is the development trend of the blockchain technology. The child chains of various industries utilize innovative encrypted and secure IoT data collection hardware, integrate in-depth business logics of a specific industry and bring vitality to the open industry expansion mechanism. SMN nodes will form a hierarchical multi-chain network linking various industries to promote the child chain ecology prosperity worldwide. Waltonchain’s cross-chain mechanism allows efficient value and data circulation between the parent chain and multiple child chains, and integrate the multi-chain into a whole cross-industry blockchain ecology. An SMN is a cross-chain node that confirms cross-chain transactions and ensures their safety and efficiency.
                  </p>
                  <p>
                      Waltonchain Foundation invested 10 million WTC to establish Waltonchain Global Ecosystem Incubation Fund (WGEIF) to incubate 50 global high-quality child chains and provides 550,000 WTC to SMN references. Waltonchain Foundation plans to recruit 30 SMNs in Asia, 30 in the US, 19 in Europe, 15 in Australia and 5 in Africa based on the current global distribution of nodes. In the event of any change of the distribution that leads to the change of the program, a further written notice will be provided.
                  </p>
              </div>
          </div>
          <div>
              <div class="content-mainTitle font-weight-bold">Recruitment Type</div>
          </div>
          <div>
              <div class="content-mainTitle font-weight-bold">SMN Permissions/Capabilities</div>
          </div>
          <div>
              <div class="content-mainTitle font-weight-bold">SMN Qualification</div>
          </div>
          <div>
              <div class="content-mainTitle font-weight-bold">Distribution of SMN Rewards</div>
          </div>
          <div>
              <div class="content-mainTitle font-weight-bold">SMN List</div>
          </div>
      </div>
  </div>
</template>

<script>
export default {
    name: 'Smn'
}
</script>
<style lang="scss" scoped>
.smn{
    &>.container{
        &>div{
            text-align: left;
        }
    }
}
</style>