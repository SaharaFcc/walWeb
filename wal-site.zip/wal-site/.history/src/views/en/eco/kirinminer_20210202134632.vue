<template>
  <div class="kirinminer">
    <div class="container">
      <img
        v-lazy="
          'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b488299b2e.png'
        "
        :key="'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b488299b2e.png'"
      />
    </div>
  </div>
</template>

<script>
export default {
  name: "Kirinminer",
  data() {
    return {
      imgList: [
        "2019-06-10/5cfe27777ac7a",
        "2019-06-10/5cfe2777e843b",
        "2019-06-10/5cfe2903660c5",
        "2019-04-24/5cc021699b14e",
        "2019-04-24/5cc0216a69f9c",
        "2019-04-24/5cc02175126c0",
        "2019-04-24/5cc021756d0c7",
        "2019-04-24/5cc02175e7ef8",
        "2019-04-24/5cc02176aaaef",
        "2019-04-24/5cc0217740988",
        "2019-04-30/5cc80404dd075",
      ],
    };
  },
};
</script>
<style lang="scss" scoped>
.kirinminer {
  & > .container {
    img {
      max-width: 100%;
    }
  }
}
</style>