<template>
  <div class="businessProcess">
      
  </div>
</template>

<script>
export default {

}
</script>
<style lang="scss" scoped>
.businessProcess{

}
</style>