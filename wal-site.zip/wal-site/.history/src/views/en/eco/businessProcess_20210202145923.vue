<template>
  <div class="businessProcess">
    <div class="container"></div>
  </div>
</template>

<script>
export default {};
</script>
<style lang="scss" scoped>
.businessProcess {
}
</style>