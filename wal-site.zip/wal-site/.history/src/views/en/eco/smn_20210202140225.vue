<template>
  <div class="smn">

  </div>
</template>

<script>
export default {
    name: 'Smn'
}
</script>
<style lang="scss" scoped>
.smn{
    
}
</style>