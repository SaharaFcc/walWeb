<template>
  <div class="businessProcess">
    <div class="container">
        <p>

        </p>
        <p>
            
        </p>
    </div>
  </div>
</template>

<script>
export default {};
</script>
<style lang="scss" scoped>
.businessProcess {
}
</style>