<template>
  <div class="eco"></div>
</template>

<script>
export default {
    name: 'Eco'
}
</script>