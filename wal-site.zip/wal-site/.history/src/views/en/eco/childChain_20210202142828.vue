<template>
  <div class="childChain">
      
  </div>
</template>

<script>
export default {
    name: 'ChildChain'
}
</script>