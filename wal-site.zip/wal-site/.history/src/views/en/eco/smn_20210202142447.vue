<template>
  <div class="smn">
      <div class="container">
          <div>
              <div class="content-mainTitle font-weight-bold">Recruitment Program Introduction</div>
              <div>
                  <p>
                      To enrich and improve the business ecology of Waltonchain, Waltonchain Foundation is about to recruit 99 Super Master Nodes worldwide to mobilize the global community for incubation and selection of high-quality child chains. To assist the development of the Waltonchain technology, this plan provides a set of incentive rules and an autonomous management mechanism aiming to accelerate the construction of the open and expansive child chain ecology and cross-chain ecology, attract more public attention to the Value IoT and related application implementation services and lead the humanity and lead human to enter the reliable digital life.
                  </p>
                  <p>
                      In the Waltonchain ecosystem, the parent chain + child chains architecture with cross-industry expansion is the development trend of the blockchain technology. The child chains of various industries utilize innovative encrypted and secure IoT data collection hardware, integrate in-depth business logics of a specific industry and bring vitality to the open industry expansion mechanism. SMN nodes will form a hierarchical multi-chain network linking various industries to promote the child chain ecology prosperity worldwide. Waltonchain’s cross-chain mechanism allows efficient value and data circulation between the parent chain and multiple child chains, and integrate the multi-chain into a whole cross-industry blockchain ecology. An SMN is a cross-chain node that confirms cross-chain transactions and ensures their safety and efficiency.
                  </p>
                  <p>
                      Waltonchain Foundation invested 10 million WTC to establish Waltonchain Global Ecosystem Incubation Fund (WGEIF) to incubate 50 global high-quality child chains and provides 550,000 WTC to SMN references. Waltonchain Foundation plans to recruit 30 SMNs in Asia, 30 in the US, 19 in Europe, 15 in Australia and 5 in Africa based on the current global distribution of nodes. In the event of any change of the distribution that leads to the change of the program, a further written notice will be provided.
                  </p>
              </div>
          </div>
          <div>
              <div class="content-mainTitle font-weight-bold">Recruitment Type</div>
              <div>
                  <p>
                      Community users — global Waltonchain community supporters
                  </p>
                  <p>
                      Business users — participants in the new Waltonchain business ecosystem
                  </p>
                  <p>
                      R&D teams — global Waltonchain technology innovative developers
                  </p>
                  <p>
                      Academic teams — global Waltonchain technology researchers
                  </p>
                  <p>
                      Investment institutions — global Waltonchain capital supporters
                  </p>
              </div>
          </div>
          <div>
              <div class="content-mainTitle font-weight-bold">SMN Permissions/Capabilities</div>
              <div>
                  <p>
                      1. Child Chain Projects Recommendation Priority.
                      <p>
                          After the recommendation and successful incubation of a child chain project, rewards will be given to the corresponding reference SMN.
                      </p>
                  </p>
                  <p>
                      2. Child Chain Voting Right.
                      <p>
                          When WGEIF proposes incubation of a certain child chain, all SMNs have the voting right on incubation proposals. A proposal shall be deemed passed when one third or more votes in favor are valid. One node has one vote. Abstain from voting or no vote within the set time shall be deemed vote abstention.
                      </p>
                  </p>
                  <p>
                      3. An SMN confirms nodes by running cross-chain transactions, ensures safe and efficient cross-chain transactions.
                  </p>
              </div>
          </div>
          <div>
              <div class="content-mainTitle font-weight-bold">SMN Qualification</div>
              <div>
                  <p>
                      1. Applicants must hold not less than 100,000 WTC stored at an ERC20 address before token swap and at a WTC Wallet address after the token swap.
                  </p>
                  <p>
                      2. Applicants holding not less than 50,000 WTC are qualified to subscribe for WTC exchange at the Binance exchange rate of WTC for BTC/ETH MA20 (average closing price for the past 20 days) on the application date. GMNs enjoy a 5 percent discount on the above price. Please submit your subscription application at the official Waltonchain website.
                  </p>
                  <p>
                      3. After confirming the SMN qualification, please ensure the address continues to hold not less than 100,000 WTC. An SMN holding less than 100,000 WTC will be automatically considered a waiver of the SMN identity.
                  </p>
              </div>
          </div>
          <div>
              <div class="content-mainTitle font-weight-bold">Distribution of SMN Rewards</div>
              <div>
                  <div>
                      <div>Distribution of SMN Rewards</div>
                      <p>
                          1. Waltonchain Foundation invested 10 million WTC to establish WGEIF to incubate 50 global high-quality child chains. The child chain projects can only accept investment in WTC.
                      </p>
                      <p>
                          2. Based on the incubation needs and scope of cooperation, a child chain project can exchange child chain tokens for maximum of 100,000 WTC for project development purposes. The investment quota of each child chain project will be decided according to the voting of SMNs, and the details will be provided in written form.
                      </p>
                      <p>
                          3. Waltonchain Foundation provides 550,000 WTC to SMN references.
                      </p>
                  </div>
                  <div>
                      <div>SMN Reward Mechanism</div>
                      <div>
                          <p>
                              1. After a successful recommendation of a child chain project by SMN, the child chain token investment with value of no more than 100,000 WTC obtained by WGEIF will be used as follows:
                              <p>
                                  5% for a global airdrop;<br/>
                                  30% for SMN rewards (an SMN reference enjoys 10%; the remaining 20% is split equally between all SMNs);<br/>
                                  65% for Waltonchain ecosystem construction.
                              </p>
                          </p>
                          <p>
                              2. SMN with the highest annual total number of child chain recommendations (at least 5 child chains recommended) will get a reward equal to 5,000,000 USD in child chain tokens form WGEIF.
                          </p>
                          <p>
                              3. SMNs will have the privilege to attend the Waltonchain Summit, annual meetings and other events free of charge.
                          </p>
                          <p>
                              4. SMNs will be qualified for the 2nd term Director of Waltonchain Foundation.
                          </p>
                          <p>
                              5. SMNs will be qualified for priority to study at Walton Blockchain Institute in Korea.
                          </p>
                          <p>
                              6. SMNs will be qualified for priority to obtain Sales Agency rights for the relevant Waltonchain products.
                          </p>
                      </div>
                  </div>
                  <div>
                      <div>SMN Reference Reward Mechanism</div>
                      <div>
                          <p>
                              1. A reference who successfully recommended an SMN obtains 2600 WTC and will continue to obtain extra 60 WTC when a new SMN joins after a successful recommendation by others.
                          </p>
                          <p>
                              2. A reference with the highest total number of SMN recommendations (at least 5 SMNs recommended) will get a reward equal to 1,000,000 USD in child chain tokens form WGEIF.
                          </p>
                          <p>
                              3. When an SMN has no reference, the recommendation reward is obtained by the SMN itself or by its organization.
                          </p>
                          <p>
                              4. An SMN reference will be qualified to attend the Waltonchain Summit, annual meetings and other events free of charge.
                          </p>
                          <p>
                              5. An SMN reference will be qualified for priority to study at Walton Blockchain Institute in Korea.
                          </p>
                          <p>
                              6. An SMN reference will be qualified for priority to obtain Sales Agency rights for the relevant Waltonchain products.
                              <p>
                                  <img
                                    v-lazy="'http://www.waltonchain.org/en/Uploads/2019-01-15/5c3d985cbc0cd.png'"
                                    :key="'http://www.waltonchain.org/en/Uploads/2019-01-15/5c3d985cbc0cd.png'"
                                    />
                              </p>
                              <p>
                                  <span class="font-weight-bold">*Note:</span>
                                  An SMN reference refers to a user who successfully recommended an SMN to Waltonchain.
                              </p>
                          </p>
                      </div>
                  </div>
              </div>
          </div>
          <div>
              <div class="content-mainTitle font-weight-bold">SMN List</div>
              <div>
                  <img
                    v-lazy="'http://www.waltonchain.org/en/Uploads/2019-01-15/5c3d977c55d4c.png'"
                    :key="'http://www.waltonchain.org/en/Uploads/2019-01-15/5c3d977c55d4c.png'"
                    />
              </div>
          </div>
      </div>
  </div>
</template>

<script>
export default {
  name: "Smn",
};
</script>
<style lang="scss" scoped>
.smn {
  & > .container {
    & > div {
      text-align: left;
      background: #fff;
      box-shadow: 6px 10.392px 62px 0px rgba(0, 0, 0, 0.07);
      padding: 90px;
      border-radius: 30px;
      &:not(:first-of-type) {
        margin-top: 30px;
      }
    }
    .content-mainTitle{
        &+div{
            color: red;
        }
    }
  }
}
</style>