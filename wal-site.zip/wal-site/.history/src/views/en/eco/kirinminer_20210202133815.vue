<template>
  <div class="kirinminer">
      
  </div>
</template>

<script>
export default {
    name: 'Kirinminer'
}
</script>
<style lang="scss" scoped>
.kirinminer{

}
</style>