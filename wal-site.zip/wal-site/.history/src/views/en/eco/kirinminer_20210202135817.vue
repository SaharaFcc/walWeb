<template>
  <div class="kirinminer">
    <div class="container">
      <img
        v-lazy="'http://www.waltonchain.org/en/Uploads/' + imgList[0] + '.jpg'"
        :key="'http://www.waltonchain.org/en/Uploads/' + imgList[0] + '.jpg'"
      />
      <a>
        <img
          v-lazy="
            'http://www.waltonchain.org/en/Uploads/' + imgList[1] + '.jpg'
          "
          :key="'http://www.waltonchain.org/en/Uploads/' + imgList[1] + '.jpg'"
        />
      </a>
      <img
        v-lazy="'http://www.waltonchain.org/en/Uploads/' + imgList[2] + '.jpg'"
        :key="'http://www.waltonchain.org/en/Uploads/' + imgList[2] + '.jpg'"
      />
      <a>
        <img
          v-lazy="
            'http://www.waltonchain.org/en/Uploads/' + imgList[1] + '.jpg'
          "
          :key="'http://www.waltonchain.org/en/Uploads/' + imgList[1] + '.jpg'"
        />
      </a>
      <img
        v-lazy="'http://www.waltonchain.org/en/Uploads/' + imgList[3] + '.jpg'"
        :key="'http://www.waltonchain.org/en/Uploads/' + imgList[3] + '.jpg'"
      />
      <img
        v-lazy="'http://www.waltonchain.org/en/Uploads/' + imgList[4] + '.jpg'"
        :key="'http://www.waltonchain.org/en/Uploads/' + imgList[4] + '.jpg'"
      />
      <img
        v-lazy="'http://www.waltonchain.org/en/Uploads/' + imgList[5] + '.jpg'"
        :key="'http://www.waltonchain.org/en/Uploads/' + imgList[5] + '.jpg'"
      />
      <img
        v-lazy="'http://www.waltonchain.org/en/Uploads/' + imgList[6] + '.jpg'"
        :key="'http://www.waltonchain.org/en/Uploads/' + imgList[6] + '.jpg'"
      />
      <img
        v-lazy="'http://www.waltonchain.org/en/Uploads/' + imgList[7] + '.jpg'"
        :key="'http://www.waltonchain.org/en/Uploads/' + imgList[7] + '.jpg'"
      />
      <img
        v-lazy="'http://www.waltonchain.org/en/Uploads/' + imgList[8] + '.jpg'"
        :key="'http://www.waltonchain.org/en/Uploads/' + imgList[8] + '.jpg'"
      />
      <img
        v-lazy="'http://www.waltonchain.org/en/Uploads/' + imgList[9] + '.jpg'"
        :key="'http://www.waltonchain.org/en/Uploads/' + imgList[9] + '.jpg'"
      />
      <img
        v-lazy="'http://www.waltonchain.org/en/Uploads/' + imgList[10] + '.jpg'"
        :key="'http://www.waltonchain.org/en/Uploads/' + imgList[10] + '.jpg'"
      />
    </div>
  </div>
</template>

<script>
export default {
  name: "Kirinminer",
  data() {
    return {
      imgList: [
        "2019-06-10/5cfe27777ac7a",
        "2019-06-10/5cfe2777e843b",
        "2019-06-10/5cfe2903660c5",
        "2019-04-24/5cc021699b14e",
        "2019-04-24/5cc0216a69f9c",
        "2019-04-24/5cc02175126c0",
        "2019-04-24/5cc021756d0c7",
        "2019-04-24/5cc02175e7ef8",
        "2019-04-24/5cc02176aaaef",
        "2019-04-24/5cc0217740988",
        "2019-04-30/5cc80404dd075",
      ],
    };
  },
};
</script>
<style lang="scss" scoped>
.kirinminer {
  & > .container {
    margin: 50px 0px;
    img {
      max-width: 100%;
    }
  }
}
</style>