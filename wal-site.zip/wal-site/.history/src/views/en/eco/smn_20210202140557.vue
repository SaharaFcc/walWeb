<template>
  <div class="smn">
      <div class="container">
          <div>
              <div class="content-mainTitle">Recruitment Program Introduction</div>
          </div>
          <div>
              <div class="content-mainTitle">Recruitment Type</div>
          </div>
          <div>
              <div class="content-mainTitle">SMN Permissions/Capabilities</div>
          </div>
          <div>
              <div class="content-mainTitle">SMN Qualification</div>
          </div>
          <div>
              <div class="content-mainTitle">Distribution of SMN Rewards</div>
          </div>
          <div>
              <div class="content-mainTitle">SMN List</div>
          </div>
      </div>
  </div>
</template>

<script>
export default {
    name: 'Smn'
}
</script>
<style lang="scss" scoped>
.smn{
    &>.container{
        &>div{
            text-align: left;
        }
    }
}
</style>