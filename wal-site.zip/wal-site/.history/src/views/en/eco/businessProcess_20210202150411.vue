<template>
  <div class="businessProcess">
    <div class="container">
      <p>
        <img
          v-lazy="
            'http://www.waltonchain.org/en/Uploads/2019-04-10/5cadc87ab6614.jpg'
          "
          :key="'http://www.waltonchain.org/en/Uploads/2019-04-10/5cadc87ab6614.jpg'"
        />
      </p>
      <p>
        <img
          v-lazy="
            'http://www.waltonchain.org/en/Uploads/2019-04-12/5cb06ce52928e.png'
          "
          :key="'http://www.waltonchain.org/en/Uploads/2019-04-12/5cb06ce52928e.png'"
        />
      </p>
    </div>
  </div>
</template>

<script>
export default {};
</script>
<style lang="scss" scoped>
.businessProcess {
    &>.container{
        padding: 50px 0px;
        img{
            max-width: 100%;
        }
    }
}
</style>