<template>
  <div class="en">
    <router-view />
  </div>
</template>

<script>
export default {
  name: "En",
};
</script>