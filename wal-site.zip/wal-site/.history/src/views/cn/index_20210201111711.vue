<template>
  <div class="cn">
    <router-view />
  </div>
</template>

<script>
export default {
  name: "Cn",
};
</script>