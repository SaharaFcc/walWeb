<template>
  <div class="cn"></div>
</template>

<script>
export default {
    name: 'Cn'
}
</script>