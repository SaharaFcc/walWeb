const path = require('path')
const webpack = require('webpack')
const CompressionPlugin = require("compression-webpack-plugin")
// const UglifyPlugin = require('uglifyjs-webpack-plugin')

const utils = {
    assetsPath: (_path)=>{
        const assetsSubDirectory = process.env.NODE_ENV === 'production'
        ? 'static' : 'static'

        return path.posix.join(assetsSubDirectory, _path)
    },
    resolve: (dir)=>{
        return path.join(__dirname, '..', dir)
    }
}
function resolve(dir) {
    return path.join(__dirname, '.', dir)
}
module.exports = {
    publicPath: './', // 基本路径
    outputDir: 'dist', // 输出文件目录
    lintOnSave: false, // eslint-loader 是否在保存时检查

    // webpack配置
    chainWebpack: (config) => {
        config.plugin('provide').use(webpack.ProvidePlugin, [{
            $: 'jquery',
            jquery: 'jquery',
            jQuery: 'jquery',
            'window.jQuery': 'jquery',
            Popper: ['popper.js', 'default']
        }])

        config.module.rules.delete("svg"); //重点:删除默认配置中处理svg,
        config.module
        .rule('svg-sprite-loader')
        .test(/\.svg$/)
        .include
        .add(resolve('src/icons')) //处理svg目录
        .end()
        .use('svg-sprite-loader')
        .loader('svg-sprite-loader')
        .options({
            symbolId: 'icon-[name]'
        })
        
        // 开启js、css压缩
        if (process.env.NODE_ENV === 'production') {
            config.plugin('compressionPlugin')
            .use(new CompressionPlugin({
              test:/\.js$|\.html$|\.css$|\.jpg$|\.jpeg$|\.png/, // 匹配文件名
              threshold: 10240, // 对超过10k的数据压缩
              deleteOriginalAssets: false // 不删除源文件
            }))
        }
    },
    configureWebpack: (config) => {
        if (process.env.NODE_ENV === 'production') {
            // 生产环境配置-->将每个依赖打包成单独js文件
            const optimization = {
                runtimeChunk: 'single',
                splitChunks: {
                    chunks: 'all',
                    maxInitialRequests: Infinity,
                    minSize: 20000,
                    cacheGroups: {
                        vendor: {
                            test: /[\\/]node_modules[\\/]/,
                            name(module) {
                                const packageName = module.context.match(/[\\/]node_modules[\\/](.*?)([\\/]|$)/)[1]
                                return `npm.${packageName.replace('@', '')}`
                            }
                        }
                    }
                },
            }

            Object.assign(config, {
                optimization
            })
        } else {
            // 开发环境配置
        }
        module:{
            rules: [
                {
                    test:/\.(woff2?|eot|ttf|otf)(\?.*)$/,
                    loader:'url-loader',
                    options:{
                        limit: 10000,
                        name: utils.assetsPath('fonrs/[name].[hash:7].[ext]')
                    }
                }
            ]
        }
        Object.assign(config, {
            // 生产 开发共同配置
            resolve: {
                // 别名配置
                alias: {
                    '@': path.resolve(__dirname, './src')
                }
            }
        })
    },
    productionSourceMap: false, // 生产环境是否生成sourceMap文件
    // css相关配置
    css: {
        sourceMap: false, // 是否开启css sourceMap
        // css预设器配置
        loaderOptions: {
            css: {} // 选项会传递给css-loader
            // postcss: {}, //选项会传递给postcss-loader
        },
        requireModuleExtension: true
    },
    parallel: require('os').cpus().length > 1, // 是否为babel或typescript使用thread-loader,该选项在系统的 CPU 有多于一个内核时自动启用，仅作用于生产构建
    pwa: {}, // pwa相关插件

    // webpack-dev-server相关配置
    devServer: {
        hot:true,
        open: process.platform === 'darwin',
        host: '0.0.0.0', // 允许外部ip访问
        port: 8084, // 端口
        https: false, // 启用https
        // 警告 错误在页面弹出
        overlay: {
            warnings: true,
            errors: true
        },
        // 代理配置
        proxy: {
            '/verify/api': {
                target: 'http://waltonchain.pro:8881/verify/api',
                changeOrigin: true, // 允许跨域
                pathRewrite: {
                    '^/verify/api': ''
                }
            },
            '/api': {
                // http://192.168.1.228/api
                target: 'http://192.168.1.132:3000/api',
                changeOrigin: true, // 允许跨域
                pathRewrite: {
                    '^/api': ''
                }
            },
            
        }
    },
    // 第三方插件配置
    pluginOptions: {

    }
}