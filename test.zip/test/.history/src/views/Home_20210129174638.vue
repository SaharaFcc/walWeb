<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png">
    <HelloWorld msg="Welcome to Your Vue.js App"/>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'Home',
  components: {
    HelloWorld
  },
  mounted(){
    this.$axios.get('/api/12.html',{params:{p:1}}).then((res)=>{console.log(res)}).catch(()=>{console.log('+++++++++')})
  }
}
</script>
