<template>
  <div class="home">
    <img alt="Vue logo" src="../assets/logo.png">
    <HelloWorld msg="Welcome to Your Vue.js App"/>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'

export default {
  name: 'Home',
  components: {
    HelloWorld
  },
  mounted(){
    this.$axios.get('/api/12.html',{params:{p:1}})
    .then((res)=>{
      console.log(res.data)
      const startIndex = res.data.indexOf('<div class="newslist clearfix" id="content-list">')
      const endIndex = res.data.indexOf('<div class="clearfix"></div>')
      const subStr = res.data.slice(startIndex,endIndex)
      console.log('subStr',subStr)
    })
    .catch(()=>{
      console.log('+++++++++')
    })
  }
}
</script>
