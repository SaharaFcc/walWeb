<template>
  <div class="exchange"></div>
</template>

<script>
export default {
    name: 'Exchange'
}
</script>