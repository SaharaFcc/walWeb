<template>
  <div class="tokenSwap"></div>
</template>

<script>
export default {
    name: 'TokenSwap'
}
</script>