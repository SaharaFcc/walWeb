<template>
  <div class="wallet"></div>
</template>

<script>
export default {
    name: 'Wallet'
}
</script>