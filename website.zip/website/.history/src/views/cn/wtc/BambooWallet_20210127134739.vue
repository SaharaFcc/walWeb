<template>
  <div class="bambooWallet"></div>
</template>

<script>
export default {
    name: 'BambooWallet'
}
</script>