<template>
  <div class="tokenSwap">
    <div class="container">
      <div>
        <div>
          <div>SMN、GMN用户代币切换进度（更新中）</div>
          <div>
            
          </div>
        </div>
        <div>
          <div></div>
        </div>
        <div></div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
    name: 'TokenSwap'
}
</script>