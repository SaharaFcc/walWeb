<template>
  <div class="cn cn-container"></div>
</template>

<script>
export default {
    name: 'Cn'
}
</script>