<template>
  <div class="clothSystem">
      <div class="container">
          <!-- 公用头部 -->
          <!-- <div></div> -->
          <div>
              <div>
                  <div>WTC-GARMENT系统</div>
                  <div>
                      <div>
                          <div>丰富消费者画像</div>
                          <div>沉浸式购物体验</div>
                          <div>全智能管理物流</div>
                          <div>保真维护品牌价值</div>
                      </div>
                  </div>
              </div>
              <div>
                  <div>案例展示</div>
                  <div>
                      <div></div>
                      <div>
                          <div>供应链各环节冗长，成本过高？ SKU繁多、物流仓储差错率难以控制？</div>
                          <div>
                              沃尔顿链“全球首个区块链服装鉴真系统<br/>
                              WTC-GARMENT”应用在供应链优化、仓储物流管理、及消费者大数据提取等服装行业各环节，从根本上解决服装行业普遍痛点。
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</template>

<script>
export default {
    name: 'ClothSystem'
}
</script>