<template>
  <div class="clothSystem">
      <div class="container">
          <!-- 公用头部 -->
          <!-- <div></div> -->
          <div>
              <div>
                  <div>WTC-FOOD系统</div>
                  <div>
                      <div>
                          <div>强大灵活的数据采集</div>
                          <div>流程信息追溯</div>
                          <div>信用安全背书</div>
                          <div>食品安全保障</div>
                      </div>
                  </div>
              </div>
              <div>
                  <div>案例展示</div>
                  <div>
                      <div></div>
                      <div>
                          <div>WTC-FOOD系统，以物联网和区块链技术为核心</div>
                          <div>结合移动互联、云计算、大数据等多重科技，打造了食品安全生产和流通数据的物联网采集、自动上链、全球分布管理 等溯源保真体系。</div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
  </div>
</template>

<script>
export default {
    name: 'ClothSystem'
}
</script>