<template>
  <div class="collectSystem">
      <div class="container">
          <!-- 公用头部 -->
          <!-- <div></div> -->
          <div>
              <div>
                  <div>视频采集上链系统</div>
                  <div>
                      <div>
                          <div>视频信息加密</div>
                          <div>指纹信息上链</div>
                          <div>链上信息快速调用</div>
                          <div>信息比对验真</div>
                      </div>
                  </div>
              </div>
              <div>
                  <div>案例展示</div>
                  <div>
                      <p>
                          视频采集上链系统分为数据端、系统端和应用端。
                      </p>
                      <p>
                          数据端主要完成视频采集工作。在摄像头终端安装视频采集器，将视频收集至指定云端服务器；
                      </p>
                      <p>
                          而系统端则分为服务器、处理器和存储器。处理器按指定时间周期对视频进行分段采集指纹并将其上链，上链信息包括:视频文件名称、摄像头位置、摄像头编号、拍摄时间、视频指纹等；
                      </p>
                      <p>
                          在应用端用户通过中心化系统多维度查询调用相关视频，可实时与链上数据比对视频信息，核验视频的真实性和完整性。
                      </p>
                  </div>
              </div>
          </div>
      </div>
  </div>
</template>

<script>
export default {
    name: 'CollectSystem'
}
</script>