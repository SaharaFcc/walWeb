<template>
  <div class="kirinminer">
    <div class="container">
      <!-- 公用头部 -->
      <!-- <div></div> -->
      <div>
        <div>
          <div>KIRINMINER使用手册</div>
          <div>下载</div>
        </div>
        <div>
          <div>FindMiner</div>
          <div>下载</div>
        </div>
        <div>
          <div>
            <div>产品概述</div>
            <div>产品尺寸</div>
            <div>产品颜色</div>
            <div>产品材质</div>
            <div>产品净重</div>
            <div>产品储存</div>
            <div>网络连接</div>
            <div>平均算力</div>
            <div>噪声值</div>
            <div>指示灯</div>
            <div>按键规格</div>
            <div>供电方式</div>
            <div>储存温度</div>
            <div>工作环境</div>
            <div>附配件</div>
          </div>
          <div>
              <div>规格参数</div>
              <div>275×265.5×44.5mm</div>
              <div>黑色/银色/灰色</div>
              <div>SGCC+喷粉</div>
              <div>2Kg</div>
              <div>云端储存</div>
              <div>1RJ45接口以太网100/10M</div>
              <div>400 MHash/S</div>
              <div>50 dB</div>
              <div>红、绿两色</div>
              <div>2×机械式</div>
              <div>额定电压:110V/220V 额定功率:135W</div>
              <div>-20~60°C</div>
              <div>0~40°C5％~95％RH，无冷凝</div>
              <div>AC电源线*1</div>
          </div>
        </div>
        <div>
            <div>
                <div>硬件配置</div>
                <div>电源</div>
                <div>按键</div>
                <div>接口</div>
                <div>指示灯</div>
                <div>风机</div>
            </div>
            <div>
                <div>规格参数</div>
                <div>AC 三插 接地 250V 10A</div>
                <div>2×机械式（开关键 复位键）</div>
                <div>1×RJ45带灯</div>
                <div>一组2颗</div>
                <div>一组3个</div>
            </div>
        </div>
        <div>
            <div>购买须知</div>
            <div>
                <div>
                    <span>关于售价:</span>首批KIRINMINER限量发售200台，官方包邮全球统一售价:42980元/台，每位用户限购1台。
                </div>
                <div>
                    <span>关于抢购:</span>您可通过官方邮箱（ miner＠ waltonchain.。org）进行抢购，订购邮件需包含正确的姓名、联系电话、收货地址（省、市、区、街道）、邮政编码、付款账户。SMN和GMN需附上可证明身份的WTC钱包地址。4月26日20:00UTC+8）前官方只接收SMN预购订单，4月27日（UTC+8）开始接收GMN预购订单，5月1日开始接收普通用户订单。
                </div>
                <div>
                    <span>关于付款:</span>当您收到官方邮箱（ miner＠ waltonchain.org）抢购成功的回复后，按邮件要求进行测试转账和全额转账，请认准官方唯一收款账号:4000134919100014417（中国工商银行），警惕诈骗。官方以收到订购邮件的先后顺序确认用户是否获得购买资格。如获得购买资格的用户在规定时间内未完成全额付款，则不再继续享有购买资格。用于测试的小金额转账（不超过7元人民币）官方不予退回。
                </div>
                <div>
                    <span>关于发货:</span>KIRINMINER正在生产中，预计将于今年6月按支付顺序陆续发货。
                </div>
            </div>
        </div>
        <div>
            <div>售后服务</div>
            <div>
                <div>
                    <div>一、 KIRINMINER退换货服务</div>
                    <div>
                        <p>
                            自您签收本产品次日起7个自然日内，可以依照如下流程进行退换货:
                        </p>
                        <p>
                          1.因功能性故障或产品质量问题您可联系售后服务中心（miner@waltonchain.org）。经产品部确认属于商品质量问题的，您可选择退换货，并且因此产生的运费由官方承担。  
                        </p>
                        <p>
                            2.自您收到 KIRINMINER后，请您务必开箱验货后再收件。如您发现有任何异常情况的，请及时拍摄照片并联系售后服务中心。
                        </p>
                        <p>
                            3 KIRINMINER不属于日常消费用品，不支持无理由退换货，请您慎重考虑后再进行购买。
                        </p>
                    </div>
                </div>
                <div>
                    <div>二、KRNM|NER三包服务</div>
                    <div>
                        <p>
                           1.自您签收后次日起7日内，如符合 KIRINMINER退换货标准的，您可申请包退服务（退货时您应确保产品无明显使用痕迹、设备无损坏、确保设备已清除数据）。 
                        </p>
                        <p>
                            2.自您签收次日起7日内，如符合 KIRINMINER退换货标准的，您可申请包换服务（换货时您应确保产品无明显使用痕迹、设备无损坏、确保设备已清除数据）。
                        </p>
                        <p>
                            3.自您签收次日起半年内，您可享受 KIRINMINER的包修服务（仅限于性能故障、系统故障、非人为损坏设备故障问题，返修务必清除设备数据）。
                        </p>
                    </div>
                </div>
                <div>
                    <div>三、KIR| NMINER返修注意事项</div>
                    <div>
                        <p>
                            请您务必在返修前重置设备，若因您未能清除全部数据导致您的信息泄露、财产丢失、数据外泄等问题，官方概不负责。
                        </p>
                    </div>
                </div>
            </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Kirinminer",
};
</script>