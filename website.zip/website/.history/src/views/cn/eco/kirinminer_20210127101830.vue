<template>
  <div class="kirinminer">

  </div>
</template>

<script>
export default {
    name: 'Kirinminer'
}
</script>