<template>
  <div class="childChain">
      <div class="container">
          <div>
              <div>
                  
              </div>
              <div></div>
          </div>
      </div>
  </div>
</template>

<script>
export default {
    name: 'ChildChain'
}
</script>