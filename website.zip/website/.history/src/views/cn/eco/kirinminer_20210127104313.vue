<template>
  <div class="kirinminer">
    <div class="container">
      <!-- 公用头部 -->
      <!-- <div></div> -->
      <div>
        <div>
          <div>KIRINMINER使用手册</div>
          <div>下载</div>
        </div>
        <div>
          <div>FindMiner</div>
          <div>下载</div>
        </div>
        <div>
          <div>
            <div>产品概述</div>
            <div>产品尺寸</div>
            <div>产品颜色</div>
            <div>产品材质</div>
            <div>产品净重</div>
            <div>产品储存</div>
            <div>网络连接</div>
            <div>平均算力</div>
            <div>噪声值</div>
            <div>指示灯</div>
            <div>按键规格</div>
            <div>供电方式</div>
            <div>储存温度</div>
            <div>工作环境</div>
            <div>附配件</div>
          </div>
          <div>
              <div>规格参数</div>
              <div>275×265.5×44.5mm</div>
              <div>黑色/银色/灰色</div>
              <div>SGCC+喷粉</div>
              <div>2Kg</div>
              <div>云端储存</div>
              <div>1RJ45接口以太网100/10M</div>
              <div>400 MHash/S</div>
              <div>50 dB</div>
              <div>红、绿两色</div>
              <div>2×机械式</div>
              <div>额定电压:110V/220V 额定功率:135W</div>
              <div>-20~60°C</div>
              <div>0~40°C5％~95％RH，无冷凝</div>
              <div>AC电源线*1</div>
          </div>
        </div>
        <div>
            <div>
                <div>硬件配置</div>
                <div>电源</div>
                <div>按键</div>
                <div>接口</div>
                <div>指示灯</div>
                <div>风机</div>
            </div>
            <div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Kirinminer",
};
</script>