<template>
  <div class="kirinminer">
    <div class="container"></div>
  </div>
</template>

<script>
export default {
  name: "Kirinminer",
};
</script>