<template>
  <div class="preMiner"></div>
</template>

<script>
export default {
    name: 'PreMiner'
}
</script>