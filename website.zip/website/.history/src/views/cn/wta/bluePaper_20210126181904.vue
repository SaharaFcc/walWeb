<template>
  <div class="bluePaper">

  </div>
</template>

<script>
export default {
    name: 'BluePaper'
}
</script>