<template>
  <div class="bluePaper">
    <div class="container">
      <!-- 公用头部 -->
      <!-- <div></div> -->
    </div>
  </div>
</template>

<script>
export default {
  name: "BluePaper",
};
</script>