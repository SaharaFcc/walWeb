<template>
  <div class="cn cn-container">
      <router-view/>
  </div>
</template>

<script>
export default {
    name: 'Cn'
}
</script>