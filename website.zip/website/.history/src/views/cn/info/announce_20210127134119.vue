<template>
  <div class="announce"></div>
</template>

<script>
export default {
    name: 'Announce'
}
</script>