<template>
  <div class="news"></div>
</template>

<script>
export default {
    name: 'News'
}
</script>

<style>

</style>