<template>
  <div class="activity">
      <div class="container">
          
      </div>
  </div>
</template>

<script>
export default {
    name: 'Activity'
}
</script>