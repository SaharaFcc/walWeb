<template>
  <div class="announce"></div>
</template>

<script>
export default {

}
</script>

<style>

</style>