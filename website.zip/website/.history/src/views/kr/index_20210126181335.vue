<template>
  <div class="kr kr-container">
      <router-view/>
  </div>
</template>

<script>
export default {
    name: 'Kr'
}   
</script>