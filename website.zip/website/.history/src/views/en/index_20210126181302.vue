<template>
  <div class="en en-container">
      <router-view/>
  </div>
</template>

<script>
export default {
    name: 'En'
}
</script>