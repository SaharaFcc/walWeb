import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('@/views/About.vue')
  },
  {
    path: '/about',
    name: 'About',
    component: () => import('@/views/About.vue')
  },
  {
    path: '/cn',
    component: () => import('@/views/cn/index.vue'),
    children: [
      {
        path: 'wta/bluePaper',
        name: 'BluePaper',
        component: () => import('@/views/cn/wta/bluePaper.vue'),
      },
      {
        path: 'solution/traceSystem',
        name: 'TraceSystem',
        component: () => import('@/views/cn/solution/traceSystem.vue'),
      },
      {
        path: 'solution/collectSystem',
        name: 'CollectSystem',
        component: () => import('@/views/cn/solution/collectSystem.vue'),
      },
      {
        path: 'solution/insureSystem',
        name: 'InsureSystem',
        component: () => import('@/views/cn/solution/insureSystem.vue'),
      },
      {
        path: 'solution/agricultureSystem',
        name: 'AgricultureSystem',
        component: () => import('@/views/cn/solution/agricultureSystem.vue'),
      },
      {
        path: 'solution/clothSystem',
        name: 'ClothSystem',
        component: () => import('@/views/cn/solution/clothSystem.vue'),
      },
      {
        path: 'eco/kirinminer',
        name: 'Kirinminer',
        component: () => import('@/views/cn/eco/kirinminer.vue'),
      },
      {
        path: 'eco/smn',
        name: 'Smn',
        component: () => import('@/views/cn/eco/smn.vue'),
      },
      {
        path: 'eco/childChain',
        name: 'ChildChain',
        component: () => import('@/views/cn/eco/childChain.vue'),
      },
      {
        path: 'info/news',
        name: 'News',
        component: () => import('@/views/cn/info/news.vue')
      },
      {
        path: 'info/activity',
        name: 'Activity',
        component: () => import('@/views/cn/info/activity.vue')
      },
      {
        path: 'info/announce',
        name: 'Announce',
        component: () => import('@/views/cn/info/announce.vue')
      },
      {
        path: 'whitePaper',
        name: 'WhitePaper',
        component: () => import('@/views/cn/whitePaper/index.vue')
      },
      {
        path: 'communite',
        name: 'Communite',
        component: () => import('@/views/cn/communite/index.vue')
      },
      {
        path: 'wtc/tokenSwap',
        name: 'TokenSwap',
        component: () => import('@/views/cn/wtc/tokenSwap.vue')
      },
      {
        path: 'wtc/wallet',
        name: 'Wallet',
        component: () => import('@/views/cn/wtc/wallet.vue')
      },
      {
        path: 'wtc/bambooWallet',
        name: 'BambooWallet',
        component: () => import('@/views/cn/wtc/bambooWallet.vue')
      },
      {
        path: 'wtc/exchange',
        name: 'Exchange',
        component: () => import('@/views/cn/wtc/exchange.vue')
      }
    ]
  },
  {
    path: '/en',
    component: () => import('@/views/en/index.vue'),
    children: []
  },
  {
    path: '/kr',
    component: () => import('@/views/kr/index.vue'),
    children: []
  }
]

const router = new VueRouter({
  routes
})

export default router
