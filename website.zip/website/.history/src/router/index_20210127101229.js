import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('@/views/About.vue')
  },
  {
    path: '/about',
    name: 'About',
    component: () => import('@/views/About.vue')
  },
  {
    path: '/cn',
    component: () => import('@/views/cn/index.vue'),
    children: [
      // {
      //   path: 'wta/bluePaper',
      //   name: 'BluePaper',
      //   component: () => import('@/views/cn/wta/bluePaper.vue'),
      // },
      // {
      //   path: 'solution/traceSystem',
      //   name: 'TraceSystem',
      //   component: () => import('@/views/cn/solution/traceSystem.vue'),
      // }
      {
        path: 'wta',
        children: [
          {
            path: 'bluePaper',
            name: 'BluePaper',
            component: () => import('@/views/cn/wta/bluePaper.vue'),
          }
        ]
      }
    ]
  },
  {
    path: '/en',
    component: () => import('@/views/en/index.vue'),
    children: []
  },
  {
    path: '/kr',
    component: () => import('@/views/kr/index.vue'),
    children: []
  }
]

const router = new VueRouter({
  routes
})

export default router
