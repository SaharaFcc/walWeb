# 基于Vue做的棋牌游戏，未完...

#### Description
vue-game是通过Vue-cli脚手架生成项目，主要想实现类似斗地主功能
1. 基本游戏桌面布局
2. 发牌
3. 选牌
4. 出牌
5. 要不起
6. 拖动出牌
7. 明牌暗牌
8. 记牌器
9. 炸弹和胜利特性
10. 棋牌规则 （未完成）
11. 地主规则 （未完成）
12. 出牌定时器 （未完成）
13. ... （未完成）


#### Installation

1. 下载本项目
2. 安装依赖包
  npm install
3. 运行
  npm run dev
#### 录屏
![game](https://gitee.com/lindeyi/vue-game/raw/master/static/c.gif)
#### 截图

![game](https://gitee.com/lindeyi/vue-game/raw/master/static/game1.png)
![game](https://gitee.com/lindeyi/vue-game/raw/master/static/game2.png)
![game](https://gitee.com/lindeyi/vue-game/raw/master/static/game3.png)
![game](https://gitee.com/lindeyi/vue-game/raw/master/static/game4.png)
