<template>
  <div class="communite">
    <div class="communite-head">
      <div>Communities</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span class="currentRoute">Communities</span>
        </div>
      </div>
    </div>
    <div class="communite-content">
      <div class="container">
        <div>
          <img src="@/assets/images/communite/img_1.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_2.png" alt="" />
          <img src="@/assets/images/communite/img_3.png" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_4.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_5.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_6.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_7.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_8.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_9.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_10.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_11.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_12.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_13.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_14.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_15.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_16.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_17.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_18.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_19.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_20.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_21.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_22.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_23.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_24.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_25.png" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_26.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_27.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_28.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_29.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_30.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_31.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_32.png" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_33.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_34.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_35.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_36.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/communite/img_37.jpg" alt="" />
        </div>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
export default {
  name: "Communite",
};
</script>
<style lang="scss" scoped>
.communite {
  .communite-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 180px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &:first-of-type {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .communite-content {
    .container {
      padding: 50px 0px;
      & > div {
        &:not(:last-of-type){
          margin-bottom: 50px;
        }
      }
    }
  }
}
</style>