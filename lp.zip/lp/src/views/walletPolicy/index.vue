<template>
  <div class="walletPolicy">
    <div class="walletPolicy-head">
      <div>Waltonchain Wallets Privacy Policy</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span class="currentRoute">Wallets Privacy Policy</span>
        </div>
      </div>
    </div>
    <div class="walletPolicy-content">
      <div class="container">
        <p>Dear Users,</p>
        <p>
          Walton Chain (HK) Development Co., Ltd. (“Walton Chain (HK)
          Development” or “we”) respects and protects the privacy of Users
          (“you” or “Users”). Walton Chain (HK) Development will collect and use
          your Personal Information, generated from your use of Waltonchain
          wallets, in accordance with this Privacy Policy (“Policy”).
        </p>
        <p>
          Walton Chain (HK) Development recommends that you carefully read and
          understand the contents of this Policy before your use of the product
          (“Waltonchain wallets”). Additionally, significant information
          including the Disclaimer is in bold form in this Policy. Definitions
          of key terms in this Policy are consistent with those in the
          Waltonchain wallets Terms of Service of Walton Chain (HK) Development.
        </p>
        <p>
          Walton Chain (HK) Development reserves the right to update this Policy
          online from time to time, and the new policy will immediately replace
          the previous one once posted.
        </p>
        <p>
          You acknowledge and accept that this Policy and other relevant rules
          apply to Waltonchain wallets.
        </p>
        <div>
          <div class="content-title font-weight-bold">
            1. Information We Collect
          </div>
          <p>
            We collect your information in order to provide the services you
            request on the Site, and we value the protection of your privacy. We
            strictly abide by the principle of “lawful, justifiable and
            necessary” during our collection of your information. You
            acknowledge that, if you do not provide us with all information we
            request, your user experiences on Waltonchain wallets may be
            adversely affected.
          </p>
          <p>
            1.1 We may collect your personal information, including but not
            limited to your mobile device information, operating records,
            transaction records and wallet addresses.
          </p>
          <p>
            1.2 In order to satisfy your needs for specific services, we may
            collect your name, bank card number, telephone number, email
            address, etc.
          </p>
          <p>
            1.3 You agree and understand that your Wallet Password, Private Key,
            Mnemonic Words, and Keystore on Waltonchain wallets are not stored
            or synchronized on Walton Chain (HK) Development’s servers. Walton
            Chain (HK) Development does not offer any services to restore your
            Wallet Password, Private Key, Mnemonic Words or Keystore. You will
            have sole responsibility and control over these items, and Walton
            Chain (HK) Development disclaims all liability for the safety,
            storage, control, or use of these items.
          </p>
          <p>
            1.4 Apart from the foregoing provisions, when you are using specific
            functions of Waltonchain wallets, we may request additional personal
            information. Your objection to providing such additional information
            will be deemed as your election not to use that specific function of
            Waltonchain wallets.
          </p>
          <p>
            1.5 In the event you use any third-party-developed applications on
            the Waltonchain wallets platform, your personal information will be
            collected and held by the third-party-developed applications instead
            of being collected and stored by Waltonchain wallets. It is your
            responsibility to become familiar with such third-party-developed
            applications’ privacy policies and personal information storage and
            safekeeping terms before you use any such applications. Walton Chain
            (HK) Development shall have no liability or obligation of any kind
            to you for the actions or policies of such third-party-developed
            applications.
          </p>
          <p>
            1.6 To the extent permitted by laws and regulations, Walton Chain
            (HK) Development may collect and use following personal information
            without your prior consent or authorization:
          </p>
          <p>
            a. information related to national security and national defense;
          </p>
          <p>
            b. information related to public security, public health,
            significant public interests;
          </p>
          <p>
            c. information related to criminal investigation, prosecution, trial
            and enforcement;
          </p>
          <p>d. any personal information collected is publicized by you;</p>
          <p>
            e. the personal information is collected from legally publicly
            disclosed information, such as news reports, government information
            disclosure and other channels;
          </p>
          <p>
            f. the personal information is necessary to maintain the security
            and compliance of services, such as to detect or to solve the
            malfunction of products and services;
          </p>
          <p>g. other circumstances prescribed by laws and regulations.</p>
          <p>1.7 We collect information in the following ways:</p>
          <p>
            a. We automatically collect and store your general internet usage
            information as and when you use our platform (including your IP
            address, browsing habits, click patterns, version of software
            installed, device type, system type, screen resolutions, plug-ins,
            language settings, the content and pages that you access in the
            Waltonchain wallets, the dates and times that you visit, paths
            taken, and time spent on pages within the Waltonchain wallets),
            using various types of tracking technology we send to your device,
            including cookies and web beacons. The use of cookies (being small
            text files containing a string of alphanumeric characters), is
            standard and many major websites, mobile sites and mobile
            applications use them. Web beacons (being electronic image requests
            also known as “single-pixel gif” requests) allow us to count page
            views and to access cookies. These can take the form of any
            electronic image viewed as part of a web page (typically 1-by-1
            pixel files) and/or in HTML-formatted broadcasts that we send to
            opt-in subscribers in order to count how many people opened and read
            the broadcast. Our web beacons do not collect, gather, monitor or
            share any personally identifiable information. They are just the
            technique we use to compile anonymous information about the
            Waltonchain wallet and your service usage.
          </p>
          <p>
            b. we may collect information during your use of Waltonchain
            wallets, including your mobile device’s information, location, and
            your operating records on Waltonchain wallets.
          </p>
          <p>
            c. we retain all or part of your transaction records on the
            blockchain. However, Users shall refer to the blockchain ledger for
            the latest transaction records.
          </p>
        </div>
        <div>
          <div class="content-title font-weight-bold">
            2. How We Use Your Information
          </div>
          <p>
            2.1 We may use your usage details described above to: (a)
            automatically provide you with the latest version of the Waltonchain
            wallets on your device; (b) remember your information so that you
            will not have to re-enter it during your visit or the next time you
            access the Waltonchain wallets; (c) monitor aggregate Waltonchain
            wallets usage metrics such as total number of visitors and
            pages/services accessed; and (d) track your entries, submissions,
            and status in any purchases or other activities in connection with
            your usage of the Waltonchain wallets.
          </p>
          <p>
            2.2 We may promptly push important notifications to you, such as
            software update(s), update of Terms of Service and this Policy.
          </p>
          <p>
            2.3 We store your feedback by using the wallet address and the
            mobile device information provided by you.
          </p>
          <p>
            2.4 We may collect your personal information to conduct an internal
            audit, data analysis and research to enhance our services.
          </p>
          <p>
            2.5 According to Waltonchain wallets Terms of Use and other rules of
            Walton Chain (HK) Development, Walton Chain (HK) Development may
            manage and track the use behaviors of Users through Users’ personal
            information.
          </p>
          <p>
            2.6 We may use your personal information in accordance with our
            jurisdiction’s laws, regulations and to cooperate with regulatory
            authorities. We are not responsible for compliance with your
            jurisdiction’s laws with respect to data storage, safe-keeping, and
            use.
          </p>
          <p>
            2.7 You may voluntarily provide additional information to us from
            time to time, such as demographic information or information related
            to your favorite social networking site, or your participation in
            competitions, promotions, surveys, and/or additional services. You
            may do this if you decide to upload or download certain content
            from/to the Waltonchain wallets, enter competitions, take advantage
            of promotions, respond to surveys, register and subscribe for
            certain additional services, or otherwise use the optional features
            and functionality of the Waltonchain wallets. We may use such
            optional details provided by you for such purposes as indicated to
            you at the time you agree to provide such optional details
          </p>
        </div>
        <div>
          <div class="content-title font-weight-bold">
            3. How You Control Your Own Information
          </div>
          <p>
            You are entitled to control the personal information provided to
            Waltonchain wallets:
          </p>
          <p>
            3.1 You may send or receive coins and tokens, transfer and collect
            tokens by clicking the “Send” and “Receive” buttons.
          </p>
          <p>
            3.2 You understand that you may initiate the following operations in
            the “Profile” column in WTCwallet:
          </p>
          <p>
            a. in the “Contacts” column, you may view and edit your “Contacts”;
          </p>
          <p>
            b. in the “Profile” column, you do not have to provide your name,
            telephone number, bank card number information. But if you wish to
            use specific services, you may need to provide such information;
          </p>
          <p>
            3.3 When we collect information from you for a specific purpose, we
            will ask for your consent in advance, which you are entitled to
            refuse. However, you understand that when you refuse to give such
            consent, you also give up the choice to use specific services
            provided by Waltonchain wallets.
          </p>
          <p>
            3.4 You acknowledge that since the blockchain ledger is an open
            source system, all your transaction records are automatically public
            and transparent on the open blockchain.
          </p>
          <p>
            3.5 You understand that after you click any link to the
            third-party-developed apps from Waltonchain wallets, the Waltonchain
            wallets Terms of Use and Waltonchain wallets Privacy Policy will no
            longer apply. You are encouraged to carefully review the privacy
            policies and related terms of service documents before your use of
            such the third-party-developed apps.
          </p>
          <p>
            3.6 You are entitled to request that we update, revise, and delete
            your relevant personal information, and we shall comply with such
            request unless such action would be in violation of applicable laws
            to which we are subject, in which case we may or may not inform you
            that we are unable to comply with your request.
          </p>
        </div>
        <div>
          <div class="content-title font-weight-bold">
            4. Information We May Share or Transfer
          </div>
          <p>
            4.1 The personal information collected and generated by Walton Chain
            (HK) Development during our operations shall be stored within the
            territory of the People’s Republic of China (PRC). If we decide, in
            our sole discretion, to transfer your personal Information abroad,
            we shall obtain your prior consent and conduct the cross-border data
            transfer in accordance with all laws, regulations and policies of
            the receiving jurisdiction, as well as undertake our present
            confidentiality obligations to protect your personal information.
          </p>
          <p>
            4.2 Walton Chain (HK) Development will not share with or transfer
            your personal information to any third party without your prior
            consent, except for the following circumstances:
          </p>
          <p>
            a. you have expressly provided your prior consent or authorization;
          </p>
          <p>b. the collected personal information is publicized by you;</p>
          <p>
            c. the personal information is collected from public information
            which had been lawfully disclosed, such as news, government
            information disclosure, and any other lawful channels;
          </p>
          <p>
            d. we may share your personal information with our affiliates only
            when necessary and to the extent permitted by this Policy;
          </p>
          <p>
            e. in order to comply with applicable laws, regulations, legal
            processes, and administrative or judicial authorities;
          </p>
          <p>
            f. in the event of merger or acquisition, if the transfer of
            personal information is involved, Walton Chain (HK) Development
            shall do its utmost to require the acquiring party to continue to be
            bound by this Policy or a policy which is similar in scope and
            spirit.
          </p>
        </div>
        <div>
          <div class="content-title font-weight-bold">
            5. How We Protect Your Information
          </div>
          <p>
            5.1 By accepting this Policy, you consent to our collection,
            storage, processing and disclosure of your personal information as
            described in this Policy. Should you terminate your registration
            with us for any reason, you consent to our retention of the
            information we have already collected from you for record-keeping
            purposes only, for an indefinite period.
          </p>
          <p>
            5.2 To protect your personal information, Walton Chain (HK)
            Development may adopt data security techniques, improve internal
            compliance levels, provide security training for our staff, and set
            security authority for access to relevant data to protect your
            personal information.
          </p>
          <p>
            5.3 We will not sell or rent any of your personal information to
            third parties for their marketing purposes and only share your
            personal information with third parties as described in this Policy.
          </p>
        </div>
        <div>
          <div class="content-title font-weight-bold">
            6. Protection for the Minors
          </div>
          <p>
            The following special provisions apply to minors who are under the
            age of 18 years old:
          </p>
          <p>
            6.1 Minors shall not use Waltonchain wallets without guidance from
            their parents or guardians.
          </p>
          <p>
            6.2 Parents and guardians of minors shall provide guidance to such
            minors on using Waltonchain wallets after they read this Policy,
            Waltonchain wallets Terms of Use and other relevant documents.
          </p>
          <p>
            6.3 Waltonchain wallets will ensure the confidentiality and security
            of the minors’ personal information in accordance with PRC laws and
            regulations.
          </p>
        </div>
        <div>
          <div class="content-title font-weight-bold">7. Disclaimer</div>
          <p>
            7.1 After you click on any third-party-developed apps from
            Waltonchain wallets, the privacy policies of the
            third-party-developed apps will apply. The collection and use of
            your personal information by the third-party-developed apps will be
            controlled neither by Walton Chain (HK) Development, nor by this
            Policy. Walton Chain (HK) Development is unable to guarantee that
            the third-party-developed apps will take any personal information
            protection measures to secure personal information and guard against
            data breaches; therefore, it your obligation to review each such
            third-party-developed apps’ privacy policy to decide whether you
            wish to continue your use of such apps.
          </p>
          <p>
            7.2 You shall carefully select and use the third-party-developed
            apps and protect your Personal Information. Walton Chain (HK)
            Development shall not be held liable for the privacy protection
            obligations of any third-party-developed apps and you assume full
            responsibility for your use of such Apps.
          </p>
          <p>
            7.3 YOU ACKNOWLEDGE AND ACCEPT THAT, TO THE MAXIMUM EXTENT PERMITTED
            BY APPLICABLE LAW, Walton Chain (HK) Development WILL ADOPT MEASURES
            AS REASONABLE AS POSSIBLE TO PROTECT YOUR PERSONAL INFORMATION UNDER
            CURRENT TECHNIQUES ON AN “AS IS”, “AS AVAILABLE” AND “WITH ALL
            FAULTS” BASIS, TO AVOID THE DISCLOSURE, TAMPERING OR DAMAGING YOUR
            PERSONAL INFORMATION. SINCE Walton Chain (HK) Development TRANSFERS
            DATA WIRELESSLY, Walton Chain (HK) Development MAKES NO GUARANTEE ON
            THE PRIVACY AND SECURITY OF WIRELESS INTERNET DATA TRANSFERS.
          </p>
        </div>
        <div>
          <div class="content-title font-weight-bold">8. Miscellaneous</div>
          <p>
            8.1 If you are a User outside of PRC, you fully understand and
            conform to the laws, regulations and rules in your jurisdiction that
            are relevant to your use of Walton Chain (HK) Development and
            Waltonchain wallets.
          </p>
          <p>
            8.2 Throughout the term of your use of Walton Chain (HK) Development
            services or Waltonchain wallets, if you come across any issues
            related to the use of your Personal Information, then you may
            contact us and submit your comment through the Site.
          </p>
          <p>
            8.3 We encourage you to check the Terms of Service and Privacy
            Policy of Walton Chain (HK) Development each time you log onto
            Waltonchain wallets.
          </p>
          <p>8.4 This English version is the only version of this Policy.</p>
          <p>
            8.5 As for any issues not covered in this Policy, you shall comply
            with the announcements and relevant rules as updated by Walton Chain
            (HK) Development from time to time.
          </p>
        </div>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
export default {
  name: "WalletPolicy",
};
</script>
<style lang="scss" scoped>
.walletPolicy {
  .walletPolicy-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 180px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &:first-of-type {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .walletPolicy-content {
    .container {
      font-size: 14px;
      padding: 80px 0px;
      .content-title {
        font-size: 14px;
        color: #555;
        margin-bottom: 5px;
      }
    }
  }
}
</style>