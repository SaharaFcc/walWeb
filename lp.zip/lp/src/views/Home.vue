<template>
  <div class="home">
    <div class="button-mouse">
      <div class="scroll"></div>
    </div>
    <full-page :options="options" ref="fullpage" id="fullpage">
      <div
        class="section position-relative"
        v-lazy:background-image="{
          src:
            'http://www.waltonchain.org/en/Uploads/2018-12-20/5c1b6c49a27e9.gif',
        }"
      >
        <div class="navs">
          <div class="container d-flex justify-content-between">
            <div>
              <a href="">
                <img
                  v-lazy="
                    'http://www.waltonchain.org/en/Uploads/2018-12-10/5c0e0ffa1f302.png'
                  "
                  :key="'http://www.waltonchain.org/en/Uploads/2018-12-10/5c0e0ffa1f302.png'"
                />
              </a>
            </div>
            <div class="d-flex">
              <div>WTA (Blue Paper)</div>
              <div>SOLUTIONS</div>
              <div>ECOSYSTEM</div>
              <div>INFO</div>
              <div>WHITE PAPER</div>
              <div>COMMUNITIES</div>
              <div>WTC</div>
              <div>中文</div>
            </div>
          </div>
        </div>
        <div class="font-weight-bold text-center position-absolute">
          <span>The Global Leader in</span><br />
          <span>Blockchain + IoT</span>
        </div>
      </div>
      <div class="section position-relative">
        <div class="nav-humber">
          <div class="container d-flex justify-content-between">
            <div>About Waltonchain</div>
            <div></div>
          </div>
        </div>
        <div class="position-absolute">
          <div
            class="container d-flex justify-content-between align-items-center"
          >
            <div class="prevPage">
              <span class="link">上一页</span>
              <span class="name"></span>
              <span class="index">01</span>
              /
              <span class="total">06</span>
            </div>
            <div>
              <p class="font-weight-bold">
                Waltonchain: Leading humanity to a reliable digital life.
              </p>
              <p>
                Waltonchain project is named after Charles Walton (1921—2011),
                the famous inventor of RFID technology.
                <br />
                <br />
                Waltonchain is the underlying public business ecochain. It
                resorts to RFID technology to create a unique combination of
                blockchain and the Internet of Things (IoT). On this ecochain,
                merchants can create customized child chains and monitor
                production, logistics, warehousing and retail circulation of all
                commodities. As a business ecochain, Waltonchain ensures that
                all data on it is authentic and credible. With the
                self-developed reader chip and tag chip, all data of physical
                commodities in circulation is automatically recorded to
                blockchain. Thus Waltonchain avoids human interference,
                minimizes the data tampering possibility and creates a fair,
                transparent, traceable and credible new-generation business
                ecosystem.
              </p>
            </div>
            <div class="nextPage">
              <span class="index">03</span>
              /
              <span class="total">06</span>
              <span class="name">Core Advantages</span>
              <span class="link">下一页</span>
            </div>
          </div>
        </div>
        <!-- <point-wave :num="1" /> -->
      </div>
      <div class="section position-relative">
        <div class="nav-humber">
          <div class="container d-flex justify-content-between">
            <div>Core Advantages</div>
            <div></div>
          </div>
        </div>
        <div class="position-absolute">
          <div
            class="container d-flex justify-content-between align-items-center"
          >
            <div class="prevPage">
              <span class="link">上一页</span>
              <span class="name">About Waltonchain</span>
              <span class="index">02</span>
              /
              <span class="total">06</span>
            </div>
            <div>
              <svg-icon iconClass="app" className="app"/>
            </div>
            <div class="nextPage">
              <span class="index">04</span>
              /
              <span class="total">06</span>
              <span class="name">Project Planning</span>
              <span class="link">下一页</span>
            </div>
          </div>
        </div>
        <!-- <point-wave :num="2" /> -->
      </div>
      <div class="section position-relative">
        <div class="nav-humber">
          <div class="container d-flex justify-content-between">
            <div>Project Planning</div>
            <div></div>
          </div>
        </div>
        <div class="position-absolute">
          <div
            class="container d-flex justify-content-between align-items-center"
          >
            <div class="prevPage">
              <span class="link">上一页</span>
              <span class="name">Core Advantages</span>
              <span class="index">03</span>
              /
              <span class="total">06</span>
            </div>
            <div>
              <p class="font-weight-bold">
                Waltonchain: Leading humanity to a reliable digital life.
              </p>
              <p>
                Waltonchain project is named after Charles Walton (1921—2011),
                the famous inventor of RFID technology.
                <br />
                <br />
                Waltonchain is the underlying public business ecochain. It
                resorts to RFID technology to create a unique combination of
                blockchain and the Internet of Things (IoT). On this ecochain,
                merchants can create customized child chains and monitor
                production, logistics, warehousing and retail circulation of all
                commodities. As a business ecochain, Waltonchain ensures that
                all data on it is authentic and credible. With the
                self-developed reader chip and tag chip, all data of physical
                commodities in circulation is automatically recorded to
                blockchain. Thus Waltonchain avoids human interference,
                minimizes the data tampering possibility and creates a fair,
                transparent, traceable and credible new-generation business
                ecosystem.
              </p>
            </div>
            <div class="nextPage">
              <span class="index">05</span>
              /
              <span class="total">06</span>
              <span class="name">Partners</span>
              <span class="link">下一页</span>
            </div>
          </div>
        </div>
        <!-- <point-wave :num="3" /> -->
      </div>
      <div class="section position-relative">
        <div class="nav-humber">
          <div class="container d-flex justify-content-between">
            <div>Partners</div>
            <div></div>
          </div>
        </div>
        <div class="position-absolute">
          <div
            class="container d-flex justify-content-between align-items-center"
          >
            <div class="prevPage">
              <span class="link">上一页</span>
              <span class="name">Project Planning</span>
              <span class="index">04</span>
              /
              <span class="total">06</span>
            </div>
            <div>
              <p class="font-weight-bold">
                Waltonchain: Leading humanity to a reliable digital life.
              </p>
              <p>
                Waltonchain project is named after Charles Walton (1921—2011),
                the famous inventor of RFID technology.
                <br />
                <br />
                Waltonchain is the underlying public business ecochain. It
                resorts to RFID technology to create a unique combination of
                blockchain and the Internet of Things (IoT). On this ecochain,
                merchants can create customized child chains and monitor
                production, logistics, warehousing and retail circulation of all
                commodities. As a business ecochain, Waltonchain ensures that
                all data on it is authentic and credible. With the
                self-developed reader chip and tag chip, all data of physical
                commodities in circulation is automatically recorded to
                blockchain. Thus Waltonchain avoids human interference,
                minimizes the data tampering possibility and creates a fair,
                transparent, traceable and credible new-generation business
                ecosystem.
              </p>
            </div>
            <div class="nextPage">
              <span class="index">06</span>
              /
              <span class="total">06</span>
              <span class="name">Contact Us</span>
              <span class="link">下一页</span>
            </div>
          </div>
        </div>
        <!-- <point-wave :num="4" /> -->
      </div>
      <div class="section position-relative">
        <div class="nav-humber">
          <div class="container d-flex justify-content-between">
            <div>Contact Us</div>
            <div></div>
          </div>
        </div>
        <div class="position-absolute">
          <div
            class="container d-flex justify-content-between align-items-center"
          >
            <div class="prevPage">
              <span class="link">上一页</span>
              <span class="name">Partners</span>
              <span class="index">05</span>
              /
              <span class="total">06</span>
            </div>
            <div>
              <p class="font-weight-bold">
                Waltonchain: Leading humanity to a reliable digital life.
              </p>
              <p>
                Waltonchain project is named after Charles Walton (1921—2011),
                the famous inventor of RFID technology.
                <br />
                <br />
                Waltonchain is the underlying public business ecochain. It
                resorts to RFID technology to create a unique combination of
                blockchain and the Internet of Things (IoT). On this ecochain,
                merchants can create customized child chains and monitor
                production, logistics, warehousing and retail circulation of all
                commodities. As a business ecochain, Waltonchain ensures that
                all data on it is authentic and credible. With the
                self-developed reader chip and tag chip, all data of physical
                commodities in circulation is automatically recorded to
                blockchain. Thus Waltonchain avoids human interference,
                minimizes the data tampering possibility and creates a fair,
                transparent, traceable and credible new-generation business
                ecosystem.
              </p>
            </div>
            <div class="nextPage"></div>
          </div>
        </div>
        <!-- <point-wave :num="5" /> -->
      </div>
    </full-page>
  </div>
</template>
<script>
import PointWave from "@/components/PointWave/index.vue";
export default {
  name: "Home",
  components: {
    PointWave,
  },
  data() {
    return {
      options: {
        licenseKey: "OPEN-SOURCE-GPLV3-LICENSE",
        afterLoad: this.afterLoad,
      }
    };
  },
  methods: {
    gotolastpage() {
      fullpage_api.moveTo("page3", 1);
    },
    afterLoad(anchorLink, index) {
      console.log("index:", index);
    },
    next() {
      // 向下滚动一页
      this.$refs.fullpage.api.moveSectionDown();
    },
  },
};
</script>
<style lang="scss" scoped>
.home {
  #fullpage {
    .section {
      background-color: #100619;
      background-size: cover;
      .container {
        max-width: 1640px;
      }
      .navs {
        color: #fff;
        font-size: 16px;
        letter-spacing: 1px;
        .container {
          & > div {
            &:last-of-type {
              div {
                padding: 62px 20px 52px;
              }
            }
          }
        }
        & + div {
          font-size: 80px;
          line-height: 100px;
          color: #fff;
          letter-spacing: 5px;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
        }
      }
      .nav-humber {
        color: #fff;
        font-size: 36px;
        height: 140px;
        line-height: 140px;
        border-bottom: 1px solid rgba(153, 153, 153, 0.23);
        & + div {
          color: #fff;
          width: 100%;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          .container {
            & > div {
              &:nth-of-type(2) {
                max-width: 580px;
              }
              span {
                &.total {
                  padding: 0px 5px;
                }
                &.index {
                  padding: 0px 5px;
                  color: #8200ff;
                }
                &.name {
                  padding: 0px 12px;
                }
              }
            }
          }
        }
      }
      &:nth-of-type(2) {
        .nav-humber {
          & + div {
            .container {
              & > div {
                &:nth-of-type(2) {
                  p {
                    &:first-of-type {
                      font-size: 24px;
                      letter-spacing: 2px;
                      margin-bottom: 40px;
                    }
                    &:last-of-type {
                      font-size: 14px;
                      line-height: 1.8;
                      margin-bottom: 70px;
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  .button-mouse {
    position: absolute;
    width: 30px;
    height: 42px;
    bottom: 60px;
    left: 50%;
    margin-left: -12px;
    border-radius: 15px;
    border: 2px solid rgba(255, 255, 255, 0.5);
    animation: intro 1s;
    z-index: 99;
    .scroll {
      display: block;
      width: 3px;
      height: 8px;
      margin: 6px auto;
      border-radius: 4px;
      background: rgba(255, 255, 255, 0.5);
      animation: finger 1.2s infinite;
      z-index: 99;
    }
  }
  @keyframes intro {
    0% {
      opacity: 0;
      transform: translateY(40px);
    }
    100% {
      opacity: 1;
      transform: translateY(0);
    }
  }
  @keyframes finger {
    0% {
      opacity: 1;
    }
    100% {
      opacity: 0;
      transform: translateY(20px);
    }
  }
}
</style>