<template>
  <div class="announce"></div>
</template>

<script>
export default {
  name: "Announce",
};
</script>
<style lang="scss" scoped>
.announce {
}
</style>