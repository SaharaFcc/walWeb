<template>
  <div class="collectSystem">
    <div class="collectSystem-head">
      <div>Blockchain + Cloud Video Collection System</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span class="currentRoute">Blockchain + Cloud</span>
        </div>
      </div>
    </div>
    <common-nav :navList="navList" :pageType="1" pageName="collectSystem" />
    <div class="collectSystem-content">
      <div class="introduction" id="introduction">
        <div class="container">
          <div class="content-title">
            Blockchain + Cloud Video Collection System
          </div>
          <div>
            <div
              class="introduction-cells justify-content-between d-flex flex-wrap"
            >
              <div>Blockchain + Cloud</div>
            </div>
            <div class="d-flex justify-content-center">
              <img
                src="@/assets/images/solution/collectSystem/img_introduction.png"
                alt=""
              />
            </div>
          </div>
        </div>
      </div>
      <div class="presentation" id="presentation">
        <div class="container">
          <div class="content-title">Case Presentation</div>
          <p>
            · Blockchain Video Collection System includes Data End, System End
            and Application End.
          </p>
          <p>
            · Data end collects video. Camera terminals feature video collection
            devices connected to a cloud server.
          </p>
          <p>
            · System End includes servers, processors and storage. Processors
            segment videos, collect stamps and upload to blockchain at specified
            time periods. The information uploaded to blockchain includes: video
            file name, camera location, camera No., shooting time, video
            fingerprint, etc.
          </p>
          <p>
            · In the application end, users can query related videos by multiple
            parameters on a centralized system, compare video information with
            on-chain data instantly for authenticity and integrity
          </p>
          <p>
            Blockchain + Cloud Architecture can accelerate construction of
            campus/city monitoring system, improve district security work and
            reduce information authenticity disputes of completely centralized
            systems
          </p>
        </div>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
import CommonNav from "@/components/common/CommonNav.vue";
export default {
  components: {
    CommonNav,
  },
  name: "CollectSystem",
  data() {
    return {
      navList: [
        {
          name: "System Introduction",
          id: "introduction",
        },
        {
          name: "Case Presentation",
          id: "presentation",
        },
      ],
    };
  },
};
</script>
<style lang="scss" scoped>
.collectSystem {
  .collectSystem-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 180px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &:first-of-type {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .commonNav {
    /deep/ .nav {
      background: url("../../../assets/images/common/bg_nav.jpg") no-repeat;
      background-size: cover;
      box-shadow: 2.5px 4.33px 13px 0px rgba(0, 0, 0, 0.24);
      height: 170px;
    }
    /deep/ .container.position-relative {
      & > div {
        height: 55px;
      }
      line-height: 55px;
      & > div {
        width: 50%;
      }
    }
  }
  .collectSystem-content {
    & > div {
      .container {
        padding: 0px;
      }
      .content-title {
        font-size: 28px;
        color: #8200ff;
        font-weight: 600;
        margin-bottom: 20px;
      }
      p {
        font-size: 16px;
        color: #555;
        margin-bottom: 30px;
        line-height: 30px;
      }
      padding: 80px 0px;
      &.introduction {
        margin-top: 60px;
        .content-title + div {
          padding: 50px;
          border-radius: 30px;
          overflow: hidden;
          box-shadow: 5.5px 9.526px 59px 0px rgba(0, 0, 0, 0.24);
        }
        .introduction-cells {
          font-size: 14px;
          color: #8200ff;
          & > div {
            width: 510px;
            height: 40px;
            text-align: center;
            line-height: 40px;
            border: 1px solid #8200ff;
            margin-bottom: 10px;
          }
          & + div {
            margin-top: 30px;
          }
        }
      }
      &.presentation {
        padding: 80px 0px;
        background: url("../../../assets/images/solution/traceSystem/bg_presentation.jpg")
          no-repeat;
        background-size: cover;
        .content-title {
          margin-bottom: 60px;
        }
      }
    }
  }
}
</style>