<template>
  <div class="traceSystem">
    <div class="traceSystem-head">
      <div>Liquor/Pharmaceuticals/Oil & Gas Traceability System</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span class="currentRoute">Blockchain + Liquor/Pharmaceuticals</span>
        </div>
      </div>
    </div>
    <common-nav :navList="navList" :pageType="1" pageName="traceSystem"/>
    <div class="traceSystem-content">
      <div class="introduction" id="introduction">
        <div class="container">
          <div class="content-title">
            Liquor/Pharmaceuticals/Oil & Gas Traceability System
          </div>
          <div>
            <div
              class="introduction-cells justify-content-between d-flex flex-wrap"
            >
              <div>Full process monitoring</div>
              <div>On-chain data stamps</div>
              <div>Fast on-chain data calling</div>
              <div>Data comparison for authenticity</div>
            </div>
            <div class="d-flex justify-content-center">
              <img
                src="@/assets/images/solution/traceSystem/img_introduction.jpg"
                alt=""
              />
            </div>
          </div>
        </div>
      </div>
      <div class="presentation" id="presentation">
        <div class="container">
          <div class="content-title">Case Presentation</div>
          <p>
            · The system includes Production Management, Warehousing & Logistics
            and Consumer End of the production flow
          </p>
          <p>
            · Production End: sensors/devices collect production environment
            data (temperature, humidity, process), encrypted data/extracted data
            stamps are uploaded to blockchain and written into the product-bound
            RFID tag
          </p>
          <p>
            · Logistics & Warehousing deploys RFID reader-writers; product
            status at each link is recorded in the back-end management system
            and written into the RFID tag; system data is encrypted and uploaded
            to blockchain regularly
          </p>
          <p>
            · Consumer End: users scan product tags with RFID readers in stores
            to view product information and check authenticity
          </p>
          <p>
            Powerful and flexible data collection, information traceability and
            credit endorsement are beneficial for consumers, enterprises and
            technology development. It has wide application prospects for health
            products, liquor and other industries
          </p>
        </div>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
import CommonNav from "@/components/common/CommonNav.vue";
export default {
  components: {
    CommonNav,
  },
  name: "TraceSystem",
  data() {
    return {
      navList: [
        {
          name: "System Introduction",
          id: "introduction",
        },
        {
          name: "Case Presentation",
          id: "presentation",
        },
      ],
    };
  },
};
</script>
<style lang="scss" scoped>
.traceSystem {
  .traceSystem-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 180px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &:first-of-type {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .commonNav {
    /deep/ .nav {
      background: url("../../../assets/images/common/bg_nav.jpg") no-repeat;
      background-size: cover;
      box-shadow: 2.5px 4.33px 13px 0px rgba(0, 0, 0, 0.24);
      height: 170px;
    }
    /deep/ .container.position-relative {
      & > div {
        height: 55px;
      }
      line-height: 55px;
      & > div {
        width: 50%;
      }
    }
  }
  .traceSystem-content {
    & > div {
      .container {
        padding: 0px;
      }
      .content-title {
        font-size: 28px;
        color: #8200ff;
        font-weight: 600;
        margin-bottom: 20px;
      }
      p {
        font-size: 16px;
        color: #555;
        margin-bottom: 30px;
        line-height: 30px;
      }
      padding: 80px 0px;
      &.introduction {
        margin-top: 60px;
        .content-title + div {
          padding: 50px;
          border-radius: 30px;
          overflow: hidden;
          box-shadow: 5.5px 9.526px 59px 0px rgba(0, 0, 0, 0.24);
        }
        .introduction-cells {
          font-size: 14px;
          color: #8200ff;
          & > div {
            width: 510px;
            height: 40px;
            text-align: center;
            line-height: 40px;
            border: 1px solid #8200ff;
            margin-bottom: 10px;
          }
          &+div{
              margin-top: 30px;
          }
        }
      }
      &.presentation {
        padding: 80px 0px;
        background: url("../../../assets/images/solution/traceSystem/bg_presentation.jpg")
          no-repeat;
        background-size: cover;
        .content-title {
          margin-bottom: 60px;
        }
      }
    }
  }
}
</style>