<template>
  <svg :class="svgClass" v-on="$listeners">
    <use :xlink:href="iconName" />
  </svg>
</template>
<script>
export default {
  name: "SvgIcon",
  props: {
    iconClass: {
      type: String,
      required: true,
    },
    className: {
      type: String,
      default: "",
    },
  },
  computed: {
    iconName() {
      return `#icon-${this.iconClass}`;
    },
    svgClass() {
      if (this.className) {
        return "svg-icon " + this.className;
      } else {
        return "svg-icon";
      }
    },
    styleExternalIcon() {
      return {
        mask: `url(${this.iconClass}) no-repeat 50% 50%`,
        "-webkit-mask": `url(${this.iconClass}) no-repeat 50% 50%`,
      };
    },
  },
};
</script>
<style lang="scss" scoped>
.svg-icon {
  width: 1.5em;
  height: 1.5em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
}
.svg-external-icon {
  background-color: currentColor;
  mask-size: cover !important;
  display: inline-block;
}

</style>
<style>
@-webkit-keyframes el_P7pZskq9FM_BHhscBjTM_Animation {
  10% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
  }
  30% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 10px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 10px);
  }
  50% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
  }
  0% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
  }
  100% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
  }
}
@keyframes el_P7pZskq9FM_BHhscBjTM_Animation {
  10% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
  }
  30% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 10px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 10px);
  }
  50% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
  }
  0% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
  }
  100% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
  }
}
.svgHover * {
  -webkit-animation-duration: 1s;
  animation-duration: 1s;
  -webkit-animation-play-state: running;
  animation-play-state: running;
  -webkit-animation-timing-function: cubic-bezier(0, 0, 1, 1);
  animation-timing-function: cubic-bezier(0, 0, 1, 1);
}
#icon-app_el_QLJEshgSMh {
  fill: #8200ff;
}
#icon-app_el_cc3JkLAXIf {
  fill: #00ffda;
}
#icon-app_el_P7pZskq9FM {
  fill: #8200ff;
}
#icon-app_el_iu_WQqvKDl {
  display: none;
}
#icon-app_el_OjVGKMBWBG {
  display: inline;
}
#icon-app_el_VzX5ihUdFc {
  fill: #00ffda;
}
#icon-app_el_5O3BhGmGCY {
  fill: #00ffda;
}
#icon-app_el_E8hbrsI0JW {
  fill: #00ffda;
}
#icon-app_el_y7EgwBgS2O {
  fill: #8200ff;
}
#icon-app_el_1FQcEcl_CB {
  display: none;
}
#icon-app_el_JbuqEE4Wvz {
  display: inline;
}
#icon-app_el_yLqZqBYqZK {
  fill: #8200ff;
}
#icon-app_el_zaFRNRCS4yT {
  fill: #00ffda;
}
#icon-app_el_P7pZskq9FM_BHhscBjTM {
  -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
    translate(0px, 0px);
  transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
    translate(0px, 0px);
}
.svgHover:hover #icon-app_el_P7pZskq9FM_BHhscBjTM {
  -webkit-animation-name: el_P7pZskq9FM_BHhscBjTM_Animation;
  animation-name: el_P7pZskq9FM_BHhscBjTM_Animation;
}
</style>