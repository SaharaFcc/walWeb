import Vue from 'vue'
import Vuex from 'vuex'
import state from './state'

Vue.use(Vuex)

export default new Vuex.Store({
  state,
  getters: {
    lang: state => state.lang,
    sectionIndex: state => state.sectionIndex,
    showSwitch: state => state.showSwitch,
  },
  mutations: {
    SET_LANG: (state, data) => {
      state.lang = data;
    },
    SET_SHOWSWITCH: (state, data) => {
      state.showSwitch = data;
    },
    SET_SECTIONINDEX: (state, data) => {
      state.sectionIndex = data;
    },
  },
  actions: {
  },
  modules: {
  }
})
