const state = {
    lang: 'EN',
    showSwitch: false,
    sectionIndex: 0
}
export default state