<template>
  <div class="commonHeader">
    <div class="navs">
      <div class="container d-flex justify-content-between">
        <div>
          <a href="">
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2018-12-10/5c0e0ffa1f302.png'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2018-12-10/5c0e0ffa1f302.png'"
            />
          </a>
        </div>
        <div class="d-flex">
          <div
            class="cursor-btn position-relative"
            @mouseover="showWTA = true"
            @mouseleave="showWTA = false"
          >
            {{ $t("home.headerOne") }}
            <div class="circle" v-if="showWTA"></div>
            <ul class="position-absolute" v-if="showWTA">
              <li class="text-center">Blue Paper</li>
              <li class="text-center">SMN/GMN Pre-mining</li>
              <li class="text-center">App Download</li>
            </ul>
          </div>
          <div
            class="cursor-btn position-relative"
            @mouseover="showSolution = true"
            @mouseleave="showSolution = false"
          >
            {{ $t("home.headerTwo") }}
            <div class="circle" v-if="showSolution"></div>
            <ul class="position-absolute" v-if="showSolution">
              <li class="text-center">Blockchain + Liquor/Pharmaceuticals</li>
              <li class="text-center">Blockchain + Cloud</li>
              <li class="text-center">Blockchain + Warranty</li>
              <li class="text-center">Agriculture Solution</li>
              <li class="text-center">Clothing Industry Solution</li>
            </ul>
          </div>
          <div
            class="cursor-btn position-relative"
            @mouseover="showEco = true"
            @mouseleave="showEco = false"
          >
            {{ $t("home.headerThree") }}
            <div class="circle" v-if="showEco"></div>
            <ul class="position-absolute" v-if="showEco">
              <li class="text-center">KIRINMINER</li>
              <li class="text-center">SMN</li>
              <li class="text-center">Public Child Chains</li>
              <li class="text-center">Blockchain Explorer</li>
              <li class="text-center">Business Process</li>
            </ul>
          </div>
          <div
            class="cursor-btn position-relative"
            @mouseover="showInfo = true"
            @mouseleave="showInfo = false"
          >
            {{ $t("home.headerFour") }}
            <div class="circle" v-if="showInfo"></div>
            <ul class="position-absolute" v-if="showInfo">
              <li class="text-center">News</li>
              <li class="text-center">Activities</li>
              <li class="text-center">Announcements</li>
              <li class="text-center">Blog</li>
            </ul>
          </div>
          <div
            class="cursor-btn"
            @mouseover="showWhitePaper = true"
            @mouseleave="showWhitePaper = false"
          >
            {{ $t("home.headerFive") }}
            <div class="circle" v-if="showWhitePaper"></div>
          </div>
          <div
            class="cursor-btn"
            @mouseover="showCommunite = true"
            @mouseleave="showCommunite = false"
          >
            {{ $t("home.headerSix") }}
            <div class="circle" v-if="showCommunite"></div>
          </div>
          <div
            class="cursor-btn position-relative"
            @mouseover="showWTC = true"
            @mouseleave="showWTC = false"
          >
            {{ $t("home.headerSeven") }}
            <div class="circle" v-if="showWTC"></div>
            <ul class="position-absolute" v-if="showWTC">
              <li class="text-center">SMN & GMN Token Swap</li>
              <li class="text-center">Wallet</li>
              <li class="text-center">Bamboo Wallet</li>
              <li class="text-center">Exchanges</li>
            </ul>
          </div>
          <div
            class="cursor-btn position-relative"
            @mouseover="showLanguage = true"
            @mouseleave="showLanguage = false"
          >
            <span class="text-center">
                <template v-if="currentLanguage==='CN'">中文</template>
                <template v-if="currentLanguage==='EN'">ENGLISH</template>
                <template v-if="currentLanguage==='KR'">한국어</template>
            </span>
            <div class="circle" v-if="showLanguage"></div>
            <ul class="position-absolute" v-if="showLanguage">
              <li class="text-center" @click="changeLanguage('EN')" v-if="currentLanguage!=='EN'">ENGLISH</li>
              <li class="text-center" @click="changeLanguage('CN')" v-if="currentLanguage!=='CN'">中文</li>
              <li class="text-center" @click="changeLanguage('KR')" v-if="currentLanguage!=='KR'">한국어</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapGetters, mapMutations } from "vuex";
export default {
  name: "CommonHeader",
  data() {
    return {
      showWTC: false,
      showWTA: false,
      showSolution: false,
      showInfo: false,
      showEco: false,
      showWhitePaper: false,
      showCommunite: false,
      showLanguage: false,
      currentLanguage: 'EN'
    };
  },
  computed: {
    ...mapGetters(["lang","showSwitch"]),
  },
  mounted(){
    this.currentLanguage = localStorage.getItem('lang') ? localStorage.getItem('lang') : this.currentLanguage
  },
  methods: {
    ...mapMutations(["SET_LANG","SET_SHOWSWITCH"]),

    //切换语言
    changeLanguage(lang) {
      switch (lang) {
        case "CN":
          localStorage.setItem("locale", "cn");
          localStorage.setItem("lang", "CN");
          this.SET_LANG("CN");
          this.$i18n.locale = "cn";
          break;
        case "EN":
          localStorage.setItem("locale", "en");
          localStorage.setItem("lang", "EN");
          this.SET_LANG("EN");
          this.$i18n.locale = "en";
          break;
        case "KR":
          localStorage.setItem("locale", "kr");
          localStorage.setItem("lang", "KR");
          this.SET_LANG("KR");
          this.$i18n.locale = "kr";
          break;
        default:
          break;
      }
      this.currentLanguage = lang
      this.showLanguage = !this.showLanguage;
      this.SET_SHOWSWITCH(this.showLanguage);
    },
  },
};
</script>
<style lang="scss" scoped>
.commonHeader {
  .navs {
    color: #fff;
    font-size: 16px;
    letter-spacing: 1px;
    .container {
      max-width: 1640px;
      & > div {
        &:last-of-type {
          & > div {
            &:last-of-type {
              span {
                display: inline-block;
                width: 180px;
                padding: 1px 0px;
                border-radius: 25px;
                border: 1px solid rgba(255, 255, 255, 0.75);
                ul {
                  left: 72% !important;
                }
              }
            }
          }
          div {
            padding: 62px 20px 52px;
          }
          div.circle {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: #00ffda;
            padding: 0px;
            margin: 10px auto 0px;
          }
          ul {
            width: 180px;
            list-style: none;
            color: #eee;
            font-size: 12px;
            background-color: rgba(0, 0, 0, 0.85);
            border-color: #3f3f3f;
            border-top-color: #00ffda;
            box-shadow: 0px 13px 42px 11px rgba(0, 0, 0, 0.05);
            border: 1px solid #333;
            border-top: 2px solid #00ffda;
            top: 80%;
            left: 50%;
            margin-left: -90px;
            z-index: 199;
            li {
              padding: 12px 0px;
              &:hover {
                background: rgb(26, 25, 27);
                color: #00ffda;
              }
            }
          }
        }
      }
    }
  }
}
</style>