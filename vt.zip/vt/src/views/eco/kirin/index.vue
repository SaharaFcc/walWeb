<template>
  <div class="kirin">
    <div class="kirin-head">
      <div>KIRINMINER</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span class="currentRoute">KIRINMINER</span>
        </div>
      </div>
    </div>
    <div class="kirin-content">
      <div class="container">
        <div class="kirin-download">
          <div>
            <div class="d-flex justify-content-center">
              <img src="@/assets/images/eco/kirin/img_manual.jpg" alt="" />
            </div>
            <div class="d-flex justify-content-center">
              <a
                href="https://www.waltonchain.org/document/Kirinminer_User_Manual_EN.pdf"
              >
                <img src="@/assets/images/eco/kirin/img_download.jpg" alt="" />
              </a>
            </div>
          </div>
          <div>
            <div class="d-flex justify-content-center">
              <img src="@/assets/images/eco/kirin/img_findMiner.jpg" alt="" />
            </div>
            <div class="d-flex justify-content-center">
              <a
                href="http://file.kirinpool.com/download/FINDMINER_1_0_0.zip?attname="
              >
                <img src="@/assets/images/eco/kirin/img_download.jpg" alt="" />
              </a>
            </div>
          </div>
        </div>
        <div class="kirin-images">
          <div>
            <img src="@/assets/images/eco/kirin/img_1.jpg" alt="" />
          </div>
          <div>
            <img src="@/assets/images/eco/kirin/img_2.jpg" alt="" />
          </div>
          <div>
            <img src="@/assets/images/eco/kirin/img_3.jpg" alt="" />
          </div>
          <div>
            <img src="@/assets/images/eco/kirin/img_4.jpg" alt="" />
          </div>
          <div>
            <img src="@/assets/images/eco/kirin/img_5.jpg" alt="" />
          </div>
          <div>
            <img src="@/assets/images/eco/kirin/img_6.jpg" alt="" />
          </div>
          <div>
            <img src="@/assets/images/eco/kirin/img_7.jpg" alt="" />
          </div>
        </div>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
export default {
  name: "Kirin",
};
</script>
<style lang="scss" scoped>
.kirin {
  .kirin-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 180px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &:first-of-type {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .kirin-content {
    .container {
      padding: 0px;
      .kirin-download {
        & > div {
          &:first-of-type{
            margin-top: 40px;
          }
          &:not(:first-of-type) {
            margin-bottom: 40px;
          }
        }
      }
    }
  }
}
</style>