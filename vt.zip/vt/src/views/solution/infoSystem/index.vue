<template>
  <div class="infoSystem">
    <div class="infoSystem-head">
      <div>Warranty/Extension Information Traceability System</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span class="currentRoute">Blockchain + Warranty</span>
        </div>
      </div>
    </div>
    <common-nav :navList="navList" :pageType="1" pageName="infoSystem" />
    <div class="infoSystem-content">
      <div class="introduction" id="introduction">
        <div class="container">
          <div class="content-title">
            Warranty/Extension Information Traceability System
          </div>
          <div>
            <div
              class="introduction-cells justify-content-between d-flex flex-wrap"
            >
              <div>All process data on blockchain</div>
              <div>Co-management</div>
              <div>Equal rights & interests</div>
              <div>Modular seamless docking</div>
              <div>Instant verification</div>
            </div>
            <div class="d-flex justify-content-center">
              <img
                src="@/assets/images/solution/infoSystem/img_introduction.jpg"
                alt=""
              />
            </div>
          </div>
        </div>
      </div>
      <div class="presentation" id="presentation">
        <div class="container">
          <div class="content-title">Case Presentation</div>
          <div class="font-weight-bold">
            The warranty/extension system ensures equality of rights and
            interests for beneficiary parties/nodes by uploading encrypted
            information of each link to blockchain and storing it on multiple
            node servers in a distributed way to complicate tampering/deletion.
            The system compares claim, reimbursement and maintenance data with
            that on blockchain.
          </div>
          <div class="font-weight-bold">
            Warranty/extension product uploading to blockchain:
          </div>
          <p>
            Product query on a centralized system. The results are instantly
            compared with the data on blockchain for authenticity.
          </p>
          <div class="font-weight-bold">key order information</div>
          <p>Data comparison to check if repair requirements are met:</p>
          <p>
            YES: proceed to maintenance, NO: maintenance non-conformity report
          </p>
          <div class="font-weight-bold">extension/claim applications</div>
          <p>Query result comparison to check if claim requirements are met</p>
          <div class="font-weight-bold">
            extension/repair order key information
          </div>
          <p>Insurance companies query the whole process</p>
          <div class="font-weight-bold">repair orders</div>
          <p>
            Users query parts, maintenance items, cost and check repair order
            authenticity
          </p>
          <div class="font-weight-bold">extension order key information</div>
          <p>
            Users query extension orders and products in them for data
            authenticity
          </p>
        </div>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
import CommonNav from "@/components/common/CommonNav.vue";
export default {
  components: {
    CommonNav,
  },
  name: "InfoSystem",
  data() {
    return {
      navList: [
        {
          name: "System Introduction",
          id: "introduction",
        },
        {
          name: "Case Presentation",
          id: "presentation",
        },
      ],
    };
  },
};
</script>
<style lang="scss" scoped>
.infoSystem {
  .infoSystem-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 180px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &:first-of-type {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .commonNav {
    /deep/ .nav {
      background: url("../../../assets/images/common/bg_nav.jpg") no-repeat;
      background-size: cover;
      box-shadow: 2.5px 4.33px 13px 0px rgba(0, 0, 0, 0.24);
      height: 170px;
    }
    /deep/ .container.position-relative {
      & > div {
        height: 55px;
      }
      line-height: 55px;
      & > div {
        width: 50%;
      }
    }
  }
  .infoSystem-content {
    & > div {
      .container {
        padding: 0px;
      }
      .content-title {
        font-size: 28px;
        color: #8200ff;
        font-weight: 600;
        margin-bottom: 20px;
      }
      p,
      div {
        font-size: 14px;
        color: #555;
        margin-bottom: 30px;
        line-height: 30px;
      }
      padding: 80px 0px;
      &.introduction {
        margin-top: 60px;
        .content-title + div {
          padding: 50px;
          border-radius: 30px;
          overflow: hidden;
          box-shadow: 5.5px 9.526px 59px 0px rgba(0, 0, 0, 0.24);
        }
        .introduction-cells {
          font-size: 14px;
          color: #8200ff;
          & > div {
            width: 510px;
            height: 40px;
            text-align: center;
            line-height: 40px;
            border: 1px solid #8200ff;
            margin-bottom: 10px;
          }
          & + div {
            margin-top: 30px;
          }
        }
      }
      &.presentation {
        padding: 80px 0px;
        background: url("../../../assets/images/solution/traceSystem/bg_presentation.jpg")
          no-repeat;
        background-size: cover;
        .content-title {
          margin-bottom: 60px;
        }
      }
    }
  }
}
</style>