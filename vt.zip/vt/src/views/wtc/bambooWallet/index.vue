<template>
  <div class="bambooWallet">
    <div class="bambooWallet-head">
      <div>Bamboo Wallet</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span class="currentRoute">Bamboo Wallet</span>
        </div>
      </div>
    </div>
    <div class="bambooWallet-content">
      <div class="container">
        <div v-for="(item, index) in 10" :key="index" class="text-center">
          <template v-if="index === 9">
            <a href="https://github.com/WaltonChain/BambooWallet" target="_balnk">
              <img src="@/assets/images/wtc/bambooWallet/img_10.jpg" alt="" />
            </a>
          </template>
          <template v-else>
            <img :src="index === 0  ? require(`@/assets/images/wtc/bambooWallet/img_`+(index+1)+`.png`) : require(`@/assets/images/wtc/bambooWallet/img_`+(index+1)+`.jpg`)" alt="" />
          </template>
        </div>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
export default {
  name: "BambooWallet",
};
</script>
<style lang="scss" scoped>
.bambooWallet {
  .bambooWallet-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 180px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &:first-of-type {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .bambooWallet-content {
    .container {
      padding: 50px 0px;
      &>div{
        &:last-of-type{
            margin-top: 20px;
        }
      }
    }
  }
}
</style>