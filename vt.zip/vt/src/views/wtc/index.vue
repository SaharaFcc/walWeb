<template>
  <div class="wallet">
    <router-view />
  </div>
</template>