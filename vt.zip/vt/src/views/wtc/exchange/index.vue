<template>
  <div class="exchange">
    <div class="exchange-head">
      <div>Exchanges</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span class="currentRoute">Exchanges</span>
        </div>
      </div>
    </div>
    <div class="exchange-content">
      <div class="container">
        <div>
          <div class="content-title font-weight-bold">
            Since its listing on one of the world’s major cryptocurrency
            exchanges Binance in August 2017, Waltoncoin (WTC) has entered 30+
            cryptocurrency exchanges globally.
          </div>
          <div class="d-flex flex-wrap">
            <div v-for="(item, index) in cryptoList" :key="index">
              <a :href="item" target="_blank">
                <img
                  :src="
                    index === 22
                      ? require(`@/assets/images/wtc/exchange/img_crypto_` +
                          (index + 1) +
                          `.png`)
                      : require(`@/assets/images/wtc/exchange/img_crypto_` +
                          (index + 1) +
                          `.jpg`)
                  "
                  alt=""
              /></a>
            </div>
            <div>
              <a
                href="https://market.exchain.com/exchange/wtc_eth"
                target="_blank"
              >
                <img src="@/assets/images/wtc/exchange/img_more.png" alt=""
              /></a>
            </div>
          </div>
        </div>
        <div>
          <div class="content-title font-weight-bold">
            Platforms supporting mainnet WTC coins:
          </div>
          <div class="d-flex flex-wrap">
            <div v-for="(item, index) in coinList" :key="index">
              <a :href="item" target="_blank">
                <img
                  :src="
                    require(`@/assets/images/wtc/exchange/img_coin_` +
                      (index + 1) +
                      `.jpg`)
                  "
                  alt=""
              /></a>
            </div>
          </div>
        </div>
        <div>
          <div class="content-title font-weight-bold">
            Platforms performing automatic swap of ERC-20 WTC tokens to mainnet
            WTC coins:
          </div>
          <div class="d-flex flex-wrap">
            <div v-for="(item, index) in swapCoinList" :key="index">
              <a :href="item" target="_blank">
                <img
                  :src="
                    require(`@/assets/images/wtc/exchange/img_coin_` +
                      (16 + (index + 1)) +
                      `.jpg`)
                  "
                  alt=""
              /></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
export default {
  name: "Exchange",
  data() {
    return {
      cryptoList: [
        "https://www.binance.com/en/trade/WTC_BTC",
        "https://www.huobi.com/en-us/exchange/?s=wtc_btc/",
        "https://www.okex.com/spot/trade/wtc-btc",
        "https://en.bithumb.com/trade/order/WTC_KRW/",
        "https://www.bitfinex.com/t/WTC:USD?locale=en/",
        "https://trade.lykke.com/trade/WTCBTC",
        "https://trade.kucoin.com/WTC-BTC/",
        "https://latoken.com/exchange/WTC-BTC",
        "https://bitsonic.co.kr/front/en/exchange/wtc-btc",
        "https://okex.co.kr/kr/view/exchange?coin=WTC&market=BTC",
        "https://kanga.exchange/market/WTC-ETH",
        "https://www.cointree.com/buy/waltonchain",
        "https://hitbtc.com/WTC-to-BTC",
        "https://allbit.com/exchange/WTC?market=BTC",
        "https://zgtop.io/exchange#symbol=43",
        "https://idex.market/eth/wtc",
        "https://coinplace.pro/",
        "https://www.bitcratic.com/#!/trade/WTC-ETH",
        "https://simex.global/en/exchange/wtc/btc",
        "https://dragonex.im/en-us/trade/index/wtc_usdt",
        "https://www.bitrue.com/trade/wtc_btc?hl=en_US",
        "https://app.ex.cash/Home/Trade/index/market/WTC_USDT",
        "https://godex.io/exchange/",
        "https://account.bitvavo.com/markets/WTC-EUR",
        "https://p2pb2b.com/trade/WTC_BTC",
        "https://coindcx.com/",
        "https://alterdice.com/trading/WTCBTC",
        "https://www.probit.kr/app/exchange/WTC-KRW",
        "https://www.taibi.io/exchange/?symbol=wtc_usdt&head_index=1",
        "https://www.bitcoinmeester.nl/waltonchain",
        "https://coinmerce.io/en/waltonchain/",
        "https://www.coinspot.com.au/buy/wtc",
        "https://changelly.com/",
        "https://swapzone.io/?to=wtc",
      ],
      coinList: [
        "https://www.okex.com/spot/trade/wtc-btc",
        "https://www.taibi.io/exchange/?symbol=wtc_usdt&head_index=1",
        "https://app.waltonchain.org/app-h5/down",
        "https://en.bithumb.com/trade/order/WTC_KRW/",
        "https://www.binance.com/cn/trade/WTC_BTC",
        "https://www.bitcoinmeester.nl/waltonchain",
        "https://trade.kucoin.com/WTC-BTC/",
        "https://hitbtc.com/WTC-to-BTC",
        "https://www.huobi.com/en-us/exchange/?s=wtc_btc/",
        "https://latoken.com/exchange/WTC-BTC",
        "https://coinmerce.io/en/waltonchain/",
        "https://www.coinspot.com.au/buy/wtc",
        "https://changelly.com/",
        "https://swapzone.io/?to=wtc",
        "https://dragonex.co/zh-hans/trade/index/wtc-usdt",
        "https://crypto.com/en/wallet.html",
      ],
      swapCoinList: [
        "https://app.waltonchain.org/app-h5/down",
        "https://www.binance.com/cn/trade/WTC_BTC",
        "https://www.huobi.com/en-us/exchange/?s=wtc_btc/",
        "https://trade.kucoin.com/WTC-BTC/",
      ],
    };
  },
};
</script>
<style lang="scss" scoped>
.exchange {
  .exchange-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 180px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &:first-of-type {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .exchange-content {
    .container {
      padding: 50px 0px;
      .content-title {
        font-size: 16px;
      }
      & > div > div {
        margin-bottom: 20px;
      }
    }
  }
}
</style>