<template>
  <div class="whitePaper">
    <div class="whitePaper-head">
      <div>White Paper</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span class="currentRoute">White Paper</span>
        </div>
      </div>
    </div>
    <div class="whitePaper-content">
      <div>
        <div class="container">
          <div class="introduction-title font-weight-bold text-center">
            The Innovation Redesigned: Waltonchain 101 What exactly is
            Waltonchain?
          </div>
          <div class="d-flex introduction-flex">
            <div class="position-realtive col-md-6">
              <img src="@/assets/images/whitePaper/img_1.jpg" alt="" />
              <a
                href="https://waltonchain.org/video/whitepaper-en.mp4"
                class="position-absolute"
              >
                <div class="text-center">
                  <img src="@/assets/images/solution/foodSystem/img_video.png" alt="" />
                </div>
                <div>Watch a Video Introduction</div>
              </a>
            </div>
            <div class="col-md-6">
              <div class="introduction-subTitle font-weight-bold">
                Waltonchain White Paper V 2.0
              </div>
              <p>
                On September 4, 2018, Waltonchain officially released White
                Paper V2.0. It is not only a periodic report on the business
                ecosystem construction progress, but also a deep interpretation
                of the future vision of Waltonchain. It presents the most
                sincere, valuable and imaginative consensus mechanism available
                today, WPoC (Waltonchain Proof of Contribution), and puts
                forward the unprecedented Chain Cluster concept.
              </p>
              <p>
                The various projects Waltonchain has been working on have one
                simple idea at their core: to lead humanity into a reliable
                digital life, establish a brand new sustainable business
                ecosystem with all things interconnected via the blockchain
                technology. With our trust mechanism, human life will become
                more productive. We invite everyone to read our white paper and
                discover the potential of Waltonchain!
              </p>
            </div>
          </div>
          <div
            class="anchor-link text-center cursor-btn"
            @click="anchor('read')"
          >
            <span>BROWSE THE WHITE PAPER</span>
          </div>
        </div>
      </div>
      <div id="read">
        <div class="container">
          <div class="content-title font-weight-bold">Read</div>
          <div class="whitePaper-docs d-flex justify-content-between">
            <div>
              <a
                href="http://www.waltonchain.org/en/Uploads/2020-06-11/5ee1c6b5b10cf.pdf"
              >
                <div>
                  <img src="@/assets/images/whitePaper/img_doc_1.jpg" alt="" />
                </div>
                <div class="docs-name font-weight-bold text-center">
                  English
                </div>
                <div class="docs-time">Update date 2018-10-17</div>
              </a>
            </div>
            <div>
              <a
                href="http://www.waltonchain.org/en/Uploads/2020-06-11/5ee1c6dcdba18.pdf"
              >
                <div>
                  <img src="@/assets/images/whitePaper/img_doc_2.jpg" alt="" />
                </div>
                <div class="docs-name font-weight-bold text-center">
                  Chinese
                </div>
                <div class="docs-time">Update date 2018-10-17</div>
              </a>
            </div>
            <div>
              <a
                href="http://www.waltonchain.org/en/Uploads/2020-06-11/5ee1c6eba9ae6.pdf"
              >
                <div>
                  <img src="@/assets/images/whitePaper/img_doc_3.jpg" alt="" />
                </div>
                <div class="docs-name font-weight-bold text-center">
                  Chinese Traditional
                </div>
                <div class="docs-time">Update date 2018-10-17</div>
              </a>
            </div>
            <div>
              <a
                href="http://www.waltonchain.org/en/Uploads/2020-06-11/5ee1c70b4d6a4.pdf"
              >
                <div>
                  <img src="@/assets/images/whitePaper/img_doc_4.jpg" alt="" />
                </div>
                <div class="docs-name font-weight-bold text-center">Korean</div>
                <div class="docs-time">Update date 2018-10-17</div>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
export default {
  name: "WhitePaper",
  methods: {
    //锚点链接
    anchor(anchorId) {
      let anchorElement = document.getElementById(anchorId);
      if (anchorElement) {
        anchorElement.scrollIntoView({
          behavior: "smooth",
        });
      }
    },
  },
};
</script>
<style lang="scss" scoped>
.whitePaper {
  .whitePaper-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 180px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &:first-of-type {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .whitePaper-content {
    & > div {
      .container {
        padding: 80px 0px;
      }
      &:first-of-type {
        .introduction-flex {
          img {
            max-width: 100%;
            border-radius: 10px;
            & + a {
              top: 50%;
              left: 50%;
              transform: translate(-50%, -50%);
              color: #fff;
              font-size: 16px;
              text-decoration: none;
              & > div:last-of-type {
                margin-top: 8px;
              }
            }
          }
          & > div {
            padding: 0px;
            &:first-of-type {
              &::before {
                content: "";
                display: block;
                position: absolute;
                top: 0;
                left: 0;
                height: 100%;
                width: 100%;
                background: rgba(0, 0, 0, 0.7);
                border-radius: 10px;
              }
            }
            &:last-of-type {
              margin-left: 40px;
              p {
                font-size: 15px;
                line-height: 30px;
              }
            }
          }
        }
        .anchor-link {
          margin-top: 50px;
          span {
            color: #8200ff;
            font-size: 15px;
            padding: 0px 30px;
            border: 2px solid #8200ff;
            height: 35px;
            border-radius: 30px;
            display: inline-block;
            line-height: 33px;
          }
        }
      }
      &:last-of-type {
        background: #e9e9e9;
      }
      .content-title {
        font-size: 34px;
        color: #8200ff;
        margin-bottom: 50px;
      }
      .introduction-title {
        font-size: 24px;
        margin-bottom: 50px;
      }
      .introduction-subTitle {
        font-size: 30px;
        color: #8200ff;
        margin-bottom: 20px;
      }
    }
    .whitePaper-docs {
      img {
        border-radius: 27px;
        &:hover {
          box-shadow: 0px 5px 35px 0px;
          transition: 0.3s;
        }
      }
      .docs-name {
        font-size: 18px;
        border-bottom: 5px solid #8200ff;
        padding: 20px 0px 8px;
        margin-bottom: 5px;
      }
      .docs-time {
        font-size: 12px;
      }
      a{
        text-decoration: none;
        color: #000;
      }
    }
  }
}
</style>