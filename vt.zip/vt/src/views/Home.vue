<template>
  <div class="home">
    <div class="button-mouse">
      <div class="scroll"></div>
    </div>
    <div class="scroll-items position-fixed d-flex" v-if="currentSection !== 0">
      <a
        class="cursor-btn"
        v-for="(item, index) in 6"
        :key="index"
        @click="changeSection(index)"
        :class="currentSection === index ? 'active' : ''"
      ></a>
    </div>
    <full-page :options="options" ref="fullpage" id="fullpage">
      <div
        class="section position-relative"
        v-lazy:background-image="{
          src:
            'http://www.waltonchain.org/en/Uploads/2018-12-20/5c1b6c49a27e9.gif',
        }"
      >
        <common-header />
        <div class="font-weight-bold text-center position-absolute navs-text">
          <span>{{ $t("home.headerTextOne") }}</span
          ><br />
          <span>{{ $t("home.headerTextTwo") }}</span>
        </div>
      </div>
      <div class="section position-relative">
        <div class="nav-humber">
          <div class="container d-flex justify-content-between">
            <div>{{ $t("home.aboutText") }}</div>
            <div></div>
          </div>
        </div>
        <div class="position-absolute">
          <div
            class="container d-flex justify-content-between align-items-center"
          >
            <div class="prevPage">
              <span class="link cursor-btn" @click="gotoprevpage">{{
                $t("home.prevText")
              }}</span>
              <span class="name"></span>
              <span class="index">01</span>
              /
              <span class="total">06</span>
            </div>
            <div>
              <p class="font-weight-bold">
                {{ $t("sectionOne.titleText") }}
              </p>
              <p>
                {{ $t("sectionOne.contentTextOne") }}
                <br />
                <br />
                {{ $t("sectionOne.contentTextTwo") }}
              </p>
            </div>
            <div class="nextPage">
              <span class="index">03</span>
              /
              <span class="total">06</span>
              <span class="name">{{ $t("home.centerText") }}</span>
              <span class="link cursor-btn" @click="gotonextpage">{{
                $t("home.nextText")
              }}</span>
            </div>
          </div>
          <div class="nav-video cursor-btn">
            {{ $t("sectionOne.videoText") }}
            <svg-icon iconClass="video" className="video" />
          </div>
        </div>
      </div>
      <div class="section position-relative">
        <div class="nav-humber">
          <div class="container d-flex justify-content-between">
            <div>{{ $t("home.centerText") }}</div>
            <div></div>
          </div>
        </div>
        <div class="position-absolute">
          <div
            class="container d-flex justify-content-between align-items-center"
          >
            <div class="prevPage">
              <span class="link cursor-btn" @click="gotoprevpage">{{
                $t("home.prevText")
              }}</span>
              <span class="name">{{ $t("home.aboutText") }}</span>
              <span class="index">02</span>
              /
              <span class="total">06</span>
            </div>
            <div class="d-flex">
              <div class="text-center cursor-btn">
                <svg-icon iconClass="app" className="app" />
                <p>{{ $t("sectionTwo.tabTextOne") }}</p>
                <div>
                  <img
                    v-lazy="
                      'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/youshi-down.png'
                    "
                    :key="'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/youshi-down.png'"
                  />
                  <div @click="showContent = true">{{ $t("sectionTwo.expandText") }}</div>
                </div>
              </div>
              <div class="text-center cursor-btn">
                <svg-icon iconClass="inter" className="inter" />
                <p>{{ $t("sectionTwo.tabTwoText") }}</p>
                <div>
                  <img
                    v-lazy="
                      'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/youshi-down.png'
                    "
                    :key="'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/youshi-down.png'"
                  />
                  <div>{{ $t("sectionTwo.expandText") }}</div>
                </div>
              </div>
              <div class="text-center cursor-btn">
                <svg-icon iconClass="tech" className="tech" />
                <p>{{ $t("sectionTwo.tabThreeText") }}</p>
                <div>
                  <img
                    v-lazy="
                      'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/youshi-down.png'
                    "
                    :key="'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/youshi-down.png'"
                  />
                  <div>{{ $t("sectionTwo.expandText") }}</div>
                </div>
              </div>
            </div>
            <div class="nextPage">
              <span class="index">04</span>
              /
              <span class="total">06</span>
              <span class="name">{{ $t("home.planText") }}</span>
              <span class="link cursor-btn" @click="gotonextpage">{{
                $t("home.nextText")
              }}</span>
            </div>
          </div>
          <div class="tab-content" v-if="showContent" @mousemove.stop>
            <div v-html="$t('sectionTwo.contentOneTitle')"></div>
            <div v-html="$t('sectionTwo.contentOneText')"></div>
          </div>
        </div>
      </div>
      <div class="section position-relative">
        <div class="nav-humber">
          <div class="container d-flex justify-content-between">
            <div>{{ $t("home.planText") }}</div>
            <div></div>
          </div>
        </div>
        <div class="position-absolute">
          <div
            class="container d-flex justify-content-between align-items-center"
          >
            <div class="prevPage">
              <span class="link cursor-btn" @click="gotoprevpage">{{
                $t("home.prevText")
              }}</span>
              <span class="name">{{ $t("home.centerText") }}</span>
              <span class="index">03</span>
              /
              <span class="total">06</span>
            </div>
            <div>
              <div class="process-tabs d-flex">
                <div class="text-center cursor-btn">
                  <svg-icon iconClass="token" className="token" />
                  <div class="circle"></div>
                  <p class="font-weight-bold">
                    {{ $t("sectionThree.tabTextOne") }}
                  </p>
                  <p class="font-weight-bold">1.0</p>
                </div>
                <div class="text-center cursor-btn">
                  <svg-icon iconClass="data" className="data" />
                  <div class="circle"></div>
                  <p class="font-weight-bold">
                    {{ $t("sectionThree.tabTextTwo") }}
                  </p>
                  <p class="font-weight-bold">2.0</p>
                </div>
                <div class="text-center cursor-btn">
                  <svg-icon iconClass="value" className="value" />
                  <div class="circle"></div>
                  <p class="font-weight-bold">
                    {{ $t("sectionThree.tabTextThree") }}
                  </p>
                  <p class="font-weight-bold">3.0</p>
                </div>
                <div class="text-center cursor-btn">
                  <svg-icon iconClass="custom" className="custom" />
                  <div class="circle"></div>
                  <p class="font-weight-bold">
                    {{ $t("sectionThree.tabTextFour") }}
                  </p>
                  <p class="font-weight-bold">4.0</p>
                </div>
                <div class="text-center cursor-btn">
                  <svg-icon iconClass="eco" className="eco" />
                  <div class="circle"></div>
                  <p class="font-weight-bold">
                    {{ $t("sectionThree.tabTextFive") }}
                  </p>
                  <p class="font-weight-bold">5.0</p>
                </div>
              </div>
              <div class="process-text"></div>
            </div>
            <div class="nextPage">
              <span class="index">05</span>
              /
              <span class="total">06</span>
              <span class="name">{{ $t("home.playText") }}</span>
              <span class="link cursor-btn" @click="gotonextpage">{{
                $t("home.nextText")
              }}</span>
            </div>
          </div>
        </div>
      </div>
      <div class="section position-relative">
        <div class="nav-humber">
          <div class="container d-flex justify-content-between">
            <div>{{ $t("home.playText") }}</div>
            <div></div>
          </div>
        </div>
        <div class="position-absolute">
          <div
            class="container d-flex justify-content-between align-items-center"
          >
            <div class="prevPage">
              <span class="link cursor-btn" @click="gotoprevpage">{{
                $t("home.prevText")
              }}</span>
              <span class="name">{{ $t("home.planText") }}</span>
              <span class="index">04</span>
              /
              <span class="total">06</span>
            </div>
            <div>
              <el-carousel
                trigger="click"
                height="330px"
                :autoplay="false"
                arrow="always"
              >
                <el-carousel-item v-for="(item, index) in imgData" :key="index">
                  <div v-for="(item2, index2) in item.imgList" :key="index2">
                    <img v-lazy="item2" :key="item2" />
                  </div>
                </el-carousel-item>
              </el-carousel>
            </div>
            <div class="nextPage">
              <span class="index">06</span>
              /
              <span class="total">06</span>
              <span class="name">{{ $t("home.linkText") }}</span>
              <span class="link cursor-btn" @click="gotonextpage">{{
                $t("home.nextText")
              }}</span>
            </div>
          </div>
        </div>
      </div>
      <div class="section position-relative">
        <div class="nav-humber">
          <div class="container d-flex justify-content-between">
            <div>{{ $t("home.linkText") }}</div>
            <div></div>
          </div>
        </div>
        <div class="position-absolute">
          <div
            class="container d-flex justify-content-between align-items-center"
          >
            <div class="prevPage">
              <span class="link cursor-btn" @click="gotoprevpage">{{
                $t("home.prevText")
              }}</span>
              <span class="name">{{ $t("home.playText") }}</span>
              <span class="index">05</span>
              /
              <span class="total">06</span>
            </div>
            <div>
              <div class="d-flex">
                <div>
                  <p class="font-weight-bold">
                    {{ $t("sectionFive.customerText") }}
                  </p>
                  <p>services@waltonchain.org</p>
                </div>
                <div>
                  <p class="font-weight-bold">
                    {{ $t("sectionFive.mediaText") }}
                  </p>
                  <p>info@waltonchain.org</p>
                </div>
                <div>
                  <p class="font-weight-bold">
                    {{ $t("sectionFive.smnText") }}
                  </p>
                  <p>smn@waltonchain.org</p>
                </div>
                <div>
                  <p class="font-weight-bold">
                    {{ $t("sectionFive.businessText") }}
                  </p>
                  <p>business@waltonchain.org</p>
                </div>
              </div>
              <div class="leave-btn cursor-btn text-center">
                {{ $t("sectionFive.leaveText") }}
              </div>
              <div class="d-flex">
                <div class="text-center cursor-btn">
                  <i class="iconfont">&#xe600;</i>
                  <p>{{ $t("sectionFive.twitterText") }}</p>
                </div>
                <div class="text-center cursor-btn">
                  <i class="iconfont">&#xe667;</i>
                  <p>{{ $t("sectionFive.redditText") }}</p>
                </div>
                <div class="text-center cursor-btn">
                  <i class="iconfont">&#xe62d;</i>
                  <p>{{ $t("sectionFive.teleText") }}</p>
                </div>
                <div class="text-center cursor-btn">
                  <i class="iconfont">&#xe6a7;</i>
                  <p>{{ $t("sectionFive.mText") }}</p>
                </div>
                <div class="text-center cursor-btn">
                  <i class="iconfont">&#xe805;</i>
                  <p>{{ $t("sectionFive.tubeText") }}</p>
                </div>
              </div>
            </div>
            <div class="nextPage"></div>
          </div>
        </div>
      </div>
    </full-page>
  </div>
</template>
<script>
import { mapState, mapGetters, mapMutations } from "vuex";
import PointWave from "@/components/PointWave/index.vue";
import CommonHeader from "@/components/common/CommonHeader.vue";
export default {
  name: "Home",
  components: {
    PointWave,
    CommonHeader,
  },
  data() {
    return {
      currentSection: 0,
      showContent: false,
      options: {
        licenseKey: "OPEN-SOURCE-GPLV3-LICENSE",
        afterLoad: this.afterLoad,
        lockAnchors: true,
        anchors: ["page1", "page2", "page3", "page4", "page5", "page6"],
      },
      imgData: [
        {
          imgList: [
            "http://www.waltonchain.org/en/Uploads/2019-05-31/5cf12abfab4ae.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-18/5c18cae0bff10.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-18/5c18cb1403266.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-18/5c18cb22d8971.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-10/5c0e09ccc9bbd.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-10/5c0e494f57642.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-10/5c0e495206c58.jpg",
            "http://www.waltonchain.org/en/Uploads/2020-09-14/5f5f1eb16b5d2.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c136810dc678.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c136829a1a13.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c13683a04393.jpg",
            "http://www.waltonchain.org/en/Uploads/2019-11-19/5dd3c63703488.png",
          ],
        },
        {
          imgList: [
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c1368476beee.jpg",
            "http://www.waltonchain.org/en/Uploads/2019-11-27/5dddebe24ee71.png",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c13687a00e23.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c13688886c70.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c13689c35a13.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c1368ae657af.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c1368c4a1f4d.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c1368dfc20d1.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c136901bf59f.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c13691adbb48.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c13693e19ff5.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c13694dcf866.jpg",
          ],
        },
        {
          imgList: [
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c136966cb495.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-17/5c174a746ea05.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c1369ad8b804.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c1369bf29ff5.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c1369d5c9f0f.jpg",
            "http://www.waltonchain.org/en/Uploads/2019-09-09/5d75ed99dbad3.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c136a15a3796.jpg",
            "http://www.waltonchain.org/en/Uploads/2020-05-14/5ebd0a46d39ad.jpg",
            "http://www.waltonchain.org/en/Uploads/2020-05-14/5ebd0aa1aee92.jpg",
            "http://www.waltonchain.org/en/Uploads/2020-05-14/5ebd0adee94f2.jpg",
            "http://www.waltonchain.org/en/Uploads/2020-05-14/5ebd0af67aca7.jpg",
            "http://www.waltonchain.org/en/Uploads/2020-05-14/5ebd0a59cf7fc.jpg",
          ],
        },
        {
          imgList: [
            "http://www.waltonchain.org/en/Uploads/2020-06-15/5ee722400d122.jpg",
            "http://www.waltonchain.org/en/Uploads/2020-06-15/5ee71b590875e.jpg",
            "http://www.waltonchain.org/en/Uploads/2020-07-27/5f1e931701ce4.jpg",
            "http://www.waltonchain.org/en/Uploads/2020-07-27/5f1e932e24629.jpg",
          ],
        },
      ],
    };
  },
  computed: {
    ...mapGetters(["sectionIndex"]),
  },
  methods: {
    ...mapMutations(["SET_SECTIONINDEX"]),
    //切换Section模块
    changeSection(index) {
      this.currentSection = index;
      this.gotopage(index);
    },
    //跳转前一个Section模块
    gotoprevpage() {
      fullpage_api.moveSectionUp();
    },
    //跳转后一个Section模块
    gotonextpage() {
      fullpage_api.moveSectionDown();
    },
    //跳转指定Section模块
    gotopage(index) {
      fullpage_api.moveTo("page" + (index + 1), 1);
    },
    afterLoad(anchorLink, index) {
      console.log("index:", index.index);
      this.currentSection = index.index;
      this.SET_SECTIONINDEX(index.index);
    },
    next() {
      // 向下滚动一页
      this.$refs.fullpage.api.moveSectionDown();
    },
  },
};
</script>
<style lang="scss" scoped>
.home {
  #fullpage {
    .section {
      background-color: #100619;
      background-size: cover;
      .container {
        max-width: 1640px;
      }
      div.navs-text {
        font-size: 80px;
        line-height: 100px;
        color: #fff;
        letter-spacing: 5px;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
      }
      .tab-content{
        height: 350px;
        overflow-y: auto;
        max-width: 900px;
        margin: 0px auto;
      }
      .nav-humber {
        color: #fff;
        font-size: 36px;
        height: 140px;
        line-height: 140px;
        border-bottom: 1px solid rgba(153, 153, 153, 0.23);
        & + div {
          color: #fff;
          width: 100%;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          .container {
            & > div {
              &:nth-of-type(2) {
                max-width: 580px;
              }
              span {
                &.total {
                  padding: 0px 5px;
                }
                &.index {
                  padding: 0px 5px;
                  color: #8200ff;
                }
                &.name {
                  padding: 0px 12px;
                }
              }
            }
          }
        }
      }
      .nav-video {
        font-size: 14px;
        text-indent: 608px;
        color: #00ffda;
        &:hover{
          color: #fff;
        }
      }
      &:nth-of-type(2) {
        .nav-humber {
          & + div {
            .container {
              & > div {
                &:nth-of-type(2) {
                  p {
                    &:first-of-type {
                      font-size: 24px;
                      letter-spacing: 2px;
                      margin-bottom: 40px;
                    }
                    &:last-of-type {
                      font-size: 14px;
                      line-height: 1.8;
                      margin-bottom: 70px;
                    }
                  }
                }
              }
            }
          }
        }
      }
      &:nth-of-type(3) {
        .nav-humber {
          & + div {
            .container {
              & > div {
                &:nth-of-type(2) {
                  max-width: 980px;
                  margin: 100px auto 30px;
                  & > div {
                    width: 306px;
                    p {
                      color: #888;
                      margin: 20px 0px 30px;
                      font-size: 18px;
                    }
                    img + div {
                      font-size: 14px;
                    }
                  }
                }
              }
            }
          }
        }
      }
      &:nth-of-type(4) {
        .nav-humber {
          & + div {
            .container {
              & > div {
                &:nth-of-type(2) {
                  max-width: 980px;
                  .process-tabs {
                    margin: 50px auto;
                    & > div {
                      min-width: 196px;
                      div.circle {
                        width: 10px;
                        height: 10px;
                        border-radius: 50%;
                        background: #8b8b8b;
                        margin: 26px auto 18px;
                      }
                      p {
                        &:first-of-type {
                          font-size: 16px;
                        }
                        &:last-of-type {
                          font-size: 30px;
                        }
                      }
                      &:hover div.circle {
                        background: #00ffda;
                      }
                      &:hover p {
                        color: #00ffda;
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      &:nth-of-type(5) {
        .nav-humber {
          & + div {
            .container {
              & > div {
                &:nth-of-type(2) {
                  width: 700px;
                  max-width: 700px;
                  background: #000;
                }
                /deep/ .el-carousel__item {
                  display: flex;
                  flex-wrap: wrap;
                  & > div {
                    width: 25%;
                    height: 107px;
                  }
                }
              }
            }
          }
        }
      }
      &:nth-of-type(6) {
        .nav-humber {
          & + div {
            .container {
              & > div {
                &:nth-of-type(2) {
                  max-width: 750px;
                  margin: 0 auto;
                  & > div {
                    &:first-of-type {
                      flex-wrap: wrap;
                      & > div {
                        width: 360px;
                        p {
                          &:first-of-type {
                            font-size: 14px;
                            color: #8200ff;
                            margin: 0px;
                          }
                          &:last-of-type {
                            color: #555;
                            font-size: 14px;
                            margin-bottom: 30px;
                          }
                        }
                      }
                    }
                    &.leave-btn {
                      width: 130px;
                      height: 44px;
                      font-size: 18px;
                      background: #8200ff;
                      border-radius: 30px;
                      line-height: 44px;
                      margin: 30px 0px 80px;
                      & + div {
                        & > div {
                          &:not(:last-of-type) {
                            margin-right: 100px;
                          }
                        }
                        i {
                          font-size: 35px;
                          color: #8200ff;
                        }
                        p {
                          color: #999;
                          font-size: 14px;
                          margin-top: 10px;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  .scroll-items {
    width: 100%;
    bottom: 20px;
    z-index: 30;
    & > a {
      display: inline-block;
      width: calc((100% - 20px) / 6);
      height: 5px;
      background-color: #353535;
      &.active {
        background: #595959;
      }
      &:not(:first-of-type) {
        margin-left: 4px;
      }
    }
  }
  .button-mouse {
    position: absolute;
    width: 30px;
    height: 42px;
    bottom: 60px;
    left: 50%;
    margin-left: -12px;
    border-radius: 15px;
    border: 2px solid rgba(255, 255, 255, 0.5);
    animation: intro 1s;
    z-index: 99;
    .scroll {
      display: block;
      width: 3px;
      height: 8px;
      margin: 6px auto;
      border-radius: 4px;
      background: rgba(255, 255, 255, 0.5);
      animation: finger 1.2s infinite;
      z-index: 99;
    }
  }
  @keyframes intro {
    0% {
      opacity: 0;
      transform: translateY(40px);
    }
    100% {
      opacity: 1;
      transform: translateY(0);
    }
  }
  @keyframes finger {
    0% {
      opacity: 1;
    }
    100% {
      opacity: 0;
      transform: translateY(20px);
    }
  }
}
</style>