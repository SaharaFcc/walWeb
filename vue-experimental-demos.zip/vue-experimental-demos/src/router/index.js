import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

import Layout from '@/layout'

/**
 * Note: sub-menu only appear when route children.length >= 1
 * Detail see: https://panjiachen.github.io/vue-element-admin-site/guide/essentials/router-and-nav.html
 *
 * hidden: true                   if set true, item will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu
 *                                if not set alwaysShow, when item has more than one children route,
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noRedirect           if set noRedirect will no redirect in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    roles: ['admin','editor']    control the page roles (you can set multiple roles)
    title: 'title'               the name show in sidebar and breadcrumb (recommend set)
    icon: 'svg-name'             the icon show in the sidebar
    breadcrumb: false            if set false, the item will hidden in breadcrumb(default is true)
    activeMenu: '/example/list'  if set path, the sidebar will highlight the path you set
  }
 */

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 */
export const constantRoutes = [
  {
    path: '/redirect',
    component: Layout,
    hidden: true,
    children: [
      {
        path: '/redirect/:path*',
        component: () => import('@/views/redirect')
      }
    ]
  },
  {
    path: '/',
    redirect: '/index'
  },
  {
    path: '/index',
    name: 'Index',
    component: () => import('@/views/index/index'),
    meta: { title: '索引页', icon: 'dashboard' }
  },
  {
    path: '/spacewaves',
    component: () => import('@/views/spacewaves/index'),
    meta: { title: '空间波浪特效', icon: 'example' }
  },
  {
    path: '/eyeball',
    component: () => import('@/views/eyeball/index'),
    meta: { title: '浮动的眼球', icon: 'eye' }
  },
  {
    path: '/sidebar',
    component: Layout,
    redirect: '/sidebar/index',
    children: [
      {
        path: 'index',
        name: 'SideWithDynamicBG',
        component: () => import('@/views/sidebar/index'),
        meta: { title: '动态背景侧边栏', icon: 'form' }
      }
    ]
  },
  {
    path: '/modal',
    redirect: '/modal/index',
    component: Layout,
    children: [
      {
        path: 'index',
        name: 'Modal',
        component: () => import('@/views/modal/index'),
        meta: { title: '模态框', icon: 'form' }
      }
    ]
  },
  {
    path: '/404',
    component: () => import('@/views/404'),
    hidden: true
  },

  // 404 page must be placed at the end !!!
  { path: '*', redirect: '/404', hidden: true }
]

const createRouter = () => new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
