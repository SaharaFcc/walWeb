// 封装axios
import axios from 'axios'
// import QS from 'qs'
import store from '@/store/index'
import router from '../router/index'

var instance = axios.create({timeout: 10000})
instance.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded'

instance.interceptors.request.use(
    config => {
        config.headers['X-Requested-With'] = 'XMLHttpRequest'
        const token = store.state.webToken || localStorage.getItem('webToken')
        token && (config.headers.Authorization = token)
        return config
    },
    error => Promise.error(error))

instance.interceptors.response.use(
    res => res.status === 200 ? Promise.resolve(res) : Promise.reject(res),
    error => {
        const { response } = error
        if(response) {
            console.log('response',response)
            // router.replace({path:'/login'})
            return Promise.reject(response)
        }
    }
)

export default instance