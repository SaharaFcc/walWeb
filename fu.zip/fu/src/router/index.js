import Vue from "vue";
import VueRouter from "vue-router";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    redirect: "/en"
  },
  {
    path: "/en",
    component: () => import("@/views/ENHome.vue"),
    children: [
      {
        path: "wta/bluePaper",
        component: () => import("@/views/WTA/bluePaper.vue")
      },
      {
        path: "solution/liquor",
        component: () => import("@/views/Solutions/Liquor.vue")
      },
      {
        path: "solution/cloud",
        component: () => import("@/views/Solutions/Cloud.vue")
      },
      {
        path: "solution/warrant",
        component: () => import("@/views/Solutions/Warrant.vue")
      },
      {
        path: "solution/argiculture",
        component: () => import("@/views/Solutions/Argiculture.vue")
      }
    ]
  },
  {
    path: "/cn",
    component: () => import("@/views/CNHome.vue"),
    children: []
  },
  {
    path: "/kr",
    component: () => import("@/views/KRHome.vue"),
    children: []
  }
];

const router = new VueRouter({
  routes
});

export default router;
