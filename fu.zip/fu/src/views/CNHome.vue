<template>
  <div class="cnHome">
    <router-view/>
  </div>
</template>

<script>

export default {
  name: 'CNHome',
  components: {}
}
</script>
