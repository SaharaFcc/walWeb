<template>
  <div class="enHome">
    <router-view/>
  </div>
</template>

<script>

export default {
  name: 'ENHome',
  components: {},
  data(){
    return{
      initStr: ''
    }
  },
  created(){
    this.getBluePaperInfo()
  },
  methods:{
    async getBluePaperInfo(){
      let _this = this
      let dataset = (await _this.$api.bluePaper.getBluePaper()).data.data
      this.initStr = dataset.volist[4].content
      console.log('dataset',dataset)
    }
  }
}
</script>
