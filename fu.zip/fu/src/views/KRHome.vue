<template>
  <div class="krHome">
    <router-view/>
  </div>
</template>

<script>

export default {
  name: 'KRHome',
  components: {}
}
</script>
