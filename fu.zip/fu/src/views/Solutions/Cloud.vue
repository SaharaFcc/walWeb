<template>
  <div class="cloud">
    <div class="cloud-body">
      <div class="cloud-body-content">
        <div>
          <div v-for="(item, index) in tagList" :key="index">{{ item }}</div>
        </div>
        <div>
          <img :src="coverUrl" alt="" />
        </div>
      </div>
      <div class="cloud-body-case">
        <div v-html="descStr"></div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Cloud",
  components: {},
  data() {
    return {
      tagList: [],
      descStr: "",
      coverUrl:
        "http://www.waltonchain.org/en/Uploads/2020-06-11/5ee1c7023b37e.png"
    };
  },
  computed: {
    splitStr() {
      return str => {
        return str.split(",");
      };
    }
  },
  created() {
    let _this = this;
    _this.getCloud();
  },
  methods: {
    async getCloud() {
      let _this = this;
      let dataset = (await _this.$api.cloud.getCloud()).data.data;
      _this.tagList = _this.splitStr(dataset.info.tag);
      _this.descStr = dataset.info.zsms;
    }
  }
};
</script>
<style lang="scss" scoped>
.cloud {
  .cloud-body {
    div.cloud-body-content {
      border-radius: 30px;
      overflow: hidden;
      box-shadow: 5.5px 9.526px 59px 0px rgba(0, 0, 0, 0.24);
      padding: 50px;
      width: 1040px;
      margin: 0px auto;
    }
    div.cloud-body-case {
      background: url(http://www.waltonchain.org/en/Theme/wed/Public/images/solutionbj1.jpg)
        no-repeat;
      background-size: cover;
      padding: 80px 0px;
      div {
        width: 1140px;
        padding: 0px 15px;
        margin: 0px auto;
      }
    }
  }
}
</style>
