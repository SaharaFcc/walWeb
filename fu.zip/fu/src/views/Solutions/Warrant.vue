<template>
  <div class="warrant">
    <div class="warrant-body">
      <div class="warrant-body-content">
        <div>
          <div v-for="(item, index) in tagList" :key="index">{{ item }}</div>
        </div>
        <div>
          <img :src="coverUrl" alt="" />
        </div>
      </div>
      <div class="warrant-body-case">
        <div v-html="descStr"></div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Warrant",
  components: {},
  data() {
    return {
      tagList: [],
      descStr: "",
      coverUrl:
        "http://www.waltonchain.org/en/Uploads/2019-07-16/5d2d83a1e4ea9.jpg"
    };
  },
  computed: {
    splitStr() {
      return str => {
        return str.split(",");
      };
    }
  },
  created() {
    let _this = this;
    _this.getWarrant();
  },
  methods: {
    async getWarrant() {
      let _this = this;
      let dataset = (await _this.$api.warrant.getWarrant()).data.data;
      _this.tagList = _this.splitStr(dataset.info.tag);
      _this.descStr = dataset.info.zsms;
    }
  }
};
</script>
<style lang="scss" scoped>
.warrant {
  .warrant-body {
    div.warrant-body-content {
      border-radius: 30px;
      overflow: hidden;
      box-shadow: 5.5px 9.526px 59px 0px rgba(0, 0, 0, 0.24);
      padding: 50px;
      width: 1040px;
      margin: 0px auto;
    }
    div.warrant-body-case {
      background: url(http://www.waltonchain.org/en/Theme/wed/Public/images/solutionbj1.jpg)
        no-repeat;
      background-size: cover;
      padding: 80px 0px;
      div {
        width: 1140px;
        padding: 0px 15px;
        margin: 0px auto;
      }
    }
  }
}
</style>
