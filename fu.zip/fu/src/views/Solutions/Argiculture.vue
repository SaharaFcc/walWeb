<template>
  <div class="argiculture">
    <div class="argiculture-body">
      <div class="argiculture-body-content"></div>
      <div class="argiculture-body-case"></div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Argiculture",
  components: {},
  data() {
    return {};
  },
  methods: {}
};
</script>
