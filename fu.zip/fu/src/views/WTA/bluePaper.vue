<template>
  <div class="bluePaper">
    <div class="bluePaper-body">
      <div v-for="(item, index) in volist" :key="index">
        <div v-html="formatStr(item.content)"></div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "BluePaper",
  components: {},
  data() {
    return {
      volist: []
    };
  },
  computed: {
    formatStr() {
      return str => {
        return str.replace(/<img/g, '<img style="max-width:100%;"');
      };
    }
  },
  created() {
    let _this = this;
    _this.getBluePaper();
  },
  methods: {
    async getBluePaper() {
      let _this = this;
      let bluePaper = (await _this.$api.bluePaper.getBluePaper()).data.data;
      _this.volist = bluePaper.volist;
    }
  }
};
</script>
<style lang="scss" scoped>
.bluePaper {
  .bluePaper-body {
    width: 1140px;
    margin: 0px auto;
    & > div {
      background: #fff;
      box-shadow: 6px 10.392px 62px 0px rgba(0, 0, 0, 0.07);
      padding: 90px;
      border-radius: 30px;
    }
  }
}
</style>
