<template>
  <div id="app">
    <div id="nav">
    </div>
    <router-view/>
  </div>
</template>