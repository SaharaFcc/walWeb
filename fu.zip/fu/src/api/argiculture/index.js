import axios from "@/request/http";

const argiculture = {
  getArgiculture() {
    return axios.get(`/en/solutions/agriculture_solution`, {});
  }
};

export default argiculture;
