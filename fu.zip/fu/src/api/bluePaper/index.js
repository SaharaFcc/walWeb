import axios from '@/request/http'

const bluePaper = {
    getBluePaper(){
        return axios.get(`/en/sys/list/52.html`,{})
    },
}

export default bluePaper