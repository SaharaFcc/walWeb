// api出口
import bluePaper from "@/api/bluePaper";
import liquor from "@/api/liquor";
import cloud from "@/api/cloud";
import warrant from "@/api/warrant";
import argiculture from "@/api/argiculture";

export default {
  bluePaper,
  liquor,
  cloud,
  warrant,
  argiculture
};
