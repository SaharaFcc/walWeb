import axios from "@/request/http";

const warrant = {
  getWarrant() {
    return axios.get(`/en/sys/422.html`, {});
  }
};

export default warrant;
