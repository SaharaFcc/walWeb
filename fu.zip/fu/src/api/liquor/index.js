import axios from "@/request/http";

const liquor = {
  getLiquor() {
    return axios.get(`/en/sys/424.html`, {});
  }
};

export default liquor;
