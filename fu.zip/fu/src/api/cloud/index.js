import axios from "@/request/http";

const cloud = {
  getCloud() {
    return axios.get(`/en/sys/423.html`, {});
  }
};

export default cloud;
