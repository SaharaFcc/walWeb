import Vue from 'vue'
import VueRouter from 'vue-router'
import store from '../store/index.js'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('../views/Home.vue')
  },
  {
    path: '/kr',
    component: () => import('../views/Home.vue'),
  },
  {
    path: '/en',
    component: () => import('../views/Home.vue'),
  },
  {
    path: '/en/wta/appDownload',
    component: () => import('../views/wta/appDownload/index.vue'),
  },
  {
    path: '/kr/wta/appDownload',
    component: () => import('../views/wta/appDownload/index.vue'),
  },
  {
    path: '/en/solution/foodSystem',
    component: () => import('../views/solution/foodSystem/index.vue'),
  },
  {
    path: '/kr/solution/foodSystem',
    component: () => import('../views/solution/foodSystem/index.vue'),
  },
  {
    path: '/en/solution/clothSystem',
    component: () => import('../views/solution/clothSystem/index.vue'),
  },
  {
    path: '/kr/solution/clothSystem',
    component: () => import('../views/solution/clothSystem/index.vue'),
  },
  {
    path: '/en/eco/kirin',
    component: () => import('../views/eco/kirin/index.vue'),
  },
  {
    path: '/kr/eco/kirin',
    component: () => import('../views/eco/kirin/index.vue'),
  },
  {
    path: '/en/eco/smn',
    component: () => import('../views/eco/smn/index.vue'),
  },
  {
    path: '/kr/eco/smn',
    component: () => import('../views/eco/smn/index.vue'),
  },
  {
    path: '/en/eco/childChain',
    component: () => import('../views/eco/childChain/index.vue'),
  },
  {
    path: '/kr/eco/childChain',
    component: () => import('../views/eco/childChain/index.vue'),
  },
  {
    path: '/en/wtc/bambooWallet',
    component: () => import('../views/wtc/bambooWallet/index.vue'),
  },
  {
    path: '/kr/eco/bambooWallet',
    component: () => import('../views/wtc/bambooWallet/index.vue'),
  },
  {
    path: '/en/whitePaper',
    component: () => import('../views/whitePaper/index.vue'),
  },
  {
    path: '/kr/whitePaper',
    component: () => import('../views/whitePaper/index.vue'),
  },
  {
    path: '/en/communite',
    component: () => import('../views/communite/index.vue'),
  },
  {
    path: '/kr/communite',
    component: () => import('../views/communite/index.vue'),
  },
  {
    path: '/en/wtc/wallet',
    component: () => import('../views/wtc/wallet/index.vue'),
  },
  {
    path: '/kr/wtc/wallet',
    component: () => import('../views/wtc/wallet/index.vue'),
  },
  {
    path: '/en/wtc/exchange',
    component: () => import('../views/wtc/exchange/index.vue'),
  },
  {
    path: '/kr/wtc/exchange',
    component: () => import('../views/wtc/exchange/index.vue'),
  },
  {
    path: '/wta',
    component: () => import('@/views/wta/index.vue'),
    children: [
      {
        path: 'bluePaper',
        name: 'BluePaper',
        component: () => import('@/views/wta/bluePaper/index.vue')
      },
      {
        path: 'appDownload',
        name: 'AppDownload',
        component: () => import('@/views/wta/appDownload/index.vue')
      }
    ]
  },
  {
    path: '/solution',
    component: () => import('@/views/solution/index.vue'),
    children: [
      {
        path: 'traceSystem',
        name: 'TraceSystem',
        component: () => import('@/views/solution/traceSystem/index.vue')
      },
      {
        path: 'collectSystem',
        name: 'CollectSystem',
        component: () => import('@/views/solution/collectSystem/index.vue')
      },
      {
        path: 'infoSystem',
        name: 'InfoSystem',
        component: () => import('@/views/solution/infoSystem/index.vue')
      },
      {
        path: 'foodSystem',
        name: 'FoodSystem',
        component: () => import('@/views/solution/foodSystem/index.vue')
      },
      {
        path: 'clothSystem',
        name: 'ClothSystem',
        component: () => import('@/views/solution/clothSystem/index.vue')
      }
    ]
  },
  {
    path: '/eco',
    component: () => import('@/views/eco/index.vue'),
    children: [
      {
        path: 'kirin',
        name: 'Kirin',
        component: () => import('@/views/eco/kirin/index.vue')
      },
      {
        path: 'childChain',
        name: 'ChildChain',
        component: () => import('@/views/eco/childChain/index.vue')
      },
      {
        path: 'smn',
        name: 'Smn',
        component: () => import('@/views/eco/smn/index.vue')
      },
      {
        path: 'process',
        name: 'Process',
        component: () => import('@/views/eco/process/index.vue')
      }
    ]
  },
  {
    path: '/info',
    component: () => import('@/views/info/index.vue'),
    children: [
      {
        path: 'news',
        name: 'News',
        component: () => import('@/views/info/news/index.vue')
      },
      {
        path: 'activity',
        name: 'Activity',
        component: () => import('@/views/info/activity/index.vue')
      },
      {
        path: 'announce',
        name: 'Announce',
        component: () => import('@/views/info/announce/index.vue')
      },
      {
        path: 'blog',
        name: 'Blog',
        component: () => import('@/views/info/blog/index.vue')
      }
    ]
  },
  {
    path: '/whitePaper',
    name: 'WhitePaper',
    component: () => import('@/views/whitePaper/index.vue')
  },
  {
    path: '/communite',
    name: 'Communite',
    component: () => import('@/views/communite/index.vue')
  },
  {
    path: '/wtc',
    component: () => import('@/views/wtc/index.vue'),
    children: [
      {
        path: 'tokenSwap',
        name: 'TokenSwap',
        component: () => import('@/views/wtc/tokenSwap/index.vue')
      },
      {
        path: 'wallet',
        name: 'Wallet',
        component: () => import('@/views/wtc/wallet/index.vue')
      },
      {
        path: 'bambooWallet',
        name: 'BambooWallet',
        component: () => import('@/views/wtc/bambooWallet/index.vue')
      },
      {
        path: 'exchange',
        name: 'Exchange',
        component: () => import('@/views/wtc/exchange/index.vue')
      }
    ]
  },
  {
    path: '/appPolicy',
    name: 'AppPolicy',
    component: () => import('../views/appPolicy/index.vue')
  },
  {
    path: '/walletPolicy',
    name: 'WalletPolicy',
    component: () => import('../views/walletPolicy/index.vue')
  },
  {
    path: '/useTerm',
    name: 'UseTerm',
    component: () => import('../views/useTerm/index.vue')
  },
  {
    path: '/summaryPolicy',
    name: 'SummaryPolicy',
    component: () => import('../views/summaryPolicy/index.vue')
  },
  {
    path: '/about',
    name: 'About',
    component: () => import('../views/About.vue')
  }
]

const router = new VueRouter({
  routes
})

router.beforeEach((to, from, next) => {
  next()
});

export default router
