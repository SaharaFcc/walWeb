<template>
  <div class="activity"></div>
</template>

<script>
export default {
  name: "Activity",
};
</script>
<style lang="scss" scoped>
.activity {
}
</style>