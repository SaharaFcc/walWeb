<template>
  <div class="blog">
    
  </div>
</template>

<script>
export default {
  name: "Blog",
};
</script>