<template>
  <div class="whitePaper">
    <div class="whitePaper-head">
      <common-header/>
      <div>White Paper</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span class="currentRoute">White Paper</span>
        </div>
      </div>
    </div>
    <div class="whitePaper-content">
      <div>
        <div class="container">
          <div class="introduction-title font-weight-bold text-center">
            {{ $t("whitePaper.mainTitleText") }}
          </div>
          <div class="d-flex introduction-flex">
            <div class="position-realtive col-md-6">
              <img
                v-lazy="
                  currentLanguage === 'EN'
                    ? imgOneEn
                    : currentLanguage === 'KR'
                    ? imgOneKr
                    : ''
                "
                :key="
                  currentLanguage === 'EN'
                    ? imgOneEn
                    : currentLanguage === 'KR'
                    ? imgOneKr
                    : ''
                "
              />
              <a
                href="https://waltonchain.org/video/whitepaper-en.mp4"
                class="position-absolute"
              >
                <div class="text-center">
                  <img
                    src="@/assets/images/solution/foodSystem/img_video.png"
                    alt=""
                  />
                </div>
                <div>{{ $t("whitePaper.videoText") }}</div>
              </a>
            </div>
            <div class="col-md-6">
              <div class="introduction-subTitle font-weight-bold">
                {{ $t("whitePaper.paraOneTitle") }}
              </div>
              <div v-html="$t('whitePaper.paraOneContent')"></div>
            </div>
          </div>
          <div
            class="anchor-link text-center cursor-btn"
            @click="anchor('read')"
          >
            <span>{{ $t("whitePaper.btnText") }}</span>
          </div>
        </div>
      </div>
      <div id="read">
        <div class="container">
          <div class="content-title font-weight-bold">
            {{ $t("whitePaper.paraTwoTitle") }}
          </div>
          <div class="whitePaper-docs d-flex justify-content-between">
            <div>
              <a
                href="http://www.waltonchain.org/en/Uploads/2020-06-11/5ee1c6b5b10cf.pdf"
              >
                <div>
                  <img
                    v-lazy="
                      currentLanguage === 'EN'
                        ? bookOneEn
                        : currentLanguage === 'KR'
                        ? bookOneKr
                        : ''
                    "
                    :key="
                      currentLanguage === 'EN'
                        ? bookOneEn
                        : currentLanguage === 'KR'
                        ? bookOneKr
                        : ''
                    "
                  />
                </div>
                <div class="docs-name font-weight-bold text-center">
                  {{ $t("whitePaper.bookOneName") }}
                </div>
                <div class="docs-time">{{ $t("whitePaper.bookTimeText") }}</div>
              </a>
            </div>
            <div>
              <a
                href="http://www.waltonchain.org/en/Uploads/2020-06-11/5ee1c6dcdba18.pdf"
              >
                <div>
                  <img
                    v-lazy="
                      currentLanguage === 'EN'
                        ? bookTwoEn
                        : currentLanguage === 'KR'
                        ? bookTwoKr
                        : ''
                    "
                    :key="
                      currentLanguage === 'EN'
                        ? bookTwoEn
                        : currentLanguage === 'KR'
                        ? bookTwoKr
                        : ''
                    "
                  />
                </div>
                <div class="docs-name font-weight-bold text-center">
                  {{ $t("whitePaper.bookTwoName") }}
                </div>
                <div class="docs-time">{{ $t("whitePaper.bookTimeText") }}</div>
              </a>
            </div>
            <div>
              <a
                href="http://www.waltonchain.org/en/Uploads/2020-06-11/5ee1c6eba9ae6.pdf"
              >
                <div>
                  <img
                    v-lazy="
                      currentLanguage === 'EN'
                        ? bookThreeEn
                        : currentLanguage === 'KR'
                        ? bookThreeKr
                        : ''
                    "
                    :key="
                      currentLanguage === 'EN'
                        ? bookThreeEn
                        : currentLanguage === 'KR'
                        ? bookThreeKr
                        : ''
                    "
                  />
                </div>
                <div class="docs-name font-weight-bold text-center">
                  {{ $t("whitePaper.bookThreeName") }}
                </div>
                <div class="docs-time">{{ $t("whitePaper.bookTimeText") }}</div>
              </a>
            </div>
            <div>
              <a
                href="http://www.waltonchain.org/en/Uploads/2020-06-11/5ee1c70b4d6a4.pdf"
              >
                <div>
                  <img
                    v-lazy="
                      currentLanguage === 'EN'
                        ? bookFourEn
                        : currentLanguage === 'KR'
                        ? bookFourKr
                        : ''
                    "
                    :key="
                      currentLanguage === 'EN'
                        ? bookFourEn
                        : currentLanguage === 'KR'
                        ? bookFourKr
                        : ''
                    "
                  />
                </div>
                <div class="docs-name font-weight-bold text-center">
                  {{ $t("whitePaper.bookFourName") }}
                </div>
                <div class="docs-time">{{ $t("whitePaper.bookTimeText") }}</div>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
import CommonHeader from '@/components/common/CommonHeader.vue';
export default {
  name: "WhitePaper",
  data() {
    return {
      currentLanguage: "CN",
      imgOneEn:
        "http://www.waltonchain.org/en/Uploads/2018-12-10/5c0dd5c1d91b8.jpg",
      imgOneKr:
        "http://www.waltonchain.org/kr/Uploads/2018-12-10/5c0dd5c1d91b8.jpg",
      bookOneEn:
        "http://www.waltonchain.org/en/Uploads/2018-12-20/5c1b20d1a8ad2.jpg",
      bookOneKr:
        "http://www.waltonchain.org/kr/Uploads/2018-12-20/5c1b11497c3e4.jpg",
      bookTwoEn:
        "http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b9bddb5a8e.jpg",
      bookTwoKr:
        "http://www.waltonchain.org/kr/Uploads/2019-01-04/5c2ef8992b487.jpg",
      bookThreeEn:
        "http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b9bddb5a8e.jpg",
      bookThreeKr:
        "http://www.waltonchain.org/kr/Uploads/2018-12-08/5c0b9bddb5a8e.jpg",
      bookFourEn:
        "http://www.waltonchain.org/en/Uploads/2019-01-04/5c2ef65563fc0.jpg",
      bookFourKr:
        "http://www.waltonchain.org/kr/Uploads/2018-12-08/5c0b9bddb5a8e.jpg",
    };
  },
  components:{
    CommonHeader
  },
  mounted() {
    this.currentLanguage = localStorage.getItem("lang")
      ? localStorage.getItem("lang")
      : this.currentLanguage;
  },
  methods: {
    //锚点链接
    anchor(anchorId) {
      let anchorElement = document.getElementById(anchorId);
      if (anchorElement) {
        anchorElement.scrollIntoView({
          behavior: "smooth",
        });
      }
    },
  },
};
</script>
<style lang="scss" scoped>
.whitePaper {
  .whitePaper-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    height: 410px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &.commonHeader{
        min-width: 1640px;
      }
      &:nth-of-type(2) {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .whitePaper-content {
    & > div {
      .container {
        padding: 80px 0px;
      }
      &:first-of-type {
        .introduction-flex {
          img {
            max-width: 100%;
            border-radius: 10px;
            & + a {
              top: 50%;
              left: 50%;
              transform: translate(-50%, -50%);
              color: #fff;
              font-size: 16px;
              text-decoration: none;
              & > div:last-of-type {
                margin-top: 8px;
              }
            }
          }
          & > div {
            padding: 0px;
            &:first-of-type {
              &::before {
                content: "";
                display: block;
                position: absolute;
                top: 0;
                left: 0;
                height: 100%;
                width: 100%;
                background: rgba(0, 0, 0, 0.7);
                border-radius: 10px;
              }
            }
            &:last-of-type {
              margin-left: 40px;
              p {
                font-size: 15px;
                line-height: 30px;
              }
            }
          }
        }
        .anchor-link {
          margin-top: 50px;
          span {
            color: #8200ff;
            font-size: 15px;
            padding: 0px 30px;
            border: 2px solid #8200ff;
            height: 35px;
            border-radius: 30px;
            display: inline-block;
            line-height: 33px;
          }
        }
      }
      &:last-of-type {
        background: #e9e9e9;
      }
      .content-title {
        font-size: 34px;
        color: #8200ff;
        margin-bottom: 50px;
      }
      .introduction-title {
        font-size: 24px;
        margin-bottom: 50px;
      }
      .introduction-subTitle {
        font-size: 30px;
        color: #8200ff;
        margin-bottom: 20px;
      }
    }
    .whitePaper-docs {
      img {
        border-radius: 27px;
        &:hover {
          box-shadow: 0px 5px 35px 0px;
          transition: 0.3s;
        }
      }
      .docs-name {
        font-size: 18px;
        border-bottom: 5px solid #8200ff;
        padding: 20px 0px 8px;
        margin-bottom: 5px;
      }
      .docs-time {
        font-size: 12px;
      }
      a {
        text-decoration: none;
        color: #000;
      }
    }
  }
}
</style>