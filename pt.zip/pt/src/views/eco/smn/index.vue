<template>
  <div class="smn">
    <div class="smn-head">
      <common-header/>
      <div>Waltonchain Global SMN Recruitment Program</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span>Ecosystem</span>
          <span class="splitLine">/</span>
          <span class="currentRoute"
            >Waltonchain Global SMN Recruitment Program</span
          >
        </div>
      </div>
    </div>
    <common-nav :navList="navList" :pageType="1" pageName="smn" />
    <div class="smn-content">
      <div class="container">
        <div class="mainTitle text-center" v-if="currentLanguage === 'KR'">
          {{ $t("smn.mainTitleText") }}
        </div>
        <div id="introduction">
          <div class="content-title font-weight-bold">
            {{ $t("smn.paraOneTitle") }}
          </div>
          <div v-html="$t('smn.paraOneContent')"></div>
        </div>
        <div id="recruit">
          <div class="content-title font-weight-bold">
            {{ $t("smn.paraTwoTitle") }}
          </div>
          <div v-html="$t('smn.paraTwoContent')"></div>
        </div>
        <div id="capability">
          <div class="content-title font-weight-bold">
            {{ $t("smn.paraThreeTitle") }}
          </div>
          <div v-html="$t('smn.paraThreeContent')"></div>
        </div>
        <div id="quality">
          <div class="content-title font-weight-bold">
            {{ $t("smn.paraFourTitle") }}
          </div>
          <div v-html="$t('smn.paraFourContent')"></div>
        </div>
        <div id="rewards">
          <div class="content-title font-weight-bold">
            {{ $t("smn.paraFiveTitle") }}
          </div>
          <div v-html="$t('smn.paraFiveContent')"></div>
        </div>
        <div id="smnList" v-if="currentLanguage === 'EN'">
          <div class="content-title font-weight-bold">{{$t('smn.paraSixTitle')}}</div>
          <div v-html="$t('smn.paraSixContent')"></div>
        </div>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
import CommonNav from "@/components/common/CommonNav.vue";
import CommonHeader from '@/components/common/CommonHeader.vue';
export default {
  components: {
    CommonNav,
    CommonHeader
  },
  name: "Smn",
  data() {
    return {
      navList: [
        {
          name: "Introduction",
          id: "introduction",
        },
        {
          name: "Recruitment Type",
          id: "recruit",
        },
        {
          name: "Capabilities",
          id: "capability",
        },
        {
          name: "Qualification",
          id: "quality",
        },
        {
          name: "Rewards",
          id: "rewards",
        },
        {
          name: "SMN List",
          id: "smnList",
        },
      ],
      currentLanguage: "CN",
    };
  },
  mounted() {
    this.currentLanguage = localStorage.getItem("lang")
      ? localStorage.getItem("lang")
      : this.currentLanguage;
  },
};
</script>
<style lang="scss" scoped>
.smn {
  .smn-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    height: 410px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &.commonHeader{
        min-width: 1640px;
      }
      &:nth-of-type(2) {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .commonNav {
    /deep/ .nav {
      background: url("../../../assets/images/common/bg_nav.jpg") no-repeat;
      background-size: cover;
      box-shadow: 2.5px 4.33px 13px 0px rgba(0, 0, 0, 0.24);
      height: 170px;
    }
    /deep/ .container.position-relative {
      & > div {
        height: 55px;
      }
      line-height: 55px;
      & > div {
        width: 50%;
      }
    }
  }
  .smn-content {
    .container {
      padding: 80px 0px;
      & > div {
        background: #fff;
        box-shadow: 6px 10.392px 62px 0px rgba(0, 0, 0, 0.07);
        padding: 90px;
        border-radius: 30px;
        margin-top: 30px;
        font-size: 14px;
        img {
          max-width: 100%;
        }
        p {
          line-height: 30px;
          margin-bottom: 20px;
        }
        &.mainTitle {
          box-shadow: none;
          padding: 0px;
          border-radius: 0px;
          margin-top: 0px;
          font-size: 36px;
          color: #000;
          margin-bottom: 60px;
        }
      }
      .content-title {
        color: #8200ff;
        font-size: 24px;
        margin-bottom: 50px;
      }
      .content-subTitle {
        color: #8200ff;
        margin-bottom: 20px;
      }
      .reward-note {
        margin-top: 20px;
      }
    }
  }
}
</style>