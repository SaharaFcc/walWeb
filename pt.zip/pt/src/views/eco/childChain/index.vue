<template>
  <div class="childChain">
    <div class="childChain-head">
      <common-header/>
      <div>Public Child Chains</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span>Ecosystem</span>
          <span class="splitLine">/</span>
          <span class="currentRoute">Public Child Chains</span>
        </div>
      </div>
    </div>
    <common-nav :pageType="1" pageName="childChain" />
    <div class="childChain-content">
      <div>
        <div class="container">
          <div class="content-title font-weight-bold">
            {{ $t("childChain.paraOneTitle") }}
          </div>
          <div v-html="$t('childChain.paraOneContent')"></div>
        </div>
      </div>
      <div
        :style="
          currentLanguage === 'EN'
            ? 'display:block'
            : currentLanguage === 'KR'
            ? 'display:none'
            : ''
        "
      >
        <div class="container d-flex">
          <div class="col-md-6 position-relative">
            <img
              v-lazy="currentLanguage === 'EN' ? imgOneEn : ''"
              :key="currentLanguage === 'EN' ? imgOneEn : ''"
            />
            <div class="position-absolute mask-text">DMTC</div>
          </div>
          <div class="col-md-6">
            <div class="d-flex justify-content-center">
              <img
                v-lazy="currentLanguage === 'EN' ? imgTwoEn : ''"
                :key="currentLanguage === 'EN' ? imgTwoEn : ''"
              />
            </div>
            <p class="text-center">{{ $t("childChain.paraTwoContent") }}</p>
            <div class="font-weight-bold text-center">
              <span>{{ $t("childChain.detailText") }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
import CommonNav from "@/components/common/CommonNav.vue";
import CommonHeader from "@/components/common/CommonHeader.vue";
export default {
  components: {
    CommonNav,
    CommonHeader
  },
  name: "ChildChain",
  data() {
    return {
      currentLanguage: "CN",
      imgOneEn:
        "http://www.waltonchain.org/en/Uploads/2019-05-30/5cef9da018679.jpg",
      imgTwoEn:
        "http://www.waltonchain.org/en/Uploads/2019-05-30/5cef9d976e579.jpg",
    };
  },
  mounted() {
    this.currentLanguage = localStorage.getItem("lang")
      ? localStorage.getItem("lang")
      : this.currentLanguage;
  },
};
</script>
<style lang="scss" scoped>
.childChain {
  .childChain-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    height: 410px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &.commonHeader{
        min-width: 1640px;
      }
      &:nth-of-type(2) {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .commonNav {
    /deep/ .nav {
      background: url("../../../assets/images/common/bg_nav.jpg") no-repeat;
      background-size: cover;
      box-shadow: 2.5px 4.33px 13px 0px rgba(0, 0, 0, 0.24);
      height: 115px;
    }
    /deep/ .container.position-relative {
      & > div {
        height: 55px;
      }
      line-height: 55px;
      & > div {
        width: 50%;
      }
    }
  }
  .childChain-content {
    .content-title {
      color: #8200ff;
      font-size: 24px;
      margin-bottom: 50px;
    }
    & > div {
      .container {
        padding: 0px;
      }
      &:first-of-type {
        margin: 60px 0px;
      }
      &:last-of-type {
        background: #f1f1f1;
        padding: 30px 0px;
        transition: 0.3s;
        &:hover {
          background: #fff;
          box-shadow: 4.5px 7.794px 46px 0px rgba(0, 0, 0, 0.24);
          transition: 0.3s;
          .mask-text {
            font-weight: bold;
          }
        }
        .container {
          & > div {
            padding: 0px;
            &:first-of-type {
              &::before {
                content: "";
                background: rgba(0, 0, 0, 0.6);
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                border-radius: 30px;
              }
              img {
                width: 100%;
                height: 100%;
                border-radius: 30px;
              }
              div {
                font-size: 35px;
                color: #fff;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
              }
            }
            &:last-of-type {
              padding: 0px 30px;
              margin: 30px 70px 0px;
              p {
                margin-top: 68px;
              }
              & > div {
                &:last-of-type {
                  span {
                    border: 2px solid #8200ff;
                    border-radius: 30px;
                    height: 35px;
                    line-height: 35px;
                    color: #8200ff;
                    padding: 0px 30px;
                    display: inline-block;
                  }
                }
              }
            }
          }
        }
      }
      p {
        font-size: 16px;
        color: #555;
        line-height: 30px;
        margin-bottom: 20px;
      }
    }
  }
}
</style>