<template>
  <div class="kirin">
    <div class="kirin-head">
      <common-header />
      <div>KIRINMINER</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span class="currentRoute">KIRINMINER</span>
        </div>
      </div>
    </div>
    <div class="kirin-content">
      <div class="container">
        <div class="kirin-download">
          <div>
            <div class="d-flex justify-content-center">
              <img
                v-lazy="
                  currentLanguage === 'EN'
                    ? kirinEn
                    : currentLanguage === 'KR'
                    ? kirinKr
                    : ''
                "
                :key="
                  currentLanguage === 'EN'
                    ? kirinEn
                    : currentLanguage === 'KR'
                    ? kirinKr
                    : ''
                "
              />
            </div>
            <div class="d-flex justify-content-center">
              <a
                href="https://www.waltonchain.org/document/Kirinminer_User_Manual_EN.pdf"
              >
                <img
                  v-lazy="
                    currentLanguage === 'EN'
                      ? downloadOneEn
                      : currentLanguage === 'KR'
                      ? downloadOneKr
                      : ''
                  "
                  :key="
                    currentLanguage === 'EN'
                      ? downloadOneEn
                      : currentLanguage === 'KR'
                      ? downloadOneKr
                      : ''
                  "
                />
              </a>
            </div>
          </div>
          <div>
            <div class="d-flex justify-content-center">
              <img
                v-lazy="
                  currentLanguage === 'EN'
                    ? minerEn
                    : currentLanguage === 'KR'
                    ? minerKr
                    : ''
                "
                :key="
                  currentLanguage === 'EN'
                    ? minerEn
                    : currentLanguage === 'KR'
                    ? minerKr
                    : ''
                "
              />
            </div>
            <div class="d-flex justify-content-center">
              <a
                href="http://file.kirinpool.com/download/FINDMINER_1_0_0.zip?attname="
              >
                <img
                  v-lazy="
                    currentLanguage === 'EN'
                      ? downloadTwoEn
                      : currentLanguage === 'KR'
                      ? downloadTwoKr
                      : ''
                  "
                  :key="
                    currentLanguage === 'EN'
                      ? downloadTwoEn
                      : currentLanguage === 'KR'
                      ? downloadTwoKr
                      : ''
                  "
                />
              </a>
            </div>
          </div>
        </div>
        <div class="kirin-images">
          <template v-if="currentLanguage === 'EN'">
            <div v-for="(item, index) in imagesEn" :key="index">
              <img v-lazy="item" :key="item" />
            </div>
          </template>
          <template v-if="currentLanguage === 'KR'">
            <div v-for="(item, index) in imagesKr" :key="index">
              <img v-lazy="item" :key="item" />
            </div>
          </template>
        </div>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
import CommonHeader from "@/components/common/CommonHeader.vue";
export default {
  name: "Kirin",
  data() {
    return {
      imagesEn: [
        "http://www.waltonchain.org/en/Uploads/2019-04-24/5cc021699b14e.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-24/5cc0216a69f9c.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-24/5cc02175126c0.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-24/5cc021756d0c7.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-24/5cc02175e7ef8.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-24/5cc02176aaaef.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-24/5cc0217740988.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-30/5cc80404dd075.jpg",
      ],
      imagesKr: [
        "http://www.waltonchain.org/kr/Uploads/2019-06-11/5cff48a174010.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-06-11/5cff48a310752.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-06-11/5cff48a3d7a2e.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-06-11/5cff48a466d38.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-06-11/5cff48a51a9cb.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-06-11/5cff48a5b94f7.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-06-11/5cff48a646c6f.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-06-11/5cff48a6e52eb.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-06-11/5cff48a799bac.jpg",
      ],
      kirinEn:
        "http://www.waltonchain.org/en/Uploads/2019-06-10/5cfe27777ac7a.jpg",
      kirinKr:
        "http://www.waltonchain.org/kr/Uploads/2019-06-11/5cff489f2dbb7.jpg",
      minerEn:
        "http://www.waltonchain.org/en/Uploads/2019-06-10/5cfe2903660c5.jpg",
      minerKr:
        "http://www.waltonchain.org/kr/Uploads/2019-06-11/5cff48a04f021.jpg",
      downloadOneEn:
        "http://www.waltonchain.org/en/Uploads/2019-06-10/5cfe2777e843b.jpg",
      downloadOneKr:
        "http://www.waltonchain.org/kr/Uploads/2019-06-11/5cff489fd31f1.jpg",
      downloadTwoEn:
        "https://www.waltonchain.org/en/Uploads/2019-06-10/5cfe2777e843b.jpg",
      downloadTwoKr:
        "http://www.waltonchain.org/kr/Uploads/2019-06-11/5cff48a0c6d32.jpg",
      currentLanguage: "CN",
    };
  },
  components: {
    CommonHeader,
  },
  mounted() {
    this.currentLanguage = localStorage.getItem("lang")
      ? localStorage.getItem("lang")
      : this.currentLanguage;
  },
};
</script>
<style lang="scss" scoped>
.kirin {
  .kirin-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    height: 410px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &.commonHeader {
        min-width: 1640px;
      }
      &:nth-of-type(2) {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .kirin-content {
    .container {
      padding: 0px;
      .kirin-download {
        & > div {
          &:first-of-type {
            margin-top: 40px;
          }
          &:not(:first-of-type) {
            margin-bottom: 40px;
          }
        }
      }
    }
  }
}
</style>