<template>
  <div class="eco">
    <router-view />
  </div>
</template>