<template>
  <div class="bluePaper">
    <div class="bluePaper-head">
      <div>Waltonchain Global Community Autonomy Blue Paper</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span>WTA(Blue Paper)</span>
          <span class="splitLine">/</span>
          <span class="currentRoute"
            >Waltonchain Global Community Autonomy Blue Paper</span
          >
        </div>
      </div>
    </div>
    <common-nav :navList="navList" />
    <div class="bluePaper-content">
      <div class="container">
        <div class="profile" id="profile">
          <div class="content-title">I. Waltonchain Profile</div>
          <div>
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2019-10-22/5daebe2618532.png'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2019-10-22/5daebe2618532.png'"
            />
          </div>
          <p>
            Waltonchain is an open-source underlying public business ecochain.
            As the leader of blockchain + the IoT, Waltonchain uniquely
            integrates blockchain and RFID technology to promote industry
            transformation and upgrading by serving the real economy with
            blockchain technology.
          </p>
          <p>
            Waltonchain combines the decentralization and immutability of
            blockchain with RFID chips developed in-house to provide
            traceability and certification solutions for various industries as
            well as encryption services and distributed database building for
            industrial data.
          </p>
          <p>
            Waltonchain aims to create a fair, transparent, traceable and
            credible new-generation business ecosystem. Based on the blockchain
            technology, Waltonchain constructs a VIoT (Value Internet of Things)
            ecosystem where blockchain merges with the IoT relying on devices,
            network, value and data. Its business applications include food
            traceability, luxury goods identification, seafood transportation
            tracking, logistics tracking and will be further diversified.
          </p>
          <p>Waltonchain Ecosystem Development Process:</p>
          <p>
            1. After the launch and open source of the Fully Operational
            Mainnet, Waltonchain has realized cross-chain data endorsement and
            has started token swap;
          </p>
          <p>
            2. Hardware products developed by Waltonchain in-house, including
            KIRINMINER, Bamboo Wallet, blockchain + RFID chips and Blockchain
            Data Collection Terminal, have been gradually applied in the
            ecosystem.
          </p>
          <p>
            3. Steady ecosystem development and active cooperation with various
            industries to implement child chains and relevant projects in
            logistics, liquor, agriculture traceability and other fields.
          </p>
          <p>
            In the course of the ecosystem development, we have realized that
            only when community supporters become the leaders and decision
            makers can an unprecedented new business ecosystem be created.
          </p>
        </div>
        <div class="ecosystem" id="ecosystem">
          <div class="content-title">II. Autonomous Ecosystem</div>
          <p>
            The vision of Waltonchain is to lead people into a reliable digital
            life using the blockchain technology and thus achieve consensus,
            co-governance, sharing and connection of IoT data and services in
            the information era. Currently, the Waltonchain ecosystem is under
            steady development. Next, we wish community supporters can become
            the leaders and decision makers to gather innovative ideas and
            initiatives from the community and expand the Waltonchain ecosystem
            massively.
          </p>
          <p>
            In order make WTC application more stable in the cross-chain IoT
            ecosystem and reduce the impact of market behavior on the WTC price
            fluctuation, Walton Chain Foundation issues Waltonchain Autonomy
            token (WTA) on the Waltonchain mainnet and establishes the
            Autonomous Foundation.
          </p>
          <p>
            Waltonchain Autonomous Foundation will exert the strengths of global
            supporters to jointly build the Waltonchain ecosystem and further
            promote and expand its application in various fields around the
            world to make it truly decentralized.
          </p>
          <p>
            This Community Autonomy Blue Paper outlines a detailed plan for
            Waltonchain community autonomy and covers its constitution as well
            as benefits, rights and obligations of the participants. All
            Waltonchain community autonomy members have the right to enjoy
            Waltonchain ecosystem benefits and must also fulfill their
            obligations in accordance with the requirements specified herein to
            contribute to the development of the Waltonchain ecosystem.
          </p>
        </div>
        <div class="autoToken" id="autoToken">
          <div class="content-title">III. Waltonchain Autonomy Token</div>
          <div>
            <div class="content-subTitle">3.1 WTA Mechanism</div>
            <div>
              <div class="d-flex mechanism-tip">
                <div class="font-weight-bold">Token name:</div>
                <div>WTA (Waltonchain Autonomy)</div>
              </div>
              <div class="d-flex mechanism-tip">
                <div class="font-weight-bold">Total supply:</div>
                <div>500,000,000</div>
              </div>
              <div>
                <div class="font-weight-bold">Distribution rules:</div>
                <div>
                  <div>Pre-mining (pre-staking) (7%): 35,000,000</div>
                  <div>Reward Pool (3%): 15,000,000</div>
                  <div>Staking (90%): 450,000,000</div>
                </div>
              </div>
            </div>
            <div class="d-flex justify-content-center">
              <img
                v-lazy="
                  'http://www.waltonchain.org/en/Uploads/2019-10-22/5daeb59081404.png'
                "
                :key="'http://www.waltonchain.org/en/Uploads/2019-10-22/5daeb59081404.png'"
              />
            </div>
            <div>
              <div class="content-subTitle">
                Pre-mining (pre-staking): 7%, 35,000,000 WTA
              </div>
              <div class="font-weight-bold">
                The pre-mining period is 7 days. Walton Chain Foundation commits
                to buy back the pre-mined WTA at the ratio of 1 WTC = 9 WTA one
                year after the issuance of WTA.
              </div>
              <p>
                Users participating in pre-mining will have an equivalent WTA
                buyback quota. All the WTA mined in the pre-mining period will
                be bought back.
              </p>
              <div>
                <div class="font-weight-bold">
                  1. Pre-mining for SMN and GMN Users
                </div>
                <div>
                  <span class="font-weight-bold"
                    >Total amount: 25,000,000 WTA.</span
                  >
                  <span>
                    SMN and GMN users will not lose their corresponding identity
                    by participating in the pre-mining; instead, they will
                    receive WTA airdrops. After the pre-mining period ends,
                  </span>
                  <span class="font-weight-bold">
                    the remaining not pre-mined portion shall be added to the
                    Autonomous Ecosystem Reward Pool.
                  </span>
                </div>
                <div>
                  <span class="font-weight-bold"
                    >SMN participation method:</span
                  >
                  <span>
                    During the pre-mining period, SMN users can participate in
                    360-day lock-up staking to obtain WTA airdrop at a ratio of
                    1:1 (WTC:WTA). 2% of the WTA airdrop will be released after
                    the pre-mining period ends, and the remaining 98% will be
                    completely released in 7 months after 3 months of formal
                    staking, i.e. 14% each month (distributed daily). The
                    minimum lock-up amount shall be 100,000 WTC. The WTC
                    participating in the 360-day lock-up staking will be
                    unlocked on day 361.
                  </span>
                </div>
                <div class="d-flex justify-content-center">
                  <img
                    v-lazy="
                      'http://www.waltonchain.org/en/Uploads/2019-10-22/5daeb5c1e403e.png'
                    "
                    :key="'http://www.waltonchain.org/en/Uploads/2019-10-22/5daeb5c1e403e.png'"
                  />
                </div>
                <div>
                  <span class="font-weight-bold"
                    >GMN participation method:</span
                  >
                  <span>
                    During the pre-mining period, GMN users holding 10,000 WTC
                    or more can participate in 360-day lock-up staking to obtain
                    WTA airdrop at the ratio shown in the table below. 2% of the
                    WTA airdrop will be released after the pre-mining period
                    ends, and the remaining 98% will be completely released in 7
                    months after 3 months of formal staking, i.e. 14% each month
                    (distributed daily). The minimum lock-up amount shall be
                    10,000 WTC. The WTC participating in the 360-day lock-up
                    staking will be unlocked on day 361.
                  </span>
                </div>
                <div class="d-flex justify-content-center">
                  <img
                    v-lazy="
                      'http://www.waltonchain.org/en/Uploads/2019-10-22/5daeb5d3963fa.png'
                    "
                    :key="'http://www.waltonchain.org/en/Uploads/2019-10-22/5daeb5d3963fa.png'"
                  />
                </div>
              </div>
              <div>
                <div class="font-weight-bold">2. Pre-mining for All Users</div>
                <div>
                  <span>Total 10,000,000 WTA.</span>
                  <span class="font-weight-bold">
                    The remaining not pre-mined portion shall be added to the
                    Autonomous Ecosystem Reward Pool.
                  </span>
                </div>
                <p>
                  All WTC holders can exchange WTC for WTA at the ratio shown in
                  the table below. 2% of this portion will be released after the
                  pre-mining period ends, and the remaining 98% will be
                  completely released in 7 months after 3 months of formal
                  staking, i.e. 14% each month (distributed daily).
                </p>
              </div>
              <div class="d-flex justify-content-center">
                <img
                  v-lazy="
                    'http://www.waltonchain.org/en/Uploads/2019-10-22/5daeb5f297a4d.png'
                  "
                  :key="'http://www.waltonchain.org/en/Uploads/2019-10-22/5daeb5f297a4d.png'"
                />
              </div>
            </div>
            <div>
              <div class="content-subTitle">
                Reward Pool: 3%, total 15,000,000 WTA to reward community
                autonomy contributors.
              </div>
              <div class="content-subTitle">
                Staking: 90%, total 450,000,000 WTA
              </div>
              <p>
                Staking means lock-up of WTC to receive WTA. The minimum lock-up
                amount shall be 200 WTC. Each day, 20,000 WTA can be received
                for staking in the pool and withdrawn after release. The pool
                can be staked for about 60 years.
              </p>
              <div>
                <div class="font-weight-bold">Staking rewards formula:</div>
                <div>
                  <div>My Hash Rate = Lock-up Amount × Time Coefficient</div>
                  <div>
                    Daily Rewards = My Hash Rate / Total Hash Rate × 20,000 WTA
                  </div>
                  <div class="d-flex justify-content-center">
                    <img
                      v-lazy="
                        'http://www.waltonchain.org/en/Uploads/2019-10-22/5daeb6132c3ae.png'
                      "
                      :key="'http://www.waltonchain.org/en/Uploads/2019-10-22/5daeb6132c3ae.png'"
                    />
                  </div>
                  <div>
                    Each user can have several simultaneous lock-up staking
                    orders.
                  </div>
                  <div>
                    For orders with lock-up period of 15, 30, 60, 90 and 180
                    days, early exit is not allowed.
                  </div>
                  <div>
                    For orders with lock-up period of 270 and 360 days, early
                    exit is allowed only after the orders have been locked for
                    at least 180 days and a service fee is charged.
                  </div>
                  <div>For pre-mining orders, early exit is not allowed.</div>
                  <div>
                    Service Fee = (Remaining Days / Lock-up Period) × Lock-up
                    Amount × 0.2
                  </div>
                  <div>
                    Example: If a user locked up 5,000 WTC for a period of 360
                    days, then 180/360 × 5,000 WTC × 0.2 = 500 WTC will be
                    charged as service fee if the user exits early on day 181.
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div>
            <div class="content-subTitle">3.2 WTA Utilization</div>
            <div>
              <div class="font-weight-bold">3.2.1 Do Tasks, Earn Points</div>
              <p>
                Waltonchain Global Autonomous Foundation will irregularly launch
                tasks for the community; and community members can earn points
                by completing these tasks. The points can be converted into WTA
                at a certain ratio. Board of Directors and project managers of
                the Autonomous Foundation can post public bids on the task
                platform of the Autonomous Foundation (including task
                requirements, time requirement and rewards amount, etc.). The
                tasks will be open to the whole community; and their performance
                by the Members of the Autonomous Foundation will be preferred.
                After completing the tasks, task performers shall submit the
                corresponding reports to earn points. Community members who have
                completed a certain amount of tasks will receive additional
                rewards from the Autonomous Foundation or will become project
                managers and long-term partners under the Board of Directors.
              </p>
            </div>
            <div>
              <div class="font-weight-bold">3.2.2 Discounts</div>
              <p>
                The upcoming public Child Chain Platform will support exchange
                between child chain tokens and WTC as well as exchange between
                child chain tokens on the Waltonchain mainnet. WTA will be used
                to deduct service fee during the token exchange.
              </p>
              <p>
                WTA can be used to deduct partial service fees for trading on
                the exchange or OTC platform under the Waltonchain Ecosystem.
                Details will be announced further by the respective platforms.
              </p>
            </div>
            <div>
              <div class="font-weight-bold">3.2.3 Child Chain Platform</div>
              <div>
                <span class="font-weight-bold">
                  WTA will be used as support funds to launch child chains and
                  obtain child chain tokens.
                </span>
                <span>
                  Top three child chains that receive the highest amount of WTA
                  support each month will be given priority to launch on the
                  Child Chain Platform, and will have the opportunity to receive
                  financial and resource support from the Walton Chain
                  Foundation. Details will be further announced when the Child
                  Chain Platform is launched.
                </span>
              </div>
            </div>
            <div>
              <div class="font-weight-bold">3.2.4 Waltymall</div>
              <p>
                WTA can be used to deduct the price of commodities on Waltymall.
                Details will be further announced on the Mall.
              </p>
              <p>
                Autonomous Foundation Members also have the right to list
                commodities on the Mall through WTA collateral.
              </p>
            </div>
          </div>
        </div>
        <div class="foundation" id="foundation">
          <div class="content-title">IV. Autonomous Foundation</div>
          <div>
            <div class="content-subTitle">4.1 Constitution</div>
            <p>
              1. This Constitution is formulated to standardize the operation of
              the Waltonchain Global Autonomous Foundation (hereinafter referred
              to as the “Autonomous Foundation”), effectively exert the
              decision-making and supervision functions of the Autonomous
              Foundation, maintain the secure and stable operation of the
              Waltonchain mainnet, and jointly establish the Waltonchain global
              ecosystem community.
            </p>
            <p>
              2. The Autonomous Foundation is composed of Members and the Board
              of Directors. Both shall be responsible for the operation and
              management of the Autonomous Foundation and perform corresponding
              responsibilities.
            </p>
            <p>
              3. Users with WTA hash rate will automatically become the Members
              of the Autonomous Foundation. Members have the right to propose,
              vote and comment issues posted on the Waltonchain Autonomous
              Platform in relation to the development of the Waltonchain
              ecosystem.
            </p>
            <p>
              4. Members of the Autonomous Foundation must perform their
              obligations with integrity and diligence to ensure abiding by the
              Constitution of the Autonomous Foundation as well as focus on
              safeguarding the interests of the Waltonchain global community and
              interested parties.
            </p>
            <p>
              5. Board of Directors of the Autonomous Foundation shall be
              elected by voting from the Members of the Autonomous Foundation
              for a term of one year. Board of Directors shall have the final
              voting right on proposals. Members who have 360-day lock-up
              staking orders can participate in the election. Each Member of the
              Autonomous Foundation only has one vote which can only be given to
              one candidate. Top 15 candidates with the highest votes shall be
              appointed Directors of the Autonomous Foundation.
            </p>
            <p>
              6. All the Members of the Autonomous Foundation shall have the
              right and obligation to raise and spread proposals that are
              conducive to the development of Waltonchain. After a round of
              voting by all the Members, the proposals passed shall be submitted
              to the Board of Directors for final voting.
            </p>
            <p>
              7. The Board of Directors shall bear the final responsibility of
              cost management of the Autonomous Foundation and make sure that
              voting is performed properly according to cost calculation
              consistent with the current ecosystem development.
            </p>
            <p>
              8. Resignation of Directors. When a Director of the Autonomous
              Foundation resigns from the Board out of personal reasons, it
              shall be supplemented from the Members of the Autonomous
              Foundation.
            </p>
            <p>
              9. Removal of Directors. If behavior of a Director of the
              Autonomous Foundation is harmful to the interests of Waltonchain
              and the Waltonchain community, any member of the Autonomous
              Foundation may provide evidence and initiate voting to remove the
              Director from the Autonomous Foundation and recover the losses
              incurred by the Autonomous Foundation.
            </p>
            <p>
              10. Walton Chain Foundation shall keep the fund of the Autonomous
              Foundation and allocate it to execute proposals. All the Members
              of the Autonomous Foundation and Walton Chain Foundation shall
              jointly supervise the execution and effect of the proposals.
            </p>
          </div>
          <div>
            <div class="content-subTitle">4.2 Members</div>
            <div>
              <div class="font-weight-bold">4.2.1 Benefits</div>
              <p>
                1. Members can raise proposals on the development of the
                Waltonchain ecosystem and obtain rewards once the proposals pass
                the voting by all Members and Directors. Rewards shall be 500 to
                10,000 WTA; the exact amount shall be determined by the Board of
                Directors as appropriate.
              </p>
              <p>
                2. WTA and child chain token airdrops shall be distributed once
                every three months as per the community participation of Members
                (community participation includes number of votes, number of
                proposals, number of executed proposals, membership period,
                etc.).
              </p>
            </div>
            <div>
              <div class="font-weight-bold">4.2.2 Rights</div>
              <p>
                Members are the core of the Autonomous Foundation. They shall
                have the right to raise proposals, vote and supervise the Board
                of Directors of the Autonomous Foundation.
              </p>
            </div>
            <div>
              <div class="font-weight-bold">4.2.3 Obligations</div>
              <p>
                Members shall continuously have WTA hash rate. Once a member has
                no hash rate, it shall lose the membership.
              </p>
            </div>
            <div>
              <div class="font-weight-bold">4.2.4 How to Become a Member?</div>
              <p>
                Applicants shall lock WTC for staking to become a Member. After
                the Member identity is activated on the Autonomous Foundation
                Platform, WTA staking rewards shall be distributed to the
                Member.
              </p>
            </div>
          </div>
          <div>
            <div class="content-subTitle">4.3 Board of Directors</div>
            <p>
              Board of Directors is the core representative of the Autonomous
              Foundation. It shall have the final voting and decision right on
              child chains, Mall, exchanges, DApps and technical development
              under the Waltonchain ecosystem, as well as on the future
              ecosystem constitution.
            </p>
            <div>
              <div class="font-weight-bold">4.3.1 Election of Directors</div>
              <p>
                Directors shall be elected once a year for term of one year.
                Before each election, Members of the Autonomous Foundation can
                apply to become candidates. Candidates shall submit the required
                election documents to the Autonomous Community. After the
                application period ends, each Member shall give its vote to one
                candidate. Top 15 candidates with the highest votes shall be
                appointed Directors of the Autonomous Foundation.
              </p>
            </div>
            <div>
              <div class="font-weight-bold">4.3.2 Benefits of Directors</div>
              <div>
                <span class="font-weight-bold">WTC rewards</span>
                <span>
                  shall be distributed to Directors of the Autonomous Foundation
                  every 6 months as per their contribution to the community.
                </span>
                <span class="font-weight-bold">
                  The total reward pool shall be 30,000 WTC.
                </span>
                <span>
                  Directors can also enjoy higher WTA deduction when buying
                  KIRINMINER.
                </span>
              </div>
            </div>
            <div>
              <div class="font-weight-bold">4.3.3 Obligations of Directors</div>
              <p>
                Directors shall continuously have WTA hash rate during their
                one-year term of office, otherwise their qualification shall be
                cancelled automatically. If a Director waives his qualification,
                the vacancy shall be filled by the candidate who ranks No. 16.
              </p>
            </div>
            <div>
              <div class="font-weight-bold">4.3.4 Rights of Directors</div>
              <div class="font-weight-bold">Ecosystem Decision-making</div>
              <div class="d-flex justify-content-center">
                <img
                  v-lazy="
                    'http://www.waltonchain.org/en/Uploads/2019-10-22/5daeb78875f99.png'
                  "
                  :key="'http://www.waltonchain.org/en/Uploads/2019-10-22/5daeb78875f99.png'"
                />
              </div>
              <p>
                All the Members of the Autonomous Foundation shall have the
                right to decide on and provide capital support for child chains,
                Mall, exchanges, DApps, technology development and the future
                ecosystem components.
              </p>
              <div class="font-weight-bold">
                Note: Waltonchain team shall have the right of final
                interpretation of the Blue Paper.
              </div>
            </div>
          </div>
        </div>
        <div class="quality" id="quality">
          <div class="content-title">V. Q&A</div>
          <div>
            <div class="font-weight-bold">
              1. What is WTA and why is WTA needed?
            </div>
            <div>
              <span>
                WTA is the new Waltonchain Autonomy token issued on the
                Waltonchain mainnet.
              </span>
              <span class="font-weight-bold">
                It does not replace WTC as the mainnet/parent-chain coin.
              </span>
              <span>
                WTA is a child-chain token for a specific, within-ecosystem
                purpose, namely to facilitate the Waltonchain Autonomous
                Foundation and introduce a dynamic form of Proof of Stake (PoS)
                to WTC.
              </span>
            </div>
          </div>
          <div>
            <div class="font-weight-bold">2. What's the value of WTA?</div>
            <p>
              Within the pre-mining period, 1 WTC equals 12 to 10 WTA. At the
              official issuance, 1 WTC equals 10 WTA. After listing on
              exchanges, the market value of WTA will fluctuate. Walton Chain
              Foundation commits to buy back the 35,000,000 pre-mined WTA at the
              ratio of 9 WTA = 1 WTC one year after the issuance of WTA.
            </p>
          </div>
          <div>
            <div class="font-weight-bold">3. Is the WTA code secure?</div>
            <p>
              Yes! The smart contract has been fully audited and approved by
              CertiK as part of the recent comprehensive mainnet audit.
            </p>
          </div>
          <div>
            <div class="font-weight-bold">
              4. Does the Blue Paper affect the previously announced SMN
              cross-chain rewards, GMN and PoS rewards?
            </div>
            <div>
              Not in the least. Walton Chain Foundation commits to provision of
              the previously announced GMN and PoS rewards (see
              <a
                href="https://www.waltonchain.org/doc/Waltonchain_Progressive_Mining_Reward_Program.pdf"
                target="_blank"
                >Waltonchain Progressive Mining Reward Program</a
              >) and SMN cross-chain rewards.
            </div>
          </div>
          <div>
            <div class="font-weight-bold">
              5. Can holders of ERC-20 WTC participate in WTA staking?
            </div>
            <p>
              They sure can. WTA pre-mining and staking supports both ERC-20 WTC
              tokens and mainnet Waltoncoin. When WTA are bought back after the
              lock-up period ends, holders will receive mainnet WTC.
            </p>
          </div>
          <div>
            <div class="font-weight-bold">
              6. Does a GMN with 15,000 WTC benefit from the WTC Pre-lockup (for
              one year locked in total) more than one with 10,000 WTC?
            </div>
            <p>
              Yes! The ratio increases from [1:0.4] to [1:0.5] when you have
              more than 15,000. That’s a 10% increase from 40% to 50%. If you
              have 5,000 WTC only, you need to obtain 5,000 more WTC to
              participate as a GMN. If you are an owner of multiple GMNs or wish
              to join hands with another GMN owner, you are eligible for the
              pre-lockup. More details are to be announced separately.
            </p>
          </div>
          <div>
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2019-10-22/5daebd383650e.png'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2019-10-22/5daebd383650e.png'"
            />
          </div>
          <div>
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2019-10-22/5daebd443f406.png'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2019-10-22/5daebd443f406.png'"
            />
          </div>
          <div>
            <div class="font-weight-bold">
              7. Why lock WTC? How does that benefit the ecosystem?
            </div>
            <p>
              Locking coins adds a key structural component in the ecosystem by
              allowing the Autonomous Foundation’s Directors and members to
              prove a stake in the ecosystem while completing tasks such as
              electing Directors, executing proposals, voting and rewarding
              community initiatives. As a secondary tokenomics benefit, locked
              coins mean lower selling pressure on the markets. Lower selling
              pressure + normal buying pressure + increased real ecosystem usage
              (requiring parent chain WTC) = increased valuation of WTC.
              However, this is not guaranteed to occur as markets are
              unpredictable and should be assessed on an individual basis. In
              other words, this is not financial advice.
            </p>
          </div>
        </div>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
import CommonNav from "@/components/common/CommonNav.vue";
export default {
  components: { CommonNav },
  name: "BluePaper",
  data() {
    return {
      navList: [
        {
          name: "Waltonchain Profile",
          id: "profile",
        },
        {
          name: "Autonomous Ecosystem",
          id: "ecosystem",
        },
        {
          name: "Waltonchain Autonomy Token",
          id: "autoToken",
        },
        {
          name: "Autonomous Foundation",
          id: "foundation",
        },
        {
          name: "Q&A",
          id: "quality",
        },
      ],
    };
  },
};
</script>
<style lang="scss" scoped>
.bluePaper {
  .bluePaper-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 180px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &:first-of-type {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .commonNav {
    /deep/ .nav {
      background: url("../../../assets/images/common/bg_nav.jpg") no-repeat;
      background-size: cover;
      box-shadow: 2.5px 4.33px 13px 0px rgba(0, 0, 0, 0.24);
      height: 55px;
    }
    /deep/ .container.position-relative {
      & > div {
        height: 100%;
      }
      line-height: 55px;
      & > div {
        width: 228px;
      }
    }
  }
  .bluePaper-content {
    padding: 80px 0px;
    .container {
      max-width: 1140px;
      padding: 0px;
      & > div {
        padding: 90px;
        font-size: 14px;
        box-shadow: 6px 10.392px 62px 0px rgba(0, 0, 0, 0.07);
        border-radius: 30px;
        &:not(:last-of-type) {
          margin-bottom: 30px;
        }
        img {
          max-width: 100%;
        }
        div,
        p {
          line-height: 28px;
          margin-bottom: 20px;
        }
        .mechanism-tip {
          margin-bottom: 0px;
        }
        .content-title {
          color: #8200ff;
          font-size: 24px;
          font-weight: 600;
          margin-bottom: 50px;
        }
        .content-subTitle {
          color: #8200ff;
          font-size: 18px;
          font-weight: 600;
        }
        a {
          color: #00ffda;
          text-decoration: none;
          &:hover {
            color: #000;
          }
        }
      }
    }
  }
}
</style>