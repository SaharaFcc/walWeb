<template>
  <div class="wta">
      <router-view/>
  </div>
</template>