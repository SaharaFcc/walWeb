<template>
  <div class="tokenSwap">
    <div class="tokenSwap-head">
      <div>SMN & GMN Token Swap</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span class="currentRoute">SMN & GMN Token Swap</span>
        </div>
      </div>
    </div>
    <div class="tokenSwap-content">
      <div class="container">
        <div class="content-title font-weight-bold">
          SMN & GMN Token Swap Status (updating...)
        </div>
        <div>
          <div>
            <img src="@/assets/images/wtc/tokenSwap/img_1.jpg" alt="" />
            <p>
              Waltonchain started <a>token swap for SMN & GMN users</a> on May
              10, 2020.
            </p>
          </div>
          <div>
            <div class="content-subTitle font-weight-bold">SMN</div>
            <p>
              Up till 12:00 UTC+8 on November 2, 2020, 4 SMNs have joined the
              token swap (40% of all 10 SMNs).
            </p>
            <p>1. 0x2344Bd4BD96D185dC5ef450da6752f448A7E1106</p>
            <p>2. 0x70B489ab7C41C5eF60be5D5cB742472b412300c7 (also a GMN)</p>
            <p>3. 0xf3e702cbAb82703EaaB7FC7150A94503f449798c (also a GMN)</p>
            <p>4. 0xebf22982230aC915A778bA8b8139C95f7253dFB5</p>
          </div>
          <div>
            <div class="content-subTitle font-weight-bold">GMN</div>
            <p>
              Up till 12:00 UTC+8 on November 2, 2020, 366 GMNs have joined the
              token swap (42.6% of all 859 GMNs).
            </p>
            <p v-for="(item, index) in gmnList" :key="index">
              {{ index + 1 }}.{{ item }}
            </p>
            <p>
                (updated on November 2, 2020)
            </p>
          </div>
        </div>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
export default {
  name: "TokenSwap",
  data() {
    return {
      gmnList: [
        "0xBCBE473DD45a36a97Ee612Ccf5b8b8bEA77153DA",
        "0x4551171E62a89136421e50Cc790625fa979d9caE",
        "0xb462d9F7F780242671ae07AabFbf9a44b6273ac7",
        "0x9740729D517FFA63527408C562dd540078b16633",
        "0xD4d1B95Af791c5ce685CB8d254172dF77Edba4e3",
        "0x74c502C2F91c37776E83C00EDbB2c7C97dbe6fE4",
        "0xA11d5e1623E70Cc28016cE9AC69bB47db52Fa323",
        "0xcF421eA1A520818c05ec1AAEa0D8CCb74CdA2acd",
        "0xCB86b457F3eEFf0E0aF5f9e5FcAFfa313E7809CD",
        "0xF6b08eD894CE3bd1364838c60aA17d18DcF08aff",
        "0x1B59A0A96E3416c8f4Ec78FB2b16A159F4F0e1A7",
        "0x70B489ab7C41C5eF60be5D5cB742472b412300c7",
        "0x341fB61963bfB7EA6a132Dd276fCF94Da774c799",
        "0x794341CA3Cc26532d0BA2268feECe727e688e7BC",
        "0xB63503dA3bfAB5626e2A91c4cD94fB59679f6876",
        "0x8EdaC4Ed96a22eF7Df5f97E3e4042c067Df90c5c",
        "0x086833f7a48Eca35A3d7125a48ca3c52F4554aF7",
        "0xf3e702cbAb82703EaaB7FC7150A94503f449798c",
        "0x28af543c1A5FB3e842eA712D0083e34494B284FB",
        "0xff1C8848e216D43FDE952CF71e15169aa3fD2e23",
        "0x4E742a40D75BC258714CEeD2241bB07a9F00ceDb",
        "0xfaF9ee93AD856F5025f8c721329073C7c3c89864",
        "0x3eeb08a6cdC2Eb7bEfbC21ECC5ff4fc8B79A24fd",
        "0xA6F170D4E2626eEC8DCaab6aD20Cb52BEb82fAD0",
        "0xcd3148E0BF80485f1F30d8B0A69e033F5F8F9755",
        "0x9684353a7517663ED36aCB28b19dB77E6c7e4B63",
        "0x46c916933dE7c163e2173a536695Eb687668fACd",
        "0xcdEC2a846B030F5b8DDB7629591AB2c942003e56",
        "0x3c34ee0dDbE6BCE5a8a09aaE2b39233D99313B31",
        "0x9Fb61a893a3888cD82aFf539781301F296F5CF78",
        "0x89C3FC3b9f6b6dD099e903F8ed9e1d94fC7EF602",
        "0x8D55C101c0690573cD2d004EfA7c42CCe7055791",
        "0x001cb0d5231880AC1228609b12948Ac5a64189dc",
        "0x07661F3926b5AD1B86483c90d6697A5e8e0c4CF2",
        "0xb255Fd85f2a930d4Df42c8f3293d0e042AaFF4f8",
        "0x1c27e1fe3ed8fD2435157C160106CD99eD1c14F1",
        "0xd0a232fB7E8147929868856Ca13c348B763980eB",
        "0x8FaE2Ab79dE352764d8F65529D8F6D7B1365D0Bf",
        "0x1d9d877660F36340c173506D7F906A20366e95DD",
        "0x90eB991A4CF0202E12ac07029d000080c84ff24B",
        "0x5D1B31a1c5973a0c1b80D47fED04F9bC35491471",
        "0x04a5bc0a5094adf95d3abee3fd166061fec21947",
        "0x56fc4260da0438237bf39c6f6a1e6e043ef347af",
        "0xf3b7ec10cf9ed7177209d703e9993c578e5eff04",
        "0xae83c461f9c54affb5cc89dbabe1c6de334f6d8f",
        "0x829ffd4a53158cc7bca5667cc704192a5bf415c2",
        "0x22f830a7a3bc5d67fce81ddff153f88e0861099c",
        "0x2ce4e29de37297200efee344c31b66a2f7200604",
        "0xd894199fa41813f68e9b16f08c21b805e0f6d5d5",
        "0x59e7a17df7670fdebef3e822236003b5593b5a1a",
        "0x5d34eba92a03601870c50349e5d856d24e473963",
        "0x33e7e9d9328795fea1870ae69e063efca0f62c56",
        "0x4c1d7fda665344e4682590f00330e761a17d3a5c",
        "0x26c5ea5b1d39875a0ee3add4e1a9a55fd995337f",
        "0xd7fe73c1937e6097ccb984c62906b23ba7a07ca2",
        "0xb765c77f6e2146fa76c2f9672dc734b589aaa6a0",
        "0x630497ef4e9d27e93bbd96a829a1b33064671820",
        "0x5965ec94c6594121e555b4f5880f8a1dac027b7c",
        "0x98a48587c7403124424967fc3f5cd7276e505471",
        "0x7bcce15a13ac106d1ffe35fc7a72cc0ed253975c",
        "0xec2a13dd2e2ae99382c9fc4ae7a321276274c586",
        "0x2525b13a29839bc06efc5d74884dbc84cbe1cc18",
        "0x25ff1ccfa7205387b1874bb435588e60ff2d3f99",
        "0xaab30bebd9831e86a323c2ff7378f21df3d10dd0",
        "0x060d4c6fbfc0569d6f88403af4fc21d0b2a7518d",
        "0xd15275e1b8019d2a4aaffc6ddecf497b13c1f7e9",
        "0xb1a3e1bb64cfdd54dfe8deca59df964da6849836",
        "0xdce3d1221dc1bf4263c7337068b41fc69baacec1",
        "0x1aa6ad985a32344f90392600edb705838b9e09a9",
        "0x3b6010784c4561bd107fb8d12f2904959a99ddd7",
        "0x766d2c2bbd9d10b59233ce8cb5425a1f9c71e3ef",
        "0xb6bdfef9e239ba2ede1ffe2110ec87e9c5e9b2ef",
        "0xf2e514209e87690bd6233b74dd3f7fb99e3074a8",
        "0x191adf2f9c7ba7d0dbd0fb09696477dddea732e9",
        "0x5D1e028AaE2F0f6d0E34AE2570F138D129f7245c",
        "0x7b8663ad45704ec91cf5de9ff0e16f6ca312389d",
        "0xf6838749d4b6d9f457dc4011ac47b49f83e94a25",
        "0xd3156e8b71cc12513295e525b07a551af84f264c",
        "0xe561c3a2c1fbcf8d95fca8e1ac482f8da3f15b56",
        "0x91968e4bde01e1dd5d595ae4d5caf306797b6d87",
        "0x3ab5f96bd92bdafe200aff5b55733b9c9c70984b",
        "0x92d6e8d14f46d31c528afff80bfe1f0398ababaa",
        "0x1834b93975b9f858ee75dc83236b7ebfd3cf2c3d",
        "0x6ec0ca682dc650f9ca900e39e3cf6fdda4b3246a",
        "0x9f864db4aa96c1a24bcf203e8899ce9cdc0c6214",
        "0x5b75a9be880d0b76a561edab639309147acc4b2e",
        "0xa1bd5c40f8d917e3155d499463451f2587bd668d",
        "0x752d17e5ab24a8fe6321a27891393bdf731a32a7",
        "0x43dc13ff35b868a83b3f2139d8f301ebb7eedfff",
        "0x732f25f5e3209bee23ce9190c77f3605cc1625f9",
        "0xd8e2e5807725402643f78464b3ea6e7731c26ea3",
        "0xa7c4cc5d52e3ef0fc70d7de915ab4dd614e0ef73",
        "0x13e39c2cb92366944acbe983f229a499c424d499",
        "0xb8de3776a0883df74f5eeebeecebaaf70745ff1f",
        "0x5630cdc69c256db5283328ce0842cd9d2c565f03",
        "0xb1eb41c1799d08c65f20f5dc3e80221da76b252f",
        "0xc00fa5b815f89ad342aff07cec0a886aed207a71",
        "0x3a687a5210a08986d45ff414536734e0714412a6",
        "0x332000d11273f0328662a5035e83a9a771619874",
        "0x1e1fe97ae6b386ff0a1daa7fa685912de2cc4afa",
        "0x1cff7b55dfea912f4cd7caead49406e705e2d45d",
        "0xec9795fd392b3c356515d02185d7bdaa06e662df",
        "0xec4f6347bd2ae23ce5cb23fae4207ebe5aa1d323",
        "0xb68c21c7498a043505c1df1e19e8b14c1b40116e",
        "0x041ffd871360898ade95f28e3ba295f34c5ee721",
        "0xa71022a145cdfa75637a092323322deb522dd226",
        "0xde5a8e0393c92982dc401026bf384d63e1a8f0d1",
        "0x86a163d438513cb304234700fdd6e8d993698f32",
        "0x89aa5301558e82a4e341c81a574b84999229befc",
        "0x879251752e9271a521083c88d18d7c46d2a09dd3",
        "0x3e96580f39ccaba0dedb99a501288446fa83a804",
        "0x32cf53c57bda0ce7e5eb1f24cb190b65edcb76d1",
        "0x6af127e11c2e09efbe48d590bcc008da37b3395f",
        "0x5e0b2cccb785a324774b7a8d8e3abb17e0cab6ff",
        "0x03ea8a20a856e6352c7fb8c50143b524db45492f",
        "0x860406b37b52c08d74c85040a35371204df21df1",
        "0x900c5bead0f0aa56d56ae23f38be8f4b97a6082b",
        "0x0480e55ad6f53577b89ebfd92d7d312772dc309a",
        "0x385137db323a78970e9bc92aff49ff482030634a",
        "0xe5fd0a68e96711773201909f5323ab7a0b410754",
        "0x5fc00eee088f90294ff59115b2e249a7ab5956d1",
        "0xa3faa3b417b097462399b17825ade05b2f1dbeaf",
        "0x14bdf64f101e6a751a2592807c19cf2b7e40424d",
        "0x811586a44a723621873e0797c9a8d459ec9b616b",
        "0xc4def4dcb2e1a21651073651587da38c36886db7",
        "0x95404b9f4702ff11ee9a32f06543646c441ec931",
        "0x1e29706732dcc26db4e003a22847856c64b31bb6",
        "0x96cd9cf76a85a00cb55e8699ce66b2aa0eabe104",
        "0xc79da6b9339634ce56997396fe73c51b1b6f9b28",
        "0x7aae368706f77fd4dd600c0ab8cf647b87b2f0de",
        "0x5fb2fce0544a9a53aa52fd9d98ac9a86a27a7e5b",
        "0x862d8660d63142be6ac43b7473f644b7a65bd4d6",
        "0x4bbf5523a67803631dfb4825839e8248ec2d8075",
        "0xe29428b6ff78c819e76fb1acf0bbb2b3e2ada6ed",
        "0xae0dfC122876CDDc892375f8dCac52bD01904c39",
        "0x1b7c0d359ae709b09a43b21b077e9c41f94e6313",
        "0x7c2862504e96fb8286ec42f1cdf7b22c80a7f937",
        "0x09f8A26246738146763a23b6C742099e705759B0",
        "0x3413e32f263548c95ffa5160051d99c1145b480c",
        "0xe4a14f559317a7470ffec2f429fad515e8b5331f",
        "0xc73ddf2404818346c8064e65ff113b4cdc36ae86",
        "0x33b275e8aa5a4ab3c5fa323da6b685d672d0c043",
        "0x06d2126dd0c692728c5f84c1dad3837fb237918d",
        "0x65b4f70084d86590c52d93cc9080e4f4d92ea61a",
        "0x6bde951d9b6b211f69456710c1c3138d044366cd",
        "0x104317c01e8187bc0bf43828bf9042e76bd8e221",
        "0xdcbf8475fe8f4bdb7d021e46e4bcebdc60e8cffe",
        "0x58f2f25dd4070ac6bc2eac66125bc1bfc55e78a1",
        "0x68aa41b4f63f4906cb64eaf5e22bad5f1fdccd57",
        "0x0046755325e86301952b888ed571c252a37112d4",
        "0xd1c14a2ad6c9bfba5c72eeb57c6373b59f7031dd",
        "0xb3013dce77bfba9d0548d2ddd6cc7143124ebb94",
        "0x8d55c101c0690573cd2d004efa7c42cce7055791",
        "0x001cb0d5231880ac1228609b12948ac5a64189dc",
        "0xe09ac4f081a026ff7fff0353ca9cccf4a36b994a",
        "0x26ad385f282cde4b8003a95e98029c8135e23fbd",
        "0x146400e3d53f0559dea8ce4514596600c04f8266",
        "0x81f8a4bd896e20bba4e160dc4990ba146d8996d4",
        "0x3b6a99570259240849859799791eecdc41dbfb75",
        "0x363913984f74045720c8e003ef4ca67d39db789b",
        "0x002504a6fbe12c15906e0e24378babe691424c0c",
        "0xd9df4eae9bc0b81ed09b583ea65a5302857084ae",
        "0xcb86b457f3eeff0e0af5f9e5fcaffa313e7809cd",
        "0xb28508b6d8028ba94dd5e3146e1f4ed15829b4b1",
        "0xaac5f9d8aa2f02aa1d4f97dd16576e188abf8122",
        "0xe20b3553a6489f7d1dec35381d1ab99afae9dc6d",
        "0x06f7082b1d5d7150f98436dc61b9695803d0a83b",
        "0xa86224510d05e8a4ef6bf3e60bb0cb5014bc1727",
        "0xff1ce893316637812d9ccc01cbbb5534227d7d02",
        "0x11a6ed596552a6244adea170bb883c282dd8d31d",
        "0x9b1976b4a54e50b1980dfe74e0e8b808731b5db9",
        "0x5a86cfae0ccc3675251905398ad65f2c2a1b3e37",
        "0x8f3050aa74d372a22f13a119e6534169ddfb3156",
        "0x3699d134afc4746c85c1b18d15e46a9ca675fcd0",
        "0x4fC026d831Ab4Ae0ae7fF35a6db509F7Df727742",
        "0xf016b8b17e26a36e2ab22353589988e175a52d7d",
        "0x5612b38e09d149ebf3f2a6e46a0c551fb67d8885",
        "0x0ebd30c79324b28f71c93f1c217522fd54fa45bd",
        "0xda2acfdde7070dace2d2e4e50b26f49adc66348f",
        "0x1b5500c4b8810b19660143494782f340b6326987",
        "0x01c999b79aa11f66fea462b2bb127c8b5a7aa0e7",
        "0x0ef05fd542dcf1beecdd99942773f46c4150c95e",
        "0x4e2934b53553d957e7af7fca5d3f62499321b8ad",
        "0x8c4531b3f4cdfee616a44eaef29b5b5ee60cdf6d",
        "0xb357ed25d4876a5d9c5e6c3d4838ac1772df69e1",
        "0x67e43d44fb163a44506e743fae63e5d1a512c484",
        "0x845eb78203ee3f7e022c215ff04fa1e4b562c8cc",
        "0x937df553bf609f03224e7a562176da115cf734e3",
        "0xd18fc7bacb0ddd3fbf6c5389ddd2de9d50e07c18",
        "0x31c028f9617a7528151aa249befb1bcceb24c104",
        "0x8e71549fcc4d24977d20f836d39669d1bc23c6ab",
        "0x38c1d2cb27cad2fa865e72b65ec18bc19e44360b",
        "0x0e487b8790988f03f8cd63d456f9fd75a73a3a37",
        "0xf5c3d0ea5f7de9b87b56129bccc20c4101f24725",
        "0x403e693f4d2c9833decbe2104d4141ea0582571d",
        "0xecdd822475a4361c6aece0b13b3849986aab96aa",
        "0x409e86c4c36a48d0afc2675ebd648c5e53f9e436",
        "0xd98cfe0bb7c78c7c14f26f436183b2e958d6ee8c",
        "0x3814cf11b19134ceec6c915b20e6405b89113539",
        "0x1cbcfaf09f23c1989993a3b5df1774017b5cc065",
        "0xd65c727fa1c36ad14e7392c67058d0e8815f72eb",
        "0x706a39f86f174d26c0b5285721fbc48beaa192a0",
        "0x0d0587c889e8ed1162d670b537f6fd04be42695e",
        "0x8bc2453ebf379fcb1f398defb4d96117fb810f0f",
        "0xed012d5624bf440a091290ca6c10de540c94918c",
        "0x1709d96F7af0cA1Cea2d9133d45dc96D829A013e",
        "0xDf6e70Fe4954CE45BC0399A131bfe4e9b58168c1",
        "0x9a5440227f488997cd266183f82713ab8edd806d",
        "0xa6fbfd9604dd6559cbe758ea1078842eff651226",
        "0xaf22a1a05ac191963668f5fae0b22ae1d0de42d7",
        "0xf5223f5bd08588b9de6442c5fdb91e1a59b56d67",
        "0xc9ceee68d7ae7af21e4ab6e29544b4d394d1ccdb",
        "0x0afd7d6fd51662fe0a9ded7284126cc652cf87d0",
        "0xa88e70f97c39de1d2936ed36c07fe0f893984e73",
        "0xee2c06a757fb23295ab50bb9db316d4e3df05691",
        "0x68b754afff5f1e467b7459c6cd6ec90e8722cb4e",
        "0x186d58abb91c9f183e306038c8e1d03edcd368e4",
        "0x601e617f5ea7bd2120ad754a8897916ae4c69ffa",
        "0x6ac7603159964dd9a75fd97a6f8b7419badbfe55",
        "0x67f43a276e32bb942f83fc8a23cd3e316c0f8f2d",
        "0x2543ea6c6301c4422edc0b85602132deb6460ff9",
        "0x3291a331a6e6b5ae3dc500b45b2f1abc11608fd5",
        "0xaed6ad7f0760d059a81facb08466310774f0d997",
        "0xe988ba7f39129b8d1a8946f413db3abf8ddf9eed",
        "0x70f6d52876635c907fa50ab026e535346e2f0d10",
        "0xe79741c2729fcf2dc64e3cc1b120d7157a2479ae",
        "0xff77ae6545f3a58ba719a058f0fb1dbb2181d2e7",
        "0x76d2b09b64c677c7c79f11c3d1364fb2f13ddf5a",
        "0x8c5645a50f39b5d1a6112000748b3581e8be7ad2",
        "0xb86e363e448dac7032e10194d7719bf09a694819",
        "0xef56c4ec745d20b132f2787c298d6f1f4bca933d",
        "0x4168a1e7a8fd9e04896d9eb23fb9c34b67160858",
        "0xfb731883bc765d9fa7ecf0117cd73204707d1f52",
        "0x1396e8b5e15171c30d221948a1be646b6d0b1ac3",
        "0xa1ef2112fc09f5e9d703885967e289a87166cd30",
        "0xf312453b21f6d5854a87a44c2dd6a3be0ba9dd46",
        "0x6c2e5c271e277eeab3ce4cdb7e28ea8f2c3b64a0",
        "0xa26dcbe5d9ff410d8e983bf4d0c552a3bbc3de32",
        "0x6a71fc4e1bb7c509a84f8e181f25758693f97373",
        "0xbb8ab5132b47005ea591120657e658bec1a8db36",
        "0x58bf0a9ebd472754fa1bf18d6917239e9615879b",
        "0x01ac57a18d5859571ed7f54c0379724a58562618",
        "0xaf9d983ef16c98c7bda1c8a9ba49eb53f4933137",
        "0x36bc047db1bd048159203a87bafc964b24fe2f92",
        "0xfda66f39541c0c7c21dfb4dc6bda616cb0029099",
        "0xe3005a31c0e1898bc04cedc669d6841d0274db40",
        "0xdc77720e514ed88cc56e1e93501b1e4ddf1a1686",
        "0x5c02318df780b67c732856d97f890e177e43eff0",
        "0xfe587a5ef13329c4a462ad3a803952e6496923d5",
        "0x532499d17D1da2082F6d5D20d6f68A51a4D12ee8",
        "0x1485901ef57ffacf12bb9871112826545f5102b9",
        "0xED20613De358ff68533d208B046961F0e0ba7de2",
        "0x3029ebc28548220b9abc90289d84c92d1264e393",
        "0xed49e2bf883471f25e96323931dc5ce79e65cee8",
        "0xbb0a13bfec661544792e25d141076c279abc480e",
        "0xb7d9d48aa37d8ba7a8eb6dd134180f4f29764afa",
        "0x53a6bd3eb933f7b62df5c4c5b1e1f94f208cd3bd",
        "0x46104bfd1374878841ee3e4beb87210343e6bf05",
        "0x4136f2bd8130988e831305c76e3dd467611b76db",
        "0x227eef3cf317ab44771f0c38c7aab54ac1774b73",
        "0x7f1d78cb7d96c37a29dfe45489a5cd810eec83e3",
        "0x23389892d0ee1fcd2fd1881583bdac0e7189d7c7",
        "0x462b8e47cfc5c82b70db9961c2dd6ffad465ab48",
        "0xc02f563d2ebe0863ba1f5f9feddbc1a0863ed17a",
        "0x21e6d92ef7f6365adc5512fbe695dc1cde7d40fd",
        "0xb2b1ddb352c695bf9417c8acc0950e10b8372125",
        "0xdf6d05a6bc74fb775424bf2b51df75b631ef1d50",
        "0x251ce14e8cdc3143dbd76fd6127781a5f14898c4",
        "0x9036ed0d06d66a2d856fa8f5c1566e4c13d45e4a",
        "0x1c8bdfb68226bea215fcea35467d85beabf7edc5",
        "0xe869697d4a931b3367256410974c7570111dc11b",
        "0x422480a61c3a2eb68fae881e7cb0e483545dfe81",
        "0x1fa4823613fb2424cbdab225fc1eefe3bd293c84",
        "0x56a5ad89bda2ad6790a83fb301002b2464486317",
        "0x2f0d5e5bdd71c9f4225529284c5836e1ff7d9c42",
        "0x979582d33211d3afe5902351f9f13249c3618bfa",
        "0xdaec3ad42514cfd377d89ad37730a00e154119bf",
        "0x6669ae67bb7a8ebfa3bd47d424e39159615742cd",
        "0xc7a48f77dbeb8a76931a3128d1a0a1fa1a0c7531",
        "0x570c507cc69d32ca6452f7a10f6fd91eb9c90b99",
        "0x4905a1affba1652920e179a5281cd99f34f920e7",
        "0x55a461e403c5aa9300f2794b88b3c84f882e5c7d",
        "0xd8c909205b4f9ff2504438cf43ca976f97dc56da",
        "0x3c3e15e125e582ad80eb760259cc0894bd222a63",
        "0xa1ce2ef62f94ec350c481f06677e7ac66d41ef0a",
        "0xb6e86531f807f15ddff90093018d819a9d7e457c",
        "0x20e11d8e243078b5f66652ba42d8cba075af3f7e",
        "0x15a29e3f15fa4dc7bc1c7e2c29a7f0823586593b",
        "0x3dd6e43df4062af9edcf9292a908ec12d2a7bf0a",
        "0x9003335ba23ec6c87c7cb774e353cb4e7196cb88",
        "0xcdc58d36b53fc91a050595a58d18fdb00ad16395",
        "0xae73ac2558c4d683ebc48ce59c33958da125aa6e",
        "0x7730863e133f419cac3d27cf4ff5b6f10e56997d",
        "0x6d6585cd0f30d438ec5f6f2a4f3fa31e582e8a2a",
        "0x40e83ae56da8e59931e641350c84460c200e5f23",
        "0x920ac6ad868e0ce88605681663e3ac18239ec398",
        "0xa72b34091f1ec44e698d057c341a4c6243518598",
        "0xa7e36015bd9f5fbf1b46debd253d546d0454c1b3",
        "0x151f441c27734e78544697e4e1d4e5a77837e6a2",
        "0x66c280ba61bcbbb28096f44747a5e63dfc3af709",
        "0xd2d711d3bebbe53f44a3ebe6f5de8cea2f5b1be9",
        "0xc625ab000fe195f31c306cce37adfb57fbd295d8",
        "0x6242e840bab327b0dfed8b98d1cf41d642f36f62",
        "0xfb6eb7c3f7777cb8e1ce9a6ff9158bce0d40db09",
        "0xc555dc3e0542f79fc2e71408d06c4e79b499c235",
        "0xa345677e8d5ae65aac3d34bb24a5e26cf0caffd5",
        "0x217df1967620e9ca64fbfe4dffa1be3003572d1c",
        "0xdf9fec94541727aceaf8310069f8adbbc84f2647",
        "0xf21edb0e8a76f252bb607625f57c99181b8a35f7",
        "0xd27a30ebfce5f1bcfa56bb55c6b38712e8b2e834",
        "0x303b289bc0253d8d5c817c83b366252ed71ba589",
        "0x1336f4d6cd8a4e460f27c9adcc76cde47dc87700",
        "0x5e08b19ee9f27a9b0b8c929db5e5bb765b62364e",
        "0x36c42049243ec9a923b545cf5c50d38f7a0efa49",
        "0xcd93d88a73815b3817bfffcaee6cdaa38db398d5",
        "0xf237e4069e5d189337ec514a891d41eaf4b9d730",
        "0xac208f98ee0244897ceec425b22f639d437b8a00",
        "0xdeb737cb0127cf96b7f8c80ed91db1c231175bde",
        "0xf59ab8212721fba2687ab7c26fe0471e35dfc1fb",
        "0xd91b6d1f16c505f434e3aa20303342df49065e25",
        "0x7e7cf34353b61a4f73332169d229f65913ed6c69",
        "0x577556b97c57e1d35f577f38c78fa776847149bd",
        "0x9203a1076f4dc7e010b6f19bd7e1d31be0c3a7fd",
        "0x18d49bc4c9e99aa18653d7c7f5dfbc36dcb1cf24",
        "0x29766e997e91f8f047b36fecb67c0379da434c73",
        "0xc3c93fcbe3085d7580325915fe7c1da89eb843c1",
        "0x3bb0edf618370a3bb57ce91e97a7c76d0e02926f",
        "0x8e724a913b99e17335722d072e626587f4df9d10",
        "0x42a4733d38c170b010711fe62eda005b84e1b6b8",
        "0x00c7870cee92bb15848145c3d655009fd33cf8fe",
        "0x3748666a3c5b568094e01cd19c1fa1fcbf00099c",
        "0x414839a45fae933d9518732c872d463da26b05ca",
        "0xe7b48b3102da0c0a09a279e7b67ced40566f6597",
        "0xae7f5b30805aee5f2b590941e556f2e4b1162326",
        "0xe95be7279952c72ecdc93be5a8e41af6d77b7269",
        "0x9720b02689cd64c6a65f5ded00b8104a7dbbfb99",
        "0x8e5ac89408da3091bf57fff641be99f6e15bd410",
        "0xb2f3bdad11041df06d7047878a4bc22b7e049267",
        "0x9906628bfe0704e1cb36272cb93978482c20cf19",
        "0xb8ab4d8a62cf22aec6319a7d6bb8088fe8203c75",
        "0xb544159dcb2613f06471169e943a6c10bdbbc312",
        "0x05c87f9f3f5f8df76473310a35c36d6161b71b07",
        "0xcf39010dcc0af0ac36bc6ecc7957a61a3da202ab",
        "0x546326f7f90d1f9fcd558414bbd07aef9af2a114",
        "0xc70e414b5d55182e9adf6a0211466a1d53180627",
        "0x4418295156a4f94c55b12e7f02c16a2a6522959a",
        "0xc801742d069daeb18f4fa8ed4b4728e2b6503def",
        "0x0b24b235e4766cc9d0c3821397092689d6cf5bc5",
        "0x329feb9c05cd417282444e73a9150edd512be716",
        "0xf8ffd404e1131abdb1c618ed146e27f34c88c047",
        "0x193f8bb793765409ff3babfdd0bd3e4daf20e1e7",
        "0xb59caf62a4b64a30c81087df98f6a84af18ea5e0",
        "0x100dcc93fc43578f605fdd9176f45c2c569ca434",
        "0xeefd49d0e2c5133ef8c2b3400fe10d89d5ebc941",
        "0x5b629c98ab0bea24a14e30b069cfbba8344d59a7",
        "0x04050bc6197141f2927589162821578662d6bed5",
        "0xd1bd53c13d9d8709c6f342b3f331e8e970f2ccd7",
        "0x7b154aa5030ac7729fb7f16b03436d36577f6c3b",
        "0xa0cc05a40262fd0fdb1c8f5598ca8b403df6fee8",
        "0xafff0ffeb1d2be30b769480a485e1e0a0837b204",
        "0x7099b0ee40d3eb1e222eb9eeb46c22f783502cde",
        "0x48e2f85de559ef74d53efd25755158760b5f728e",
        "0xd7c25a2f5e51aa3ce9ab23fd4565f87e07c9115f",
        "0x3a61a073c2e8e37ea59877305f6ffbcbe64b82b0",
        "0x2c438a034d3a7815a8ca5da51c24299091d030ca",
        "0xc084202253b69e80b11990625c8fd4c9720641f7",
      ],
    };
  },
};
</script>
<style lang="scss" scoped>
.tokenSwap {
  .tokenSwap-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 180px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &:first-of-type {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .tokenSwap-content {
    .container {
      padding: 50px 0px;
      img {
        margin-bottom: 20px;
      }
      p {
        font-size: 14px;
        line-height: 30px;
      }
      .content-title {
        font-size: 30px;
        margin-bottom: 30px;
      }
      .content-subTitle {
        font-size: 24px;
        margin-bottom: 30px;
      }
      a{
          color: #00ffda;
          text-decoration: none;
      }
    }
  }
}
</style>