<template>
  <div class="exchange">
    <div class="exchange-head">
      <common-header/>
      <div>Exchanges</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span class="currentRoute">Exchanges</span>
        </div>
      </div>
    </div>
    <div class="exchange-content">
      <div class="container">
        <div>
          <div class="content-title font-weight-bold">{{$t('exchange.paraOneText')}}</div>
          <div class="d-flex flex-wrap">
            <div v-for="(item, index) in paraOneList" :key="index">
              <a :href="item" target="_blank">
                <img v-lazy="item.url" :key="item.url" />
              </a>
            </div>
          </div>
        </div>
        <div>
          <div class="content-title font-weight-bold">{{$t('exchange.paraTwoText')}}</div>
          <div class="d-flex flex-wrap">
            <div v-for="(item, index) in paraTwoList" :key="index">
              <a :href="item" target="_blank">
                <img v-lazy="item.url" :key="item.url" />
              </a>
            </div>
          </div>
        </div>
        <div>
          <div class="content-title font-weight-bold">{{$t('exchange.paraThreeText')}}</div>
          <div class="d-flex flex-wrap">
            <div v-for="(item, index) in paraThreeList" :key="index">
              <a :href="item" target="_blank">
                <img v-lazy="item.url" :key="item.url" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
import CommonHeader from '@/components/common/CommonHeader.vue';
export default {
  name: "Exchange",
  data() {
    return {
      currentLanguage: "CN",
      paraOneList: [
        {link: '',url: 'http://www.waltonchain.org/Uploads/2019-03-22/5c949c38a9aff.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-03-22/5c949cbf94554.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-03-22/5c949cc94c0e3.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-03-22/5c949cd1e8ed3.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-03-22/5c949ce0bd0e2.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-03-22/5c949ce8d2502.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-03-22/5c949cf3cf9b4.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-03-22/5c949cff478ac.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-03-22/5c949d0bc0589.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2020-09-03/5f50537164df5.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-03-22/5c949d20c9447.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-03-22/5c949d2ce7ae0.jpg'},
        {link: '',url: 'http://www.waltonchain.org/en/Uploads/2019-04-24/5cbffb2d11aed.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-03-22/5c949d5a0d834.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-03-22/5c949d6e13c45.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-03-22/5c949d778e56a.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-03-22/5c949d8174a91.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-03-22/5c949da242aee.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-03-22/5c949ddc3484a.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-03-22/5c949dfa25cbd.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-03-22/5c949e02d3ead.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-03-22/5c949e19ca961.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-04-03/5ca48d8d60149.png'},
        {link: '',url: 'http://www.waltonchain.org/Uploads/2020-09-03/5f5055e4939bb.jpg'},
        {link: '',url: 'http://www.waltonchain.org/Uploads/2020-09-03/5f5056cf3a831.jpg'},
        {link: '',url: 'http://www.waltonchain.org/Uploads/2020-09-03/5f505720cca2c.jpg'},
        {link: '',url: 'http://www.waltonchain.org/Uploads/2020-09-03/5f505779d0a6f.jpg'},
        {link: '',url: 'http://www.waltonchain.org/Uploads/2020-09-03/5f5057cd51b3c.jpg'},
        {link: '',url: 'http://www.waltonchain.org/Uploads/2020-09-03/5f5058073406d.jpg'},
        {link: '',url: 'http://www.waltonchain.org/Uploads/2020-09-03/5f5058454d1a9.jpg'},
        {link: '',url: 'http://www.waltonchain.org/Uploads/2020-09-03/5f505989cb1f5.jpg'},
        {link: '',url: 'http://www.waltonchain.org/Uploads/2020-09-03/5f5059bb4581d.jpg'},
        {link: '',url: 'http://www.waltonchain.org/Uploads/2020-09-03/5f505a0792e36.jpg'},
        {link: '',url: 'http://www.waltonchain.org/Uploads/2020-09-03/5f505a38eafc5.jpg'},
        {link: '',url: 'https://www.waltonchain.org/Uploads/2019-04-03/5ca48daba6dfb.png'},
      ],
      paraTwoList: [
        {link: '',url:'http://www.waltonchain.org/Uploads/2019-03-22/5c949cc94c0e3.jpg'},
        {link: '',url:'http://www.waltonchain.org/Uploads/2020-09-03/5f5058073406d.jpg'},
        {link: '',url:'http://www.waltonchain.org/Uploads/2020-09-03/5f505f0ed461e.jpg'},
        {link: '',url:'http://www.waltonchain.org/Uploads/2019-03-22/5c949cd1e8ed3.jpg'},
        {link: '',url:'http://www.waltonchain.org/Uploads/2019-03-22/5c949c38a9aff.jpg'},
        {link: '',url:'http://www.waltonchain.org/Uploads/2020-09-03/5f5058454d1a9.jpg'},
        {link: '',url:'http://www.waltonchain.org/Uploads/2019-03-22/5c949cf3cf9b4.jpg'},
        {link: '',url:'http://www.waltonchain.org/Uploads/2019-03-22/5c94597fb90a6.jpg'},
        {link: '',url:'http://www.waltonchain.org/Uploads/2019-03-22/5c949cbf94554.jpg'},
        {link: '',url:'http://www.waltonchain.org/Uploads/2019-03-22/5c949cff478ac.jpg'},
        {link: '',url:'http://www.waltonchain.org/Uploads/2020-09-03/5f505989cb1f5.jpg'},
        {link: '',url:'http://www.waltonchain.org/Uploads/2020-09-03/5f5059bb4581d.jpg'},
        {link: '',url:'http://www.waltonchain.org/Uploads/2020-09-03/5f505a0792e36.jpg'},
        {link: '',url:'http://www.waltonchain.org/Uploads/2020-09-03/5f505a38eafc5.jpg'},
        {link: '',url:'http://www.waltonchain.org/Uploads/2019-03-22/5c949dfa25cbd.jpg'},
        {link: '',url:'http://www.waltonchain.org/Uploads/2020-09-03/5f50629c787dd.jpg'}
      ],
      paraThreeList: [
        {link: '',url: 'http://www.waltonchain.org/Uploads/2020-09-03/5f505f0ed461e.jpg'},
        {link: '',url: 'http://www.waltonchain.org/Uploads/2019-03-22/5c949c38a9aff.jpg'},
        {link: '',url: 'http://www.waltonchain.org/Uploads/2019-03-22/5c949cbf94554.jpg'},
        {link: '',url: 'http://www.waltonchain.org/Uploads/2019-03-22/5c949cf3cf9b4.jpg'}
      ]
    };
  },
  components:{
    CommonHeader
  },
  mounted() {
    this.currentLanguage = localStorage.getItem("lang")
      ? localStorage.getItem("lang")
      : this.currentLanguage;
  },
};
</script>
<style lang="scss" scoped>
.exchange {
  .exchange-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    height: 410px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &.commonHeader{
        min-width: 1640px;
      }
      &:nth-of-type(2) {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .exchange-content {
    .container {
      padding: 50px 0px;
      .content-title {
        font-size: 16px;
      }
      & > div > div {
        margin-bottom: 20px;
      }
    }
  }
}
</style>