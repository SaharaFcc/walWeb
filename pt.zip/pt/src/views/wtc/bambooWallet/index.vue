<template>
  <div class="bambooWallet">
    <div class="bambooWallet-head">
      <common-header/>
      <div>Bamboo Wallet</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span class="currentRoute">Bamboo Wallet</span>
        </div>
      </div>
    </div>
    <div class="bambooWallet-content">
      <div class="container">
        <template v-if="currentLanguage === 'EN'">
          <div
            v-for="(item, index) in imagesEn"
            :key="index"
            class="text-center"
          >
            <template v-if="index === 9">
              <a
                href="https://github.com/WaltonChain/BambooWallet"
                target="_balnk"
              >
                <img v-lazy="item" :key="item" />
              </a>
            </template>
            <template v-else>
              <img v-lazy="item" :key="item" />
            </template>
          </div>
        </template>
        <template v-if="currentLanguage === 'KR'">
          <div
            v-for="(item, index) in imagesKr"
            :key="index"
            class="text-center"
          >
            <template v-if="index === 9">
              <a
                href="https://github.com/WaltonChain/BambooWallet"
                target="_balnk"
              >
                <img v-lazy="item" :key="item" />
              </a>
            </template>
            <template v-else>
              <img v-lazy="item" :key="item" />
            </template>
          </div>
        </template>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
import CommonHeader from '@/components/common/CommonHeader.vue';
export default {
  name: "BambooWallet",
  data() {
    return {
      currentLanguage: "CN",
      imagesEn: [
        "https://www.waltonchain.org/Uploads/2019-03-30/5c9f1e8da0cab.png",
        "http://www.waltonchain.org/en/Uploads/2019-01-16/5c3f11b7cd208.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-01-16/5c3f11b856063.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-01-16/5c3f11b8de1d1.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-01-16/5c3f11b93b622.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-01-16/5c3f11bb661fc.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-01-24/5c4968f749cd3.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-01-16/5c3f11bcbf200.jpg",
        "https://www.waltonchain.org/en/Uploads/2019-03-26/5c99dbc017de5.jpg",
        "https://www.waltonchain.org/en/Uploads/2019-03-26/5c99dbc0d5a36.jpg",
      ],
      imagesKr: [
        "https://www.waltonchain.org/Uploads/2019-03-30/5c9f1e8da0cab.png",
        "http://www.waltonchain.org/kr/Uploads/2019-01-17/5c3feece5873c.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-01-17/5c3feecec0396.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-01-17/5c3feecf4cfc7.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-01-17/5c3feecfaa099.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-01-17/5c3feed03899d.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-01-17/5c3feed0b68a2.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-01-17/5c3feed17cab1.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-26/5c99dc389b71c.jpg",
        "https://www.waltonchain.org/kr/Uploads/2019-03-26/5c99dc2898b29.jpg",
      ],
    };
  },
  components:{
    CommonHeader
  },
  mounted() {
    this.currentLanguage = localStorage.getItem("lang")
      ? localStorage.getItem("lang")
      : this.currentLanguage;
  },
};
</script>
<style lang="scss" scoped>
.bambooWallet {
  .bambooWallet-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    height: 410px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &.commonHeader{
        min-width: 1640px;
      }
      &:nth-of-type(2) {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .bambooWallet-content {
    .container {
      padding: 50px 0px;
      & > div {
        &:last-of-type {
          margin-top: 20px;
        }
      }
    }
  }
}
</style>