<template>
  <div class="communite">
    <div class="communite-head">
      <common-header />
      <div>Communities</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span class="currentRoute">Communities</span>
        </div>
      </div>
    </div>
    <div class="communite-content">
      <div class="container">
        <template v-if="currentLanguage === 'EN'">
          <div v-for="(item, index) in imagesEn" :key="index">
            <img v-lazy="item" :key="item" />
          </div>
        </template>
        <template v-if="currentLanguage === 'KR'">
          <div v-for="(item, index) in imagesKr" :key="index">
            <img v-lazy="item" :key="item" />
          </div>
        </template>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
import CommonHeader from "@/components/common/CommonHeader.vue";
export default {
  name: "Communite",
  data() {
    return {
      currentLanguage: "CN",
      imagesEn: [
        "http://www.waltonchain.org/en/Uploads/2019-03-06/5c7f64b4e068f.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-25/5cc15feef016f.png",
        "http://www.waltonchain.org/en/Uploads/2019-04-25/5cc1603452ee3.png",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5cfc8321f3.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5cfd5e3cf8.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5cfe230f85.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5cfebbd2f0.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5cff870217.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d0052300c.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d01027200.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d01c3cb19.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d02813ecd.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d0316d893.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d03c4d86d.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d04597309.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d06471d46.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d087129cf.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d09106edd.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d09e6693a.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d0a941444.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d0b293e0d.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d0c42a29c.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d0d01828b.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d0da8ae5c.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-05-17/5cde800c7b14c.png",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d0ef4e029.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d0f9633bb.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d10f9350f.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d119783e8.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d122e1c7c.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d14d9cc9c.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-10/5cadb034ac81e.png",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d14fec23d.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d1511ecd2.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-04-04/5ca5d15215290.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-07-08/5d22e5a8c619f.jpg",
        "http://www.waltonchain.org/en/Uploads/2019-03-06/5c7f652733738.jpg",
      ],
      imagesKr: [
        "http://www.waltonchain.org/kr/Uploads/2019-03-06/5c7f433dc568f.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-06/5c7f433e3fc64.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-06/5c7f628385688.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-25/5c9895ef8a306.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-06/5c7f433ff1a2d.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-15/5c8b6caf7d541.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-06/5c7f434107b66.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-07/5c80b2b2128b9.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-06/5c7f4341e11fb.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-15/5c8b6d102c2d8.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-15/5c8b6d114780c.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-15/5c8b6d1252652.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-15/5c8b6d136dea8.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-15/5c8b6d143ea04.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-15/5c8b6d166f4e6.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-15/5c8b6d174ffd3.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-15/5c8b6d17e5b9d.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-15/5c8b6d92cf333.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-15/5c8b6d93da635.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-15/5c8b6d94e7a61.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-05-17/5cde80678cb95.png",
        "http://www.waltonchain.org/kr/Uploads/2019-03-25/5c989623a23d2.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-25/5c989624c4160.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-25/5c989625bebc4.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-25/5c989626c9adc.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-25/5c989627bfd92.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-07-08/5d22e62307235.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-06/5c7f434697ce5.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-15/5c8b6ddf7ecb0.jpg",
        "http://www.waltonchain.org/kr/Uploads/2019-03-15/5c8b6dc03698f.jpg",
      ],
    };
  },
  components: {
    CommonHeader,
  },
  mounted() {
    this.currentLanguage = localStorage.getItem("lang")
      ? localStorage.getItem("lang")
      : this.currentLanguage;
  },
};
</script>
<style lang="scss" scoped>
.communite {
  .communite-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    height: 410px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &.commonHeader {
        min-width: 1640px;
      }
      &:nth-of-type(2) {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .communite-content {
    .container {
      padding: 50px 0px;
      & > div {
        &:not(:last-of-type) {
          margin-bottom: 50px;
        }
      }
    }
  }
}
</style>