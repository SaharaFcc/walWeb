<template>
  <div class="commonFooter">

  </div>
</template>

<script>
export default {
    name: 'CommonFooter'
}
</script>
<style lang="scss" scoped>
.commonFooter{
    
}
</style>