<template>
  <div class="commonHeader">
    <div class="navs">
      <div class="container d-flex justify-content-between">
        <div>
          <a href="">
            <img
              v-lazy="
                'http://www.waltonchain.org/en/Uploads/2018-12-10/5c0e0ffa1f302.png'
              "
              :key="'http://www.waltonchain.org/en/Uploads/2018-12-10/5c0e0ffa1f302.png'"
            />
          </a>
        </div>
        <div class="d-flex">
          <div
            class="cursor-btn position-relative"
            @mouseover="showWTA = true"
            @mouseleave="showWTA = false"
          >
            {{ $t("home.headerOne") }}
            <div class="circle" :style="showWTA?'opacity:1':'opacity:0'"></div>
            <ul class="position-absolute" v-if="showWTA">
              <template v-if="currentLanguage === 'EN'">
                <li
                  class="text-center"
                  v-for="(item, index) in wtaEn"
                  :key="index"
                >
                  <router-link :to="{ path: item.link }" tag="a">{{
                    item.text
                  }}</router-link>
                </li>
              </template>
              <template v-if="currentLanguage === 'CN'">
                <li
                  class="text-center"
                  v-for="(item, index) in wtaCn"
                  :key="index"
                >
                  <a>{{ item.text }}</a>
                </li>
              </template>
              <template v-if="currentLanguage === 'KR'">
                <li
                  class="text-center"
                  v-for="(item, index) in wtaKr"
                  :key="index"
                >
                  <router-link :to="{ path: item.link }" tag="a">{{
                    item.text
                  }}</router-link>
                </li>
              </template>
            </ul>
          </div>
          <div
            class="cursor-btn position-relative"
            @mouseover="showSolution = true"
            @mouseleave="showSolution = false"
          >
            {{ $t("home.headerTwo") }}
            <div class="circle" :style="showSolution?'opacity:1':'opacity:0'"></div>
            <ul class="position-absolute" v-if="showSolution">
              <template v-if="currentLanguage === 'EN'">
                <li
                  class="text-center"
                  v-for="(item, index) in solutionsEn"
                  :key="index"
                >
                  <a>{{ item.text }}</a>
                </li>
              </template>
              <template v-if="currentLanguage === 'CN'">
                <li
                  class="text-center"
                  v-for="(item, index) in solutionsCn"
                  :key="index"
                >
                  <a>{{ item.text }}</a>
                </li>
              </template>
              <template v-if="currentLanguage === 'KR'">
                <li
                  class="text-center"
                  v-for="(item, index) in solutionsKr"
                  :key="index"
                >
                  <router-link :to="{ path: item.link }" tag="a">{{
                    item.text
                  }}</router-link>
                </li>
              </template>
            </ul>
          </div>
          <div
            class="cursor-btn position-relative"
            @mouseover="showEco = true"
            @mouseleave="showEco = false"
          >
            {{ $t("home.headerThree") }}
            <div class="circle" :style="showEco?'opacity:1':'opacity:0'"></div>
            <ul class="position-absolute" v-if="showEco">
              <template v-if="currentLanguage === 'EN'">
                <li
                  class="text-center"
                  v-for="(item, index) in ecoEn"
                  :key="index"
                >
                  <a>{{ item.text }}</a>
                </li>
              </template>
              <template v-if="currentLanguage === 'CN'">
                <li
                  class="text-center"
                  v-for="(item, index) in ecoCn"
                  :key="index"
                >
                  <a>{{ item.text }}</a>
                </li>
              </template>
              <template v-if="currentLanguage === 'KR'">
                <li
                  class="text-center"
                  v-for="(item, index) in ecoKr"
                  :key="index"
                >
                  <template v-if="index === 3">
                    <a :href="item.link" target="_blank">{{ item.text }}</a>
                  </template>
                  <template v-else>
                    <router-link :to="{ path: item.link }" tag="a">{{
                      item.text
                    }}</router-link>
                  </template>
                </li>
              </template>
            </ul>
          </div>
          <div
            class="cursor-btn position-relative"
            @mouseover="showInfo = true"
            @mouseleave="showInfo = false"
          >
            {{ $t("home.headerFour") }}
            <div class="circle" :style="showInfo?'opacity:1':'opacity:0'"></div>
            <ul class="position-absolute" v-if="showInfo">
              <template v-if="currentLanguage === 'EN'">
                <li
                  class="text-center"
                  v-for="(item, index) in infoEn"
                  :key="index"
                >
                  <a>{{ item.text }}</a>
                </li>
              </template>
              <template v-if="currentLanguage === 'CN'">
                <li
                  class="text-center"
                  v-for="(item, index) in infoCn"
                  :key="index"
                >
                  <a>{{ item.text }}</a>
                </li>
              </template>
              <template v-if="currentLanguage === 'KR'">
                <li
                  class="text-center"
                  v-for="(item, index) in infoKr"
                  :key="index"
                >
                  <a>{{ item.text }}</a>
                </li>
              </template>
            </ul>
          </div>
          <div
            class="cursor-btn"
            @mouseover="showWhitePaper = true"
            @mouseleave="showWhitePaper = false"
          >
            <template v-if="currentLanguage === 'CN'">
              <router-link :to="{ path: '/whitePaper' }" tag="a">{{
                $t("home.headerFive")
              }}</router-link>
            </template>
            <template v-if="currentLanguage === 'EN'">
              <router-link :to="{ path: '/en/whitePaper' }" tag="a">{{
                $t("home.headerFive")
              }}</router-link>
            </template>
            <template v-if="currentLanguage === 'KR'">
              <router-link :to="{ path: '/kr/whitePaper' }" tag="a">{{
                $t("home.headerFive")
              }}</router-link>
            </template>
            <div class="circle" :style="showWhitePaper?'opacity:1':'opacity:0'"></div>
          </div>
          <div
            class="cursor-btn"
            @mouseover="showCommunite = true"
            @mouseleave="showCommunite = false"
          >
            <template v-if="currentLanguage === 'CN'">
              <router-link :to="{ path: '/communite' }" tag="a">{{
                $t("home.headerSix")
              }}</router-link>
            </template>
            <template v-if="currentLanguage === 'EN'">
              <router-link :to="{ path: '/en/communite' }" tag="a">{{
                $t("home.headerSix")
              }}</router-link>
            </template>
            <template v-if="currentLanguage === 'KR'">
              <router-link :to="{ path: '/kr/communite' }" tag="a">{{
                $t("home.headerSix")
              }}</router-link>
            </template>
            <div class="circle" :style="showCommunite?'opacity:1':'opacity:0'"></div>
          </div>
          <div
            class="cursor-btn position-relative"
            @mouseover="showWTC = true"
            @mouseleave="showWTC = false"
          >
            {{ $t("home.headerSeven") }}
            <div class="circle" :style="showWTC?'opacity:1':'opacity:0'"></div>
            <ul class="position-absolute" v-if="showWTC">
              <template v-if="currentLanguage === 'EN'">
                <li
                  class="text-center"
                  v-for="(item, index) in wtcEn"
                  :key="index"
                >
                  <a>{{ item.text }}</a>
                </li>
              </template>
              <template v-if="currentLanguage === 'CN'">
                <li
                  class="text-center"
                  v-for="(item, index) in wtcCn"
                  :key="index"
                >
                  <a>{{ item.text }}</a>
                </li>
              </template>
              <template v-if="currentLanguage === 'KR'">
                <li
                  class="text-center"
                  v-for="(item, index) in wtcKr"
                  :key="index"
                >
                  <router-link :to="{ path: item.link }" tag="a">{{
                    item.text
                  }}</router-link>
                </li>
              </template>
            </ul>
          </div>
          <div
            class="cursor-btn position-relative"
            @mouseover="showLanguage = true"
            @mouseleave="showLanguage = false"
          >
            <span class="text-center">
              <template v-if="currentLanguage === 'CN'">中文</template>
              <template v-if="currentLanguage === 'EN'">ENGLISH</template>
              <template v-if="currentLanguage === 'KR'">한국어</template>
            </span>
            <div class="circle" :style="showLanguage?'opacity:1':'opacity:0'"></div>
            <ul class="position-absolute" v-if="showLanguage">
              <li
                class="text-center"
                @click="changeLanguage('EN')"
                v-if="currentLanguage !== 'EN'"
              >
                ENGLISH
              </li>
              <li
                class="text-center"
                @click="changeLanguage('CN')"
                v-if="currentLanguage !== 'CN'"
              >
                中文
              </li>
              <li
                class="text-center"
                @click="changeLanguage('KR')"
                v-if="currentLanguage !== 'KR'"
              >
                한국어
              </li>
            </ul>
          </div>
          <div class="cursor-btn">
            <i class="iconfont">&#xe604;</i>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapGetters, mapMutations } from "vuex";
export default {
  name: "CommonHeader",
  data() {
    return {
      showWTC: false,
      showWTA: false,
      showSolution: false,
      showInfo: false,
      showEco: false,
      showWhitePaper: false,
      showCommunite: false,
      showLanguage: false,
      currentLanguage: "CN",
      wtcKr: [
        { link: "/kr/wtc/wallet", text: "Wallet" },
        { link: "/kr/wtc/exchange", text: "거래 플랫폼" },
      ],
      wtcEn: [
        { link: "", text: "SMN & GMN Token Swap" },
        { link: "", text: "Wallet" },
        { link: "", text: "Bamboo Wallet" },
        { link: "", text: "Exchanges" },
      ],
      wtcCn: [
        { link: "", text: "SMN、GMN代币切换速度" },
        { link: "", text: "钱包" },
        { link: "", text: "Bamboo Wallet" },
        { link: "", text: "交易平台" },
      ],
      wtaKr: [{ link: "/kr/wta/appDownload", text: "App" }],
      wtaEn: [
        { link: "", text: "BLUE PAPER" },
        { link: "", text: "SMN/GMN Pre-mining" },
        { link: "/en/wta/appDownload", text: "App Download" },
      ],
      wtaCn: [
        { link: "", text: "蓝皮书" },
        { link: "", text: "SMN/GMN预挖" },
        { link: "", text: "WTA App" },
      ],
      infoKr: [
        { link: "", text: "뉴스" },
        { link: "", text: "이벤트" },
        { link: "", text: "공지" },
        { link: "", text: "블로그" },
      ],
      infoEn: [
        { link: "", text: "News" },
        { link: "", text: "Activities" },
        { link: "", text: "Announcements" },
        { link: "", text: "Blog" },
      ],
      infoCn: [
        { link: "", text: "常见问题" },
        { link: "", text: "新闻" },
        { link: "", text: "公告" },
        { link: "", text: "博客" },
      ],
      solutionsKr: [
        { link: "/kr/solution/foodSystem", text: "농업 응용 솔루션" },
        { link: "/kr/solution/clothSystem", text: "의류 업계 응용 솔루션" },
      ],
      solutionsEn: [
        { link: "", text: "Blockchain + Liquor/Pharmaceuticals" },
        { link: "", text: "Blockchain + Cloud" },
        { link: "", text: "Blockchain + Warranty" },
        { link: "", text: "Agriculture Solution" },
        { link: "", text: "Clothing Industry Solution" },
      ],
      solutionsCn: [
        { link: "", text: "区块链+酒类/药品" },
        { link: "", text: "区块链+云系统" },
        { link: "", text: "区块链+保险" },
        { link: "", text: "农业应用方案" },
        { link: "", text: "服装行业应用方案" },
      ],
      ecoKr: [
        { link: "/kr/eco/kirin", text: "KIRINMINER" },
        { link: "/kr/eco/smn", text: "SMN" },
        { link: "/kr/eco/childChain", text: "자체인" },
        { link: "https://waltonchain.pro", text: "메인넷" },
        { link: "/kr/eco/bambooWallet", text: "Bamboo Wallet" },
      ],
      ecoEn: [
        { link: "", text: "KIRINMINER" },
        { link: "", text: "SMN" },
        { link: "", text: "Public Child Chains" },
        { link: "", text: "Blockchain Explorer" },
        { link: "", text: "Business Process" },
      ],
      ecoCn: [
        { link: "", text: "KIRINMINER" },
        { link: "", text: "SMN" },
        { link: "", text: "子链" },
        { link: "", text: "区块链浏览器" },
      ],
    };
  },
  computed: {
    ...mapGetters(["lang", "showSwitch", "commonLink"]),
  },
  mounted() {
    this.currentLanguage = localStorage.getItem("lang")
      ? localStorage.getItem("lang")
      : this.currentLanguage;
  },
  methods: {
    ...mapMutations(["SET_LANG", "SET_SHOWSWITCH", "SET_COMMONLINK"]),

    //切换语言
    changeLanguage(lang) {
      switch (lang) {
        case "CN":
          localStorage.setItem("locale", "cn");
          localStorage.setItem("lang", "CN");
          this.SET_LANG("CN");
          this.SET_COMMONLINK("http://www.waltonchain.org/");
          this.$i18n.locale = "cn";
          this.$router.push({
            path: "/",
          });
          break;
        case "EN":
          localStorage.setItem("locale", "en");
          localStorage.setItem("lang", "EN");
          this.SET_LANG("EN");
          this.SET_COMMONLINK("http://www.waltonchain.org/en/");
          this.$i18n.locale = "en";
          this.$router.push({
            path: "/en",
          });
          break;
        case "KR":
          localStorage.setItem("locale", "kr");
          localStorage.setItem("lang", "KR");
          this.SET_LANG("KR");
          this.SET_COMMONLINK("http://www.waltonchain.org/kr/");
          this.$i18n.locale = "kr";
          this.$router.push({
            path: "/kr",
          });
          break;
        default:
          break;
      }
      this.currentLanguage = lang;
      this.showLanguage = !this.showLanguage;
      this.SET_SHOWSWITCH(this.showLanguage);
    },
  },
};
</script>
<style lang="scss" scoped>
.commonHeader {
  .navs {
    color: #fff;
    font-size: 16px;
    letter-spacing: 1px;
    width: 100%;
    .container {
      max-width: 1640px;
      & > div {
        &:last-of-type {
          & > div {
            &:nth-of-type(8) {
              span {
                display: inline-block;
                width: 180px;
                padding: 1px 0px;
                border-radius: 25px;
                border: 1px solid rgba(255, 255, 255, 0.75);
                ul {
                  left: 72% !important;
                }
              }
            }
            i {
              font-size: 24px;
              display: inline-block;
              margin-top: -5px;
            }
          }
          div {
            padding: 62px 20px 52px;
          }
          div.circle {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background-color: #00ffda;
            padding: 0px;
            margin: 10px auto 0px;
          }
          ul {
            width: 180px;
            list-style: none;
            color: #eee;
            font-size: 12px;
            background-color: rgba(0, 0, 0, 0.85);
            border-color: #3f3f3f;
            border-top-color: #00ffda;
            box-shadow: 0px 13px 42px 11px rgba(0, 0, 0, 0.05);
            border: 1px solid #333;
            border-top: 2px solid #00ffda;
            top: 80%;
            left: 50%;
            margin-left: -90px;
            z-index: 199;
            li {
              padding: 12px 0px;
              &:hover {
                background: rgb(26, 25, 27);
              }
              &:hover a {
                color: #00ffda;
              }
            }
          }
        }
      }
    }
    a {
      text-decoration: none;
      display: inline-block;
      width: 100%;
      color: #eee;
    }
  }
}
</style>