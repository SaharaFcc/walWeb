<template>
  <svg :class="svgClass" v-on="$listeners">
    <use :xlink:href="iconName" />
  </svg>
</template>
<script>
export default {
  name: "SvgIcon",
  props: {
    iconClass: {
      type: String,
      required: true,
    },
    className: {
      type: String,
      default: "",
    },
  },
  computed: {
    iconName() {
      return `#icon-${this.iconClass}`;
    },
    svgClass() {
      if (this.className) {
        return "svg-icon " + this.className;
      } else {
        return "svg-icon";
      }
    },
    styleExternalIcon() {
      return {
        mask: `url(${this.iconClass}) no-repeat 50% 50%`,
        "-webkit-mask": `url(${this.iconClass}) no-repeat 50% 50%`,
      };
    },
  },
};
</script>
<style lang="scss" scoped>
.svg-icon {
  width: 1.5em;
  height: 1.5em;
  vertical-align: -0.15em;
  fill: currentColor;
  overflow: hidden;
  transform: inherit;
  animation-name: inherit;
  animation-duration: inherit;
  animation-play-state: inherit;
  animation-timing-function: inherit;
  &.app,
  &.tech {
    width: 77px !important;
    height: 77px !important;
  }
  &.inter {
    width: 92px !important;
    height: 77px !important;
  }
  &.data,
  &.custom,
  &.value,
  &.eco,
  &.token {
    width: 56px !important;
    height: 47px !important;
  }
  &.video {
    width: 40px !important;
    height: 30px !important;
    vertical-align: middle;
    margin-left: 20px;
  }
  &.back{
    width: 50px !important;
    height: 50px !important;
    right: 130px;
    bottom: 96px;
    z-index: 999;
  }
}
.svg-external-icon {
  background-color: currentColor;
  mask-size: cover !important;
  display: inline-block;
}
</style>
<style>
@-webkit-keyframes el_P7pZskq9FM_BHhscBjTM_Animation {
  10% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
  }
  30% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 10px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 10px);
  }
  50% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
  }
  0% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
  }
  100% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
  }
}
@keyframes el_P7pZskq9FM_BHhscBjTM_Animation {
  10% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
  }
  30% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 10px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 10px);
  }
  50% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
  }
  0% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
  }
  100% {
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
      translate(0px, 0px);
  }
}
.svgHover * {
  -webkit-animation-duration: 1s;
  animation-duration: 1s;
  -webkit-animation-play-state: running;
  animation-play-state: running;
  -webkit-animation-timing-function: cubic-bezier(0, 0, 1, 1);
  animation-timing-function: cubic-bezier(0, 0, 1, 1);
}
#icon-app_el_QLJEshgSMh {
  fill: #8200ff;
}
#icon-app_el_cc3JkLAXIf {
  fill: #00ffda;
}
#icon-app_el_P7pZskq9FM {
  fill: #8200ff;
}
#icon-app_el_iu_WQqvKDl {
  display: none;
}
#icon-app_el_OjVGKMBWBG {
  display: inline;
}
#icon-app_el_VzX5ihUdFc {
  fill: #00ffda;
}
#icon-app_el_5O3BhGmGCY {
  fill: #00ffda;
}
#icon-app_el_E8hbrsI0JW {
  fill: #00ffda;
}
#icon-app_el_y7EgwBgS2O {
  fill: #8200ff;
}
#icon-app_el_1FQcEcl_CB {
  display: none;
}
#icon-app_el_JbuqEE4Wvz {
  display: inline;
}
#icon-app_el_yLqZqBYqZK {
  fill: #8200ff;
}
#icon-app_el_zaFRNRCS4yT {
  fill: #00ffda;
}
#icon-app_el_P7pZskq9FM_BHhscBjTM {
  -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
    translate(0px, 0px);
  transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px)
    translate(0px, 0px);
}
.svgHover:hover #icon-app_el_P7pZskq9FM_BHhscBjTM {
  -webkit-animation-name: el_P7pZskq9FM_BHhscBjTM_Animation;
  animation-name: el_P7pZskq9FM_BHhscBjTM_Animation;
}
</style>
<style>
@-webkit-keyframes el_Snc17kyWEi_Animation {
  30% {
    opacity: 1;
  }
  50% {
    opacity: 0;
  }
  70% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@keyframes el_Snc17kyWEi_Animation {
  30% {
    opacity: 1;
  }
  50% {
    opacity: 0;
  }
  70% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@-webkit-keyframes el_tu2vQUUI1C_Animation {
  20% {
    opacity: 1;
  }
  40% {
    opacity: 0;
  }
  60% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@keyframes el_tu2vQUUI1C_Animation {
  20% {
    opacity: 1;
  }
  40% {
    opacity: 0;
  }
  60% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@-webkit-keyframes el_jMpXgNgnbb_Animation {
  10% {
    opacity: 1;
  }
  30% {
    opacity: 0;
  }
  50% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@keyframes el_jMpXgNgnbb_Animation {
  10% {
    opacity: 1;
  }
  30% {
    opacity: 0;
  }
  50% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
.svgHover * {
  -webkit-animation-duration: 1s;
  animation-duration: 1s;
  -webkit-animation-play-state: running;
  animation-play-state: running;
  -webkit-animation-timing-function: cubic-bezier(0, 0, 1, 1);
  animation-timing-function: cubic-bezier(0, 0, 1, 1);
}
#icon-inter_el_tu2vQUUI1C {
  fill: #00ffda;
  opacity: 1;
}
.svgHover:hover #icon-inter_el_tu2vQUUI1C {
  -webkit-animation-name: el_tu2vQUUI1C_Animation;
  animation-name: el_tu2vQUUI1C_Animation;
}
#icon-inter_el_Snc17kyWEi {
  fill: #00ffda;
  opacity: 1;
}
.svgHover:hover #icon-inter_el_Snc17kyWEi {
  -webkit-animation-name: el_Snc17kyWEi_Animation;
  animation-name: el_Snc17kyWEi_Animation;
}
#icon-inter_el_jMpXgNgnbb {
  fill: #00ffda;
  opacity: 1;
}
.svgHover:hover #icon-app_el_jMpXgNgnbb {
  -webkit-animation-name: el_jMpXgNgnbb_Animation;
  animation-name: el_jMpXgNgnbb_Animation;
}
#icon-inter_el_AVmy2bRj6A {
  fill: #8200ff;
}
</style>
<style>
@-webkit-keyframes el_9jYmBrid4_3_CPYRmXkfO_Animation {
  10% {
    -webkit-transform: translate(16.077px, 52.39px) scale(1, 1)
      translate(-16.077px, -52.39px);
    transform: translate(16.077px, 52.39px) scale(1, 1)
      translate(-16.077px, -52.39px);
  }
  30% {
    -webkit-transform: translate(16.077px, 52.39px) scale(0, 0)
      translate(-16.077px, -52.39px);
    transform: translate(16.077px, 52.39px) scale(0, 0)
      translate(-16.077px, -52.39px);
  }
  50% {
    -webkit-transform: translate(16.077px, 52.39px) scale(1, 1)
      translate(-16.077px, -52.39px);
    transform: translate(16.077px, 52.39px) scale(1, 1)
      translate(-16.077px, -52.39px);
  }
  70% {
    -webkit-transform: translate(16.077px, 52.39px) scale(0, 0)
      translate(-16.077px, -52.39px);
    transform: translate(16.077px, 52.39px) scale(0, 0)
      translate(-16.077px, -52.39px);
  }
  100% {
    -webkit-transform: translate(16.077px, 52.39px) scale(1, 1)
      translate(-16.077px, -52.39px);
    transform: translate(16.077px, 52.39px) scale(1, 1)
      translate(-16.077px, -52.39px);
  }
  0% {
    -webkit-transform: translate(16.077px, 52.39px) scale(1, 1)
      translate(-16.077px, -52.39px);
    transform: translate(16.077px, 52.39px) scale(1, 1)
      translate(-16.077px, -52.39px);
  }
}
@keyframes el_9jYmBrid4_3_CPYRmXkfO_Animation {
  10% {
    -webkit-transform: translate(16.077px, 52.39px) scale(1, 1)
      translate(-16.077px, -52.39px);
    transform: translate(16.077px, 52.39px) scale(1, 1)
      translate(-16.077px, -52.39px);
  }
  30% {
    -webkit-transform: translate(16.077px, 52.39px) scale(0, 0)
      translate(-16.077px, -52.39px);
    transform: translate(16.077px, 52.39px) scale(0, 0)
      translate(-16.077px, -52.39px);
  }
  50% {
    -webkit-transform: translate(16.077px, 52.39px) scale(1, 1)
      translate(-16.077px, -52.39px);
    transform: translate(16.077px, 52.39px) scale(1, 1)
      translate(-16.077px, -52.39px);
  }
  70% {
    -webkit-transform: translate(16.077px, 52.39px) scale(0, 0)
      translate(-16.077px, -52.39px);
    transform: translate(16.077px, 52.39px) scale(0, 0)
      translate(-16.077px, -52.39px);
  }
  100% {
    -webkit-transform: translate(16.077px, 52.39px) scale(1, 1)
      translate(-16.077px, -52.39px);
    transform: translate(16.077px, 52.39px) scale(1, 1)
      translate(-16.077px, -52.39px);
  }
  0% {
    -webkit-transform: translate(16.077px, 52.39px) scale(1, 1)
      translate(-16.077px, -52.39px);
    transform: translate(16.077px, 52.39px) scale(1, 1)
      translate(-16.077px, -52.39px);
  }
}
@-webkit-keyframes el_9jYmBrid4_3_Animation {
  10% {
    opacity: 1;
  }
  30% {
    opacity: 0;
  }
  50% {
    opacity: 1;
  }
  70% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
}
@keyframes el_9jYmBrid4_3_Animation {
  10% {
    opacity: 1;
  }
  30% {
    opacity: 0;
  }
  50% {
    opacity: 1;
  }
  70% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
}
.svgHover * {
  -webkit-animation-duration: 1s;
  animation-duration: 1s;
  -webkit-animation-play-state: running;
  animation-play-state: running;
  -webkit-animation-timing-function: cubic-bezier(0, 0, 1, 1);
  animation-timing-function: cubic-bezier(0, 0, 1, 1);
}
#icon-tech_el_sG7M8e0abR {
  display: none;
}
#icon-tech_el_Cv9t-vmiBR {
  display: inline;
}
#icon-tech_el_uJfnYrrLcK {
  fill: #8200ff;
}
#icon-tech_el_r4iNgH4lkb {
  fill: #00ffda;
}
#icon-tech_el_IAIIpgqR7n {
  fill: #8200ff;
}
#icon-tech_el_2KwzrPjMZ7 {
  display: none;
}
#icon-tech_el_Ruo6kOa5G6 {
  display: inline;
}
#icon-tech_el_DCHwnOyZLM {
  fill: #00ffda;
}
#icon-tech_el_Qi747b7V0c {
  fill: #00ffda;
}
#icon-tech_el_oljYzjy3G3 {
  fill: #00ffda;
}
#icon-tech_el_jd_4c-F5Cr {
  fill: #8200ff;
}
#icon-tech_el_RUCxbABECX {
  fill: #8200ff;
}
#icon-tech_el_9jYmBrid4_3 {
  fill: #00ffda;
  -webkit-animation-timing-function: cubic-bezier(0.42, 0, 1, 1);
  animation-timing-function: cubic-bezier(0.42, 0, 1, 1);
  opacity: 1;
}
.svgHover:hover #icon-tech_el_9jYmBrid4_3 {
  -webkit-animation-name: el_9jYmBrid4_3_Animation;
  animation-name: el_9jYmBrid4_3_Animation;
}
#icon-tech_el_0wHC37cMyE {
  visibility: hidden;
}
#icon-tech_el_9jYmBrid4_3_CPYRmXkfO {
  -webkit-animation-timing-function: cubic-bezier(0.42, 0, 1, 1);
  animation-timing-function: cubic-bezier(0.42, 0, 1, 1);
  -webkit-transform: translate(16.077px, 52.39px) scale(1, 1)
    translate(-16.077px, -52.39px);
  transform: translate(16.077px, 52.39px) scale(1, 1)
    translate(-16.077px, -52.39px);
}
.svgHover:hover #icon-tech_el_9jYmBrid4_3_CPYRmXkfO {
  -webkit-animation-name: el_9jYmBrid4_3_CPYRmXkfO_Animation;
  animation-name: el_9jYmBrid4_3_CPYRmXkfO_Animation;
}
</style>
<style>
@-webkit-keyframes el_JxgXoL_r6P_Animation {
  10% {
    opacity: 1;
  }
  30% {
    opacity: 0.5;
  }
  50% {
    opacity: 0;
  }
  70% {
    opacity: 0.5;
  }
  100% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
}
@keyframes el_JxgXoL_r6P_Animation {
  10% {
    opacity: 1;
  }
  30% {
    opacity: 0.5;
  }
  50% {
    opacity: 0;
  }
  70% {
    opacity: 0.5;
  }
  100% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
}
@-webkit-keyframes el_JxgXoL_r6P_pv5wKrqzn_Animation {
  10% {
    -webkit-transform: translate(28.32px, 10.11px) scale(1, 1)
      translate(-28.32px, -10.11px);
    transform: translate(28.32px, 10.11px) scale(1, 1)
      translate(-28.32px, -10.11px);
  }
  30% {
    -webkit-transform: translate(28.32px, 10.11px) scale(0.5, 0.5)
      translate(-28.32px, -10.11px);
    transform: translate(28.32px, 10.11px) scale(0.5, 0.5)
      translate(-28.32px, -10.11px);
  }
  50% {
    -webkit-transform: translate(28.32px, 10.11px) scale(0, 0)
      translate(-28.32px, -10.11px);
    transform: translate(28.32px, 10.11px) scale(0, 0)
      translate(-28.32px, -10.11px);
  }
  70% {
    -webkit-transform: translate(28.32px, 10.11px) scale(0.5, 0.5)
      translate(-28.32px, -10.11px);
    transform: translate(28.32px, 10.11px) scale(0.5, 0.5)
      translate(-28.32px, -10.11px);
  }
  100% {
    -webkit-transform: translate(28.32px, 10.11px) scale(1, 1)
      translate(-28.32px, -10.11px);
    transform: translate(28.32px, 10.11px) scale(1, 1)
      translate(-28.32px, -10.11px);
  }
  0% {
    -webkit-transform: translate(28.32px, 10.11px) scale(1, 1)
      translate(-28.32px, -10.11px);
    transform: translate(28.32px, 10.11px) scale(1, 1)
      translate(-28.32px, -10.11px);
  }
}
@keyframes el_JxgXoL_r6P_pv5wKrqzn_Animation {
  10% {
    -webkit-transform: translate(28.32px, 10.11px) scale(1, 1)
      translate(-28.32px, -10.11px);
    transform: translate(28.32px, 10.11px) scale(1, 1)
      translate(-28.32px, -10.11px);
  }
  30% {
    -webkit-transform: translate(28.32px, 10.11px) scale(0.5, 0.5)
      translate(-28.32px, -10.11px);
    transform: translate(28.32px, 10.11px) scale(0.5, 0.5)
      translate(-28.32px, -10.11px);
  }
  50% {
    -webkit-transform: translate(28.32px, 10.11px) scale(0, 0)
      translate(-28.32px, -10.11px);
    transform: translate(28.32px, 10.11px) scale(0, 0)
      translate(-28.32px, -10.11px);
  }
  70% {
    -webkit-transform: translate(28.32px, 10.11px) scale(0.5, 0.5)
      translate(-28.32px, -10.11px);
    transform: translate(28.32px, 10.11px) scale(0.5, 0.5)
      translate(-28.32px, -10.11px);
  }
  100% {
    -webkit-transform: translate(28.32px, 10.11px) scale(1, 1)
      translate(-28.32px, -10.11px);
    transform: translate(28.32px, 10.11px) scale(1, 1)
      translate(-28.32px, -10.11px);
  }
  0% {
    -webkit-transform: translate(28.32px, 10.11px) scale(1, 1)
      translate(-28.32px, -10.11px);
    transform: translate(28.32px, 10.11px) scale(1, 1)
      translate(-28.32px, -10.11px);
  }
}
@-webkit-keyframes el_p8XQ511bnq_Animation {
  10% {
    opacity: 1;
  }
  30% {
    opacity: 0.5;
  }
  50% {
    opacity: 0;
  }
  70% {
    opacity: 0.5;
  }
  100% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
}
@keyframes el_p8XQ511bnq_Animation {
  10% {
    opacity: 1;
  }
  30% {
    opacity: 0.5;
  }
  50% {
    opacity: 0;
  }
  70% {
    opacity: 0.5;
  }
  100% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
}
@-webkit-keyframes el_p8XQ511bnq_b0ZByVMBw_Animation {
  10% {
    -webkit-transform: translate(28.32px, 24.53px) scale(1, 1)
      translate(-28.32px, -24.53px);
    transform: translate(28.32px, 24.53px) scale(1, 1)
      translate(-28.32px, -24.53px);
  }
  30% {
    -webkit-transform: translate(28.32px, 24.53px) scale(0.5, 0.5)
      translate(-28.32px, -24.53px);
    transform: translate(28.32px, 24.53px) scale(0.5, 0.5)
      translate(-28.32px, -24.53px);
  }
  50% {
    -webkit-transform: translate(28.32px, 24.53px) scale(0, 0)
      translate(-28.32px, -24.53px);
    transform: translate(28.32px, 24.53px) scale(0, 0)
      translate(-28.32px, -24.53px);
  }
  70% {
    -webkit-transform: translate(28.32px, 24.53px) scale(0.5, 0.5)
      translate(-28.32px, -24.53px);
    transform: translate(28.32px, 24.53px) scale(0.5, 0.5)
      translate(-28.32px, -24.53px);
  }
  100% {
    -webkit-transform: translate(28.32px, 24.53px) scale(1, 1)
      translate(-28.32px, -24.53px);
    transform: translate(28.32px, 24.53px) scale(1, 1)
      translate(-28.32px, -24.53px);
  }
  0% {
    -webkit-transform: translate(28.32px, 24.53px) scale(1, 1)
      translate(-28.32px, -24.53px);
    transform: translate(28.32px, 24.53px) scale(1, 1)
      translate(-28.32px, -24.53px);
  }
}
@keyframes el_p8XQ511bnq_b0ZByVMBw_Animation {
  10% {
    -webkit-transform: translate(28.32px, 24.53px) scale(1, 1)
      translate(-28.32px, -24.53px);
    transform: translate(28.32px, 24.53px) scale(1, 1)
      translate(-28.32px, -24.53px);
  }
  30% {
    -webkit-transform: translate(28.32px, 24.53px) scale(0.5, 0.5)
      translate(-28.32px, -24.53px);
    transform: translate(28.32px, 24.53px) scale(0.5, 0.5)
      translate(-28.32px, -24.53px);
  }
  50% {
    -webkit-transform: translate(28.32px, 24.53px) scale(0, 0)
      translate(-28.32px, -24.53px);
    transform: translate(28.32px, 24.53px) scale(0, 0)
      translate(-28.32px, -24.53px);
  }
  70% {
    -webkit-transform: translate(28.32px, 24.53px) scale(0.5, 0.5)
      translate(-28.32px, -24.53px);
    transform: translate(28.32px, 24.53px) scale(0.5, 0.5)
      translate(-28.32px, -24.53px);
  }
  100% {
    -webkit-transform: translate(28.32px, 24.53px) scale(1, 1)
      translate(-28.32px, -24.53px);
    transform: translate(28.32px, 24.53px) scale(1, 1)
      translate(-28.32px, -24.53px);
  }
  0% {
    -webkit-transform: translate(28.32px, 24.53px) scale(1, 1)
      translate(-28.32px, -24.53px);
    transform: translate(28.32px, 24.53px) scale(1, 1)
      translate(-28.32px, -24.53px);
  }
}
.svgHover * {
  -webkit-animation-duration: 1s;
  animation-duration: 1s;
  -webkit-animation-play-state: running;
  animation-play-state: running;
  -webkit-animation-timing-function: cubic-bezier(0, 0, 1, 1);
  animation-timing-function: cubic-bezier(0, 0, 1, 1);
}
#icon-token_el_vghdiOK5Wy {
  fill: #8200ff;
}
#icon-token_el_p8XQ511bnq {
  fill: #00ffda;
  opacity: 1;
}
.svgHover:hover #icon-token_el_p8XQ511bnq {
  -webkit-animation-name: el_p8XQ511bnq_Animation;
  animation-name: el_p8XQ511bnq_Animation;
}
#icon-token_el_JxgXoL_r6P {
  fill: #00ffda;
  opacity: 1;
}
.svgHover:hover #icon-token_el_JxgXoL_r6P {
  -webkit-animation-name: el_JxgXoL_r6P_Animation;
  animation-name: el_JxgXoL_r6P_Animation;
}
#icon-token_el_Bt18wgbyuP {
  display: none;
}
#icon-token_el_CWsAXOS475 {
  display: inline;
}
#icon-token_el_7qxnFm7CJu {
  fill: #8200ff;
}
#icon-token_el_F27XtDB4sf {
  fill: #00ffda;
}
#icon-token_el_MlJHTzKMXW {
  fill: #8200ff;
}
#icon-token_el_lt6vvDAr__ {
  fill: #00ffda;
}
#icon-token_el_--Pp2QG23S {
  fill: #00ffda;
}
#icon-token_el_AJiR0i0XWV {
  fill: #00ffda;
}
#icon-token_el_dBb36dskbv {
  fill: #8200ff;
}
#icon-token_el__MHKqiKhz_c {
  fill: #8200ff;
}
#icon-token_el_4WYCSswZHPg {
  fill: #8200ff;
}
#icon-token_el_zGq9UPjity2 {
  display: none;
}
#icon-token_el_w1AQzelhULp {
  display: inline;
}
#icon-token_el_ta9CpQre5YN {
  fill: #8200ff;
}
#icon-token_el_FkuSSkCz8WT {
  fill: #00ffda;
}
#icon-token_el_Z72Z0CBMuF5 {
  display: none;
}
#icon-token_el_vQiSTdt6cEo {
  display: inline;
}
#icon-token_el_DNcPqtYpwDr {
  fill: #00ffda;
}
#icon-token_el_BWe2PpgTi-T {
  fill: #8200ff;
}
#icon-token_el_J5kG0eQl3Za {
  fill: #8200ff;
}
#icon-token_el_k0gJz1in5_y {
  fill: #8200ff;
}
#icon-token_el_6EHcFfeuaRY {
  fill: #8200ff;
}
#icon-token_el_hZl7yj1ckOt {
  fill: #8200ff;
}
#icon-token_el_zU3eN8kGAUc {
  fill: #8200ff;
}
#icon-token_el_ES9jsmxfrJz {
  fill: #8200ff;
}
#icon-token_el_4eariBj52Vc {
  display: none;
}
#icon-token_el_MTnEqTUEcRj {
  display: inline;
}
#icon-token_el_Bonu2ePJjrb {
  fill: #8200ff;
}
#icon-token_el_QSZ_xdl2qtw {
  fill: #8200ff;
}
#icon-token_el_KHH5KaLLI3F {
  fill: #00ffda;
}
#icon-token_el_npNYB5vsvCa {
  fill: #00ffda;
}
#icon-token_el_s36b1uMRlsf {
  fill: #8200ff;
}
#icon-token_el__Wuz6_o_USh {
  fill: #8200ff;
}
#icon-token_el_W5xUzXS6R67 {
  fill: #8200ff;
}
#icon-token_el_KMdPnrad-XH {
  fill: #00ffda;
}
#icon-token_el_nLq7oYRXbki {
  fill: #8200ff;
}
#icon-token_el_-bKuuhKlDk0 {
  fill: #8200ff;
}
#icon-token_el_NiprfWfVNVE {
  fill: #8200ff;
}
#icon-token_el_eEi7ux0suRt {
  fill: #8200ff;
}
#icon-token_el_mqAQ2QTrVwz {
  fill: #8200ff;
}
#icon-token_el_ncy5m-dyOBi {
  fill: #8200ff;
}
#icon-token_el_tYA9ERUsvVf {
  fill: #8200ff;
}
#icon-token_el_O7AAD7avyq3 {
  fill: #00ffda;
}
#icon-token_el_iEGofKXn1F_ {
  fill: #8200ff;
}
#icon-token_el_O8nG38Rkg34 {
  fill: #8200ff;
}
#icon-token_el_HjZTZIwZoAt {
  fill: #8200ff;
}
#icon-token_el_oz5OSrjlfHb {
  fill: #8200ff;
}
#icon-token_el_jglF2bj64df {
  fill: #8200ff;
}
#icon-token_el_syzUdYOZPmC {
  fill: #00ffda;
}
#icon-token_el_dI_glXvfnoq {
  fill: #8200ff;
}
#icon-token_el_st4fv2C3Wcc {
  fill: #8200ff;
}
#icon-token_el_LqHHIdyRnRE {
  fill: #8200ff;
}
#icon-token_el_p8XQ511bnq_b0ZByVMBw {
  -webkit-transform: translate(28.32px, 24.53px) scale(1, 1)
    translate(-28.32px, -24.53px);
  transform: translate(28.32px, 24.53px) scale(1, 1)
    translate(-28.32px, -24.53px);
}
.svgHover:hover #icon-token_el_p8XQ511bnq_b0ZByVMBw {
  -webkit-animation-name: el_p8XQ511bnq_b0ZByVMBw_Animation;
  animation-name: el_p8XQ511bnq_b0ZByVMBw_Animation;
}
#icon-token_el_JxgXoL_r6P_pv5wKrqzn {
  -webkit-transform: translate(28.32px, 10.11px) scale(1, 1)
    translate(-28.32px, -10.11px);
  transform: translate(28.32px, 10.11px) scale(1, 1)
    translate(-28.32px, -10.11px);
}
.svgHover:hover #icon-token_el_JxgXoL_r6P_pv5wKrqzn {
  -webkit-animation-name: el_JxgXoL_r6P_pv5wKrqzn_Animation;
  animation-name: el_JxgXoL_r6P_pv5wKrqzn_Animation;
}
</style>
<style>
@-webkit-keyframes el_YkxZbx_TtI_Animation {
  10% {
    opacity: 1;
  }
  90% {
    opacity: 0;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 0;
  }
}
@keyframes el_YkxZbx_TtI_Animation {
  10% {
    opacity: 1;
  }
  90% {
    opacity: 0;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 0;
  }
}
@-webkit-keyframes el_c2x7KYoP3Fh_Animation {
  10% {
    opacity: 1;
  }
  90% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@keyframes el_c2x7KYoP3Fh_Animation {
  10% {
    opacity: 1;
  }
  90% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@-webkit-keyframes el_c2x7KYoP3Fh_CleOhVbrU_Animation {
  10% {
    -webkit-transform: translate(28.102px, 23.5px) rotate(-360deg)
      translate(-28.102px, -23.5px);
    transform: translate(28.102px, 23.5px) rotate(-360deg)
      translate(-28.102px, -23.5px);
  }
  90% {
    -webkit-transform: translate(28.102px, 23.5px) rotate(0deg)
      translate(-28.102px, -23.5px);
    transform: translate(28.102px, 23.5px) rotate(0deg)
      translate(-28.102px, -23.5px);
  }
  0% {
    -webkit-transform: translate(28.102px, 23.5px) rotate(-360deg)
      translate(-28.102px, -23.5px);
    transform: translate(28.102px, 23.5px) rotate(-360deg)
      translate(-28.102px, -23.5px);
  }
  100% {
    -webkit-transform: translate(28.102px, 23.5px) rotate(0deg)
      translate(-28.102px, -23.5px);
    transform: translate(28.102px, 23.5px) rotate(0deg)
      translate(-28.102px, -23.5px);
  }
}
@keyframes el_c2x7KYoP3Fh_CleOhVbrU_Animation {
  10% {
    -webkit-transform: translate(28.102px, 23.5px) rotate(-360deg)
      translate(-28.102px, -23.5px);
    transform: translate(28.102px, 23.5px) rotate(-360deg)
      translate(-28.102px, -23.5px);
  }
  90% {
    -webkit-transform: translate(28.102px, 23.5px) rotate(0deg)
      translate(-28.102px, -23.5px);
    transform: translate(28.102px, 23.5px) rotate(0deg)
      translate(-28.102px, -23.5px);
  }
  0% {
    -webkit-transform: translate(28.102px, 23.5px) rotate(-360deg)
      translate(-28.102px, -23.5px);
    transform: translate(28.102px, 23.5px) rotate(-360deg)
      translate(-28.102px, -23.5px);
  }
  100% {
    -webkit-transform: translate(28.102px, 23.5px) rotate(0deg)
      translate(-28.102px, -23.5px);
    transform: translate(28.102px, 23.5px) rotate(0deg)
      translate(-28.102px, -23.5px);
  }
}
@-webkit-keyframes el_7bKyNptnv2_Animation {
  10% {
    opacity: 1;
  }
  50% {
    opacity: 0;
  }
  90% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@keyframes el_7bKyNptnv2_Animation {
  10% {
    opacity: 1;
  }
  50% {
    opacity: 0;
  }
  90% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
.svgHover * {
  -webkit-animation-duration: 1s;
  animation-duration: 1s;
  -webkit-animation-play-state: running;
  animation-play-state: running;
  -webkit-animation-timing-function: cubic-bezier(0, 0, 1, 1);
  animation-timing-function: cubic-bezier(0, 0, 1, 1);
}
#icon-data_el_jOei76ksrh {
  fill: #8200ff;
}
#icon-data_el_7bKyNptnv2 {
  fill: #00ffda;
  opacity: 1;
}
.svgHover:hover #icon-data_el_7bKyNptnv2 {
  -webkit-animation-name: el_7bKyNptnv2_Animation;
  animation-name: el_7bKyNptnv2_Animation;
}
#icon-data_el_W8SPTU3OUH {
  fill: #8200ff;
}
#icon-data_el_dXX-0vC5Pc {
  fill: #00ffda;
}
#icon-data_el_xZtnCQg5oMV {
  fill: #00ffda;
}
#icon-data_el_yxJYwLrIz-Y {
  fill: #00ffda;
}
#icon-data_el_tYTv5MrgRqf {
  fill: #8200ff;
}
#icon-data_el_alHKIn9tGwg {
  fill: #8200ff;
}
#icon-data_el_OwjXSORDjOW {
  fill: #8200ff;
}
#icon-data_el_YkxZbx_TtI_01TYyVBdR {
  -webkit-transform: translate(32.76px, 23.18px) rotate(-360deg)
    translate(-32.76px, -23.18px);
  transform: translate(32.76px, 23.18px) rotate(-360deg)
    translate(-32.76px, -23.18px);
}
#icon-data_el_YkxZbx_TtI {
  opacity: 1;
}
.svgHover:hover #icon-data_el_YkxZbx_TtI {
  -webkit-animation-name: el_YkxZbx_TtI_Animation;
  animation-name: el_YkxZbx_TtI_Animation;
}
#icon-data_el_c2x7KYoP3Fh_CleOhVbrU {
  -webkit-transform: translate(28.102px, 23.5px) rotate(-360deg)
    translate(-28.102px, -23.5px);
  transform: translate(28.102px, 23.5px) rotate(-360deg)
    translate(-28.102px, -23.5px);
}
.svgHover:hover #icon-data_el_c2x7KYoP3Fh_CleOhVbrU {
  -webkit-animation-name: el_c2x7KYoP3Fh_CleOhVbrU_Animation;
  animation-name: el_c2x7KYoP3Fh_CleOhVbrU_Animation;
}
#icon-data_el_c2x7KYoP3Fh {
  opacity: 1;
}
.svgHover:hover #icon-data_el_c2x7KYoP3Fh {
  -webkit-animation-name: el_c2x7KYoP3Fh_Animation;
  animation-name: el_c2x7KYoP3Fh_Animation;
}
</style>
<style>
@-webkit-keyframes el_odEQjJncnkQ_Animation {
  0% {
    opacity: 1;
  }
  30% {
    opacity: 0;
  }
  50% {
    opacity: 1;
  }
  70% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@keyframes el_odEQjJncnkQ_Animation {
  0% {
    opacity: 1;
  }
  30% {
    opacity: 0;
  }
  50% {
    opacity: 1;
  }
  70% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@-webkit-keyframes el_odEQjJncnkQ_Y_JPsnTrG_Animation {
  0% {
    -webkit-transform: translate(28.066px, 23.17px) scale(1, 1)
      translate(-28.066px, -23.17px);
    transform: translate(28.066px, 23.17px) scale(1, 1)
      translate(-28.066px, -23.17px);
  }
  30% {
    -webkit-transform: translate(28.066px, 23.17px) scale(0, 0)
      translate(-28.066px, -23.17px);
    transform: translate(28.066px, 23.17px) scale(0, 0)
      translate(-28.066px, -23.17px);
  }
  50% {
    -webkit-transform: translate(28.066px, 23.17px) scale(1, 1)
      translate(-28.066px, -23.17px);
    transform: translate(28.066px, 23.17px) scale(1, 1)
      translate(-28.066px, -23.17px);
  }
  70% {
    -webkit-transform: translate(28.066px, 23.17px) scale(1, 1)
      translate(-28.066px, -23.17px);
    transform: translate(28.066px, 23.17px) scale(1, 1)
      translate(-28.066px, -23.17px);
  }
  100% {
    -webkit-transform: translate(28.066px, 23.17px) scale(1, 1)
      translate(-28.066px, -23.17px);
    transform: translate(28.066px, 23.17px) scale(1, 1)
      translate(-28.066px, -23.17px);
  }
}
@keyframes el_odEQjJncnkQ_Y_JPsnTrG_Animation {
  0% {
    -webkit-transform: translate(28.066px, 23.17px) scale(1, 1)
      translate(-28.066px, -23.17px);
    transform: translate(28.066px, 23.17px) scale(1, 1)
      translate(-28.066px, -23.17px);
  }
  30% {
    -webkit-transform: translate(28.066px, 23.17px) scale(0, 0)
      translate(-28.066px, -23.17px);
    transform: translate(28.066px, 23.17px) scale(0, 0)
      translate(-28.066px, -23.17px);
  }
  50% {
    -webkit-transform: translate(28.066px, 23.17px) scale(1, 1)
      translate(-28.066px, -23.17px);
    transform: translate(28.066px, 23.17px) scale(1, 1)
      translate(-28.066px, -23.17px);
  }
  70% {
    -webkit-transform: translate(28.066px, 23.17px) scale(1, 1)
      translate(-28.066px, -23.17px);
    transform: translate(28.066px, 23.17px) scale(1, 1)
      translate(-28.066px, -23.17px);
  }
  100% {
    -webkit-transform: translate(28.066px, 23.17px) scale(1, 1)
      translate(-28.066px, -23.17px);
    transform: translate(28.066px, 23.17px) scale(1, 1)
      translate(-28.066px, -23.17px);
  }
}
.svgHover * {
  -webkit-animation-duration: 1s;
  animation-duration: 1s;
  -webkit-animation-play-state: running;
  animation-play-state: running;
  -webkit-animation-timing-function: cubic-bezier(0, 0, 1, 1);
  animation-timing-function: cubic-bezier(0, 0, 1, 1);
}
#icon-value_el_koG3RgmyMMP {
  display: none;
}
#icon-value_el_Q3V1YFTbf7q {
  display: inline;
}
#icon-value_el_hTSBPLanukO {
  fill: #8200ff;
}
#icon-value_el_O6OepnG12qt {
  fill: #00ffda;
}
#icon-value_el_2ZypnMR1nth {
  fill: #00ffda;
}
#icon-value_el_CdslwhYGd4p {
  display: none;
}
#icon-value_el_l9lbsYXJsJn {
  display: inline;
}
#icon-value_el_a9vzC4W5KCV {
  fill: #8200ff;
}
#icon-value_el_U6WKOyHotHc {
  fill: #00ffda;
}
#icon-value_el_1ouCjumSSza {
  fill: #8200ff;
}
#icon-value_el_fE8ANwm1Wcb {
  fill: #00ffda;
}
#icon-value_el_enjmkrBc-zL {
  fill: #00ffda;
}
#icon-value_el_FmODQer5uR6 {
  fill: #00ffda;
}
#icon-value_el_J3_GHonvgLu {
  fill: #8200ff;
}
#icon-value_el_7UdH2nXGxXz {
  fill: #8200ff;
}
#icon-value_el_KLl82GsVQTn {
  fill: #8200ff;
}
#icon-value_el__j5JvX1Einb {
  fill: #8200ff;
}
#icon-value_el_odEQjJncnkQ {
  fill: #00ffda;
  opacity: 1;
}
.svgHover:hover #icon-value_el_odEQjJncnkQ {
  -webkit-animation-name: el_odEQjJncnkQ_Animation;
  animation-name: el_odEQjJncnkQ_Animation;
}
#icon-value_el_5fF7awzlHw_ {
  display: none;
}
#icon-value_el_iUu38gwF340 {
  display: inline;
}
#icon-value_el_HKfoTBeoSkb {
  fill: #00ffda;
}
#icon-value_el_NZZKm2C2Ngg {
  fill: #8200ff;
}
#icon-value_el_y9Gohg673xD {
  fill: #8200ff;
}
#icon-value_el_TxLLylgsym4 {
  fill: #8200ff;
}
#icon-value_el_WPfZDuPd_hC {
  fill: #8200ff;
}
#icon-value_el_dRXWEGIBV9D {
  fill: #8200ff;
}
#icon-value_el_Bmqq91MbG6b {
  fill: #8200ff;
}
#icon-value_el_tBPv6Eb-dr9 {
  fill: #8200ff;
}
#icon-value_el_cfC3n3NgwiY {
  display: none;
}
#icon-value_el_nWby3FRlESE {
  display: inline;
}
#icon-value_el_GXBNQRwVhD1 {
  fill: #8200ff;
}
#icon-value_el__AxfwMhwgD5 {
  fill: #8200ff;
}
#icon-value_el_oUl6IF_MQdy {
  fill: #00ffda;
}
#icon-value_el_rG94-9rcfkn {
  fill: #00ffda;
}
#icon-value_el_QHm6VtARcQF {
  fill: #8200ff;
}
#icon-value_el_oNQnrfxZcYD {
  fill: #8200ff;
}
#icon-value_el_qkj0YsEEZcQ {
  fill: #8200ff;
}
#icon-value_el_9fadhgzjXTX {
  fill: #00ffda;
}
#icon-value_el__4c5d2t_ab9 {
  fill: #8200ff;
}
#icon-value_el_FPHCQEo-YRL {
  fill: #8200ff;
}
#icon-value_el_gkiJ9OtfD3D {
  fill: #8200ff;
}
#icon-value_el_YLZMkDs5FpM {
  fill: #8200ff;
}
#icon-value_el_L9z6_QCpNWP {
  fill: #8200ff;
}
#icon-value_el_jAWT2s391jw {
  fill: #8200ff;
}
#icon-value_el_1Vo9A6upAH5 {
  fill: #8200ff;
}
#icon-value_l_vTmqVTUuh-- {
  fill: #00ffda;
}
#icon-value_el_BI0eAtXeSk0 {
  fill: #8200ff;
}
#icon-value_el_3LGl2yqh_C- {
  fill: #8200ff;
}
#icon-value_el__lGCn04_FCU {
  fill: #8200ff;
}
#icon-value_el_5oTXjF7FDFP {
  fill: #8200ff;
}
#icon-value_el_vR4Hg42bGkW {
  fill: #8200ff;
}
#icon-value_el_1QqnYjo-llA {
  fill: #00ffda;
}
#icon-value_el_2mIbevnE3WK {
  fill: #8200ff;
}
#icon-value_el_-Z-F0WEf-2C {
  fill: #8200ff;
}
#icon-value_el_Dm3oYgumB8u {
  fill: #8200ff;
}
#icon-value_el_odEQjJncnkQ_qW_oAIs7r {
  -webkit-transform: translate(28.066px, 23.17px) translate(-28.066px, -23.17px)
    translate(0px, 50px);
  transform: translate(28.066px, 23.17px) translate(-28.066px, -23.17px)
    translate(0px, 50px);
}
#icon-value_el_odEQjJncnkQ_1bvS3dDzs {
  -webkit-transform: translate(28.066px, 23.17px) rotate(-360deg)
    translate(-28.066px, -23.17px);
  transform: translate(28.066px, 23.17px) rotate(-360deg)
    translate(-28.066px, -23.17px);
}
#icon-value_el_odEQjJncnkQ_Ad6Uda8pD {
  -webkit-transform: translate(28.066px, 23.17px) scale(1, 1)
    translate(-28.066px, -23.17px);
  transform: translate(28.066px, 23.17px) scale(1, 1)
    translate(-28.066px, -23.17px);
}
#icon-value_el_odEQjJncnkQ_ctTqeY1vT {
  -webkit-transform: translate(28.066px, 23.17px) translate(-28.066px, -23.17px)
    translate(0px, 0px);
  transform: translate(28.066px, 23.17px) translate(-28.066px, -23.17px)
    translate(0px, 0px);
}
#icon-value_el_odEQjJncnkQ_Y_JPsnTrG {
  -webkit-transform: translate(28.066px, 23.17px) scale(1, 1)
    translate(-28.066px, -23.17px);
  transform: translate(28.066px, 23.17px) scale(1, 1)
    translate(-28.066px, -23.17px);
}
.svgHover:hover #icon-value_el_odEQjJncnkQ_Y_JPsnTrG {
  -webkit-animation-name: el_odEQjJncnkQ_Y_JPsnTrG_Animation;
  animation-name: el_odEQjJncnkQ_Y_JPsnTrG_Animation;
}
</style>
<style>
@-webkit-keyframes el_AXOCoMK4BZG_88BIRxieb_Animation {
  10% {
    -webkit-transform: translate(28.45px, 23.54px) rotate(-360deg)
      translate(-28.45px, -23.54px);
    transform: translate(28.45px, 23.54px) rotate(-360deg)
      translate(-28.45px, -23.54px);
  }
  90% {
    -webkit-transform: translate(28.45px, 23.54px) rotate(0deg)
      translate(-28.45px, -23.54px);
    transform: translate(28.45px, 23.54px) rotate(0deg)
      translate(-28.45px, -23.54px);
  }
  0% {
    -webkit-transform: translate(28.45px, 23.54px) rotate(-360deg)
      translate(-28.45px, -23.54px);
    transform: translate(28.45px, 23.54px) rotate(-360deg)
      translate(-28.45px, -23.54px);
  }
  100% {
    -webkit-transform: translate(28.45px, 23.54px) rotate(0deg)
      translate(-28.45px, -23.54px);
    transform: translate(28.45px, 23.54px) rotate(0deg)
      translate(-28.45px, -23.54px);
  }
}
@keyframes el_AXOCoMK4BZG_88BIRxieb_Animation {
  10% {
    -webkit-transform: translate(28.45px, 23.54px) rotate(-360deg)
      translate(-28.45px, -23.54px);
    transform: translate(28.45px, 23.54px) rotate(-360deg)
      translate(-28.45px, -23.54px);
  }
  90% {
    -webkit-transform: translate(28.45px, 23.54px) rotate(0deg)
      translate(-28.45px, -23.54px);
    transform: translate(28.45px, 23.54px) rotate(0deg)
      translate(-28.45px, -23.54px);
  }
  0% {
    -webkit-transform: translate(28.45px, 23.54px) rotate(-360deg)
      translate(-28.45px, -23.54px);
    transform: translate(28.45px, 23.54px) rotate(-360deg)
      translate(-28.45px, -23.54px);
  }
  100% {
    -webkit-transform: translate(28.45px, 23.54px) rotate(0deg)
      translate(-28.45px, -23.54px);
    transform: translate(28.45px, 23.54px) rotate(0deg)
      translate(-28.45px, -23.54px);
  }
}
.svgHover * {
  -webkit-animation-duration: 1s;
  animation-duration: 1s;
  -webkit-animation-play-state: running;
  animation-play-state: running;
  -webkit-animation-timing-function: cubic-bezier(0, 0, 1, 1);
  animation-timing-function: cubic-bezier(0, 0, 1, 1);
}
#icon-custom_el_rePbP9qg6J {
  display: none;
}
#icon-custom_el_3QfdkOgCsF {
  display: inline;
}
#icon-custom_el_GWgCfKmdLP {
  fill: #8200ff;
}
#icon-custom_el_B7JY8k4XTq {
  fill: #00ffda;
}
#icon-custom_el_mw_BLT-rSQv {
  fill: #00ffda;
}
#icon-custom_el_IqnCW44_tsh {
  display: none;
}
#icon-custom_el_ZBUt9wDaUrM {
  display: inline;
}
#icon-custom_el_3DH9d5bWriW {
  fill: #8200ff;
}
#icon-custom_el_DhJomKWWhdG {
  fill: #00ffda;
}
#icon-custom_el_zNRogbXj3NI {
  fill: #8200ff;
}
#icon-custom_el_J57iXKCqXwb {
  fill: #00ffda;
}
#icon-custom_el_o_uhvM09P-1 {
  fill: #00ffda;
}
#icon-custom_el_Iz262vbGaD3 {
  fill: #00ffda;
}
#icon-custom_el_ZUQ381_843I {
  fill: #8200ff;
}
#icon-custom_el_WCM49NDQhxX {
  fill: #8200ff;
}
#icon-custom_el_JUqXvjUjU7q {
  fill: #8200ff;
}
#icon-custom_el_88SI3Su63Im {
  display: none;
}
#icon-custom_el_RyJKofG81Om {
  display: inline;
}
#icon-custom_el_OS0W57wdbSS {
  fill: #8200ff;
}
#icon-custom_el_KWoRWjUiZjo {
  fill: #00ffda;
}
#icon-custom_el_r4fYqIxMqq0 {
  fill: #00ffda;
}
#icon-custom_el_9hZZnriI0-4 {
  fill: #8200ff;
}
#icon-custom_el_qga3yfM3mAr {
  fill: #8200ff;
}
#icon-custom_el_FqdjESHKcuV {
  fill: #8200ff;
}
#icon-custom_el_k-grfEbojjF {
  fill: #8200ff;
}
#icon-custom_el_yi7QdOWfHia {
  fill: #8200ff;
}
#icon-custom_el_o7EdoMGzVlt {
  fill: #8200ff;
}
#icon-custom_el_YuoViMijuPT {
  fill: #8200ff;
}
#icon-custom_el_A6WiIVa6g_6 {
  display: none;
}
#icon-custom_el_ajsMo1f7QnU {
  display: inline;
}
#icon-custom_el_0JOJb8QzNvp {
  fill: #8200ff;
}
#icon-custom_el_hty8cTx-aOx {
  fill: #8200ff;
}
#icon-custom_el_-984fMwrqUk {
  fill: #00ffda;
}
#icon-custom_el_yvZTHeFmgmR {
  fill: #00ffda;
}
#icon-custom_el_TvJQ8gvDvZA {
  fill: #8200ff;
}
#icon-custom_el__sf3qwrs5aF {
  fill: #8200ff;
}
#icon-custom_el_mVjamGr1i-b {
  fill: #8200ff;
}
#icon-custom_el_lGNjmOMI_-4 {
  fill: #00ffda;
}
#icon-custom_el_4tXaMdT2Jkr {
  fill: #8200ff;
}
#icon-custom_el_ZN7jZe0Rwbx {
  fill: #8200ff;
}
#icon-custom_el_meQZTBjHkUN {
  fill: #8200ff;
}
#icon-custom_el_mTeP1OE4Ji9 {
  fill: #8200ff;
}
#icon-custom_el_vepLxuZzQKp {
  fill: #8200ff;
}
#icon-custom_el_d0an1mbHLCZ {
  fill: #8200ff;
}
#icon-custom_el_T4iSL-p-kt- {
  fill: #8200ff;
}
#icon-custom_el_FyAmFF4iRmx {
  fill: #00ffda;
}
#icon-custom_el_Dd0BHdRYwZp {
  fill: #8200ff;
}
#icon-custom_el_tC_MeFbqPgS {
  fill: #8200ff;
}
#icon-custom_el_ZROG649Ye_3 {
  fill: #8200ff;
}
#icon-custom_el_gc-vGUA92SQ {
  fill: #8200ff;
}
#icon-custom_el_dUn-y4_Xkhv {
  fill: #8200ff;
}
#icon-custom_el_ydg3SBpPp0k {
  fill: #00ffda;
}
#icon-custom_el_oPUxjUKbzhJ {
  fill: #8200ff;
}
#icon-custom_el_ScrBm2MStp6 {
  fill: #8200ff;
}
#icon-custom_el_FKXAXr7jxyh {
  fill: #8200ff;
}
#icon-custom_el_AXOCoMK4BZG_88BIRxieb {
  -webkit-transform: translate(28.45px, 23.54px) rotate(-360deg)
    translate(-28.45px, -23.54px);
  transform: translate(28.45px, 23.54px) rotate(-360deg)
    translate(-28.45px, -23.54px);
}
.svgHover:hover #icon-custom_el_AXOCoMK4BZG_88BIRxieb {
  -webkit-animation-name: el_AXOCoMK4BZG_88BIRxieb_Animation;
  animation-name: el_AXOCoMK4BZG_88BIRxieb_Animation;
}
</style>
<style>
@-webkit-keyframes el_4PIThnNp9CA_Animation {
  0% {
    opacity: 1;
  }
  30% {
    opacity: 0;
  }
  60% {
    opacity: 1;
  }
  90% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@keyframes el_4PIThnNp9CA_Animation {
  0% {
    opacity: 1;
  }
  30% {
    opacity: 0;
  }
  60% {
    opacity: 1;
  }
  90% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@-webkit-keyframes el_3YxAetsNTJX_Animation {
  10% {
    opacity: 1;
  }
  50% {
    opacity: 0;
  }
  90% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@keyframes el_3YxAetsNTJX_Animation {
  10% {
    opacity: 1;
  }
  50% {
    opacity: 0;
  }
  90% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
.svgHover * {
  -webkit-animation-duration: 1s;
  animation-duration: 1s;
  -webkit-animation-play-state: running;
  animation-play-state: running;
  -webkit-animation-timing-function: cubic-bezier(0, 0, 1, 1);
  animation-timing-function: cubic-bezier(0, 0, 1, 1);
}
#icon-eco_el_x9l3tIw1iy {
  display: none;
}
#icon-eco_el_dib9fi8zkh {
  display: inline;
}
#icon-eco_el_3lE5s5rA1y {
  fill: #8200ff;
}
#icon-eco_el_jR7ESh7qmN {
  fill: #00ffda;
}
#icon-eco_el_xK1z5oVPkB {
  fill: #00ffda;
}
#icon-eco_el_TIFzHA9Llq {
  display: none;
}
#icon-eco_el_TzNYRBw7f- {
  display: inline;
}
#icon-eco_el_47ltmGzkYO {
  fill: #8200ff;
}
#icon-eco_el_HPmS5Q73Oc {
  fill: #00ffda;
}
#icon-eco_el__PogajmPHLK {
  fill: #8200ff;
}
#icon-eco_el_wGPIITt-9wa {
  fill: #00ffda;
}
#icon-eco_el_vDcRPZ6bGmZ {
  fill: #00ffda;
}
#icon-eco_el_gOanEykLTM0 {
  fill: #00ffda;
}
#icon-eco_el_nSkf78K0E5e {
  fill: #8200ff;
}
#icon-eco_el_CMGvo896xZn {
  fill: #8200ff;
}
#icon-eco_el_CpCQnDyvyrt {
  fill: #8200ff;
}
#icon-eco_el_XxxX4s_7D2J {
  display: none;
}
#icon-eco_el_XdJkNml2sbs {
  display: inline;
}
#icon-eco_el_nCdU31z2ROV {
  fill: #8200ff;
}
#icon-eco_el_ZuVe7l52m1d {
  fill: #00ffda;
}
#icon-eco_el_uk8TN5TOKLH {
  display: none;
}
#icon-eco_el_ubcIbhnNVZ5 {
  display: inline;
}
#icon-eco_el_X4gGFMlAEkn {
  fill: #00ffda;
}
#icon-eco_el_mop3fvZ6H73 {
  fill: #8200ff;
}
#icon-eco_el_HqL4t07JeQJ {
  fill: #8200ff;
}
#icon-eco_el_Y_mQey69iQu {
  fill: #8200ff;
}
#icon-eco_el_UJ6MFnMA4RW {
  fill: #8200ff;
}
#icon-eco_el_p-OxgVdLGeI {
  fill: #8200ff;
}
#icon-eco_el_k1EQHuWl8OS {
  fill: #8200ff;
}
#icon-eco_el_vIxIpR4zneV {
  fill: #8200ff;
}
#icon-eco_el_8RFUhGcm3N5 {
  fill: #00ffda;
}
#icon-eco_el_xe3V0Y-woxK {
  fill: #00ffda;
}
#icon-eco_el_91xhwDyBCwZ {
  fill: #00ffda;
}
#icon-eco_el_t_0PZVhc9nw {
  fill: #00ffda;
}
#icon-eco_el_Lwq2t4OeuGJ {
  fill: #00ffda;
}
#icon-eco_el_JG6YkfnWUjC {
  fill: #8200ff;
}
#icon-eco_el_khakNLuoRb0 {
  fill: #8200ff;
}
#icon-eco_el_ctjGx04ZOcm {
  fill: #8200ff;
}
#icon-eco_el_LFVHZP2pbhK {
  fill: #8200ff;
}
#icon-eco_el_3wGpsg6bk90 {
  fill: #8200ff;
}
#icon-eco_el_XaPLc40y51o {
  fill: #8200ff;
}
#icon-eco_el_sVZRT_uEWZL {
  fill: #8200ff;
}
#icon-eco_el_FlTJWWBqlFo {
  fill: #8200ff;
}
#icon-eco_el_TkIykQaWgQZ {
  fill: #8200ff;
}
#icon-eco_el_ovszXpIln9Y {
  fill: #8200ff;
}
#icon-eco_el_k9xEtW6TeRA {
  fill: #8200ff;
}
#icon-eco_el_3MBmRyMh8YK {
  fill: #8200ff;
}
#icon-eco_el_PVmEMxy4ELN {
  fill: #8200ff;
}
#icon-eco_el_w0Cv2AlD8RT {
  fill: #8200ff;
}
#icon-eco_el_hCP_PqDC6i6 {
  fill: #8200ff;
}
#icon-eco_el_pO0dKg2wdFg {
  fill: #8200ff;
}
#icon-eco_el_nNO0me2tkfp {
  fill: #8200ff;
}
#icon-eco_el_loG8pLUuhAK {
  fill: #8200ff;
}
#icon-eco_el_B6jbzGk2umI {
  fill: #8200ff;
}
#icon-eco_el_RL8WWuFB6wQ {
  fill: #8200ff;
}
#icon-eco_el_3YxAetsNTJX {
  opacity: 1;
}
.svgHover:hover #icon-eco_el_3YxAetsNTJX {
  -webkit-animation-name: el_3YxAetsNTJX_Animation;
  animation-name: el_3YxAetsNTJX_Animation;
}
#icon-eco_el_4PIThnNp9CA {
  opacity: 1;
}
.svgHover:hover #icon-eco_el_4PIThnNp9CA {
  -webkit-animation-name: el_4PIThnNp9CA_Animation;
  animation-name: el_4PIThnNp9CA_Animation;
}
</style>
<style>
@-webkit-keyframes el_LAoB5Vn5Xe_Animation {
  10% {
    opacity: 1;
  }
  60% {
    opacity: 0;
  }
  80% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@keyframes el_LAoB5Vn5Xe_Animation {
  10% {
    opacity: 1;
  }
  60% {
    opacity: 0;
  }
  80% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@-webkit-keyframes el_r6-rEYLJ94_Animation {
  10% {
    opacity: 1;
  }
  60% {
    opacity: 0;
  }
  80% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@keyframes el_r6-rEYLJ94_Animation {
  10% {
    opacity: 1;
  }
  60% {
    opacity: 0;
  }
  80% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@-webkit-keyframes el_2wOLZwDZkS_Animation {
  10% {
    opacity: 1;
  }
  60% {
    opacity: 0;
  }
  80% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@keyframes el_2wOLZwDZkS_Animation {
  10% {
    opacity: 1;
  }
  60% {
    opacity: 0;
  }
  80% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@-webkit-keyframes el_EHreB5gjp6_Animation {
  10% {
    opacity: 1;
  }
  40% {
    opacity: 0;
  }
  60% {
    opacity: 0;
  }
  80% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@keyframes el_EHreB5gjp6_Animation {
  10% {
    opacity: 1;
  }
  40% {
    opacity: 0;
  }
  60% {
    opacity: 0;
  }
  80% {
    opacity: 1;
  }
  0% {
    opacity: 1;
  }
  100% {
    opacity: 1;
  }
}
@-webkit-keyframes el_LAoB5Vn5Xe_fRposm_7o_Animation {
  10% {
    -webkit-transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(0px, 0px);
    transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(0px, 0px);
  }
  40% {
    -webkit-transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(50px, 0px);
    transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(50px, 0px);
  }
  60% {
    -webkit-transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(-50px, 0px);
    transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(-50px, 0px);
  }
  80% {
    -webkit-transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(0px, 0px);
    transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(0px, 0px);
  }
  0% {
    -webkit-transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(0px, 0px);
    transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(0px, 0px);
  }
  100% {
    -webkit-transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(0px, 0px);
    transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(0px, 0px);
  }
}
@keyframes el_LAoB5Vn5Xe_fRposm_7o_Animation {
  10% {
    -webkit-transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(0px, 0px);
    transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(0px, 0px);
  }
  40% {
    -webkit-transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(50px, 0px);
    transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(50px, 0px);
  }
  60% {
    -webkit-transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(-50px, 0px);
    transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(-50px, 0px);
  }
  80% {
    -webkit-transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(0px, 0px);
    transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(0px, 0px);
  }
  0% {
    -webkit-transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(0px, 0px);
    transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(0px, 0px);
  }
  100% {
    -webkit-transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(0px, 0px);
    transform: translate(14.04px, 21px) translate(-14.04px, -21px)
      translate(0px, 0px);
  }
}
@-webkit-keyframes el_r6-rEYLJ94_Vwy-Z-1zv_Animation {
  10% {
    -webkit-transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(0px, 0px);
    transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(0px, 0px);
  }
  40% {
    -webkit-transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(50px, 0px);
    transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(50px, 0px);
  }
  60% {
    -webkit-transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(-50px, -50px);
    transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(-50px, -50px);
  }
  80% {
    -webkit-transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(0px, 0px);
    transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(0px, 0px);
  }
  0% {
    -webkit-transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(0px, 0px);
    transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(0px, 0px);
  }
  100% {
    -webkit-transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(0px, 0px);
    transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(0px, 0px);
  }
}
@keyframes el_r6-rEYLJ94_Vwy-Z-1zv_Animation {
  10% {
    -webkit-transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(0px, 0px);
    transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(0px, 0px);
  }
  40% {
    -webkit-transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(50px, 0px);
    transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(50px, 0px);
  }
  60% {
    -webkit-transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(-50px, -50px);
    transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(-50px, -50px);
  }
  80% {
    -webkit-transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(0px, 0px);
    transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(0px, 0px);
  }
  0% {
    -webkit-transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(0px, 0px);
    transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(0px, 0px);
  }
  100% {
    -webkit-transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(0px, 0px);
    transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
      translate(0px, 0px);
  }
}
@-webkit-keyframes el_2wOLZwDZkS_8Xm-vEExA_Animation {
  10% {
    -webkit-transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(0px, 0px);
    transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(0px, 0px);
  }
  40% {
    -webkit-transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(50px, 0px);
    transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(50px, 0px);
  }
  60% {
    -webkit-transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(-50px, 0px);
    transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(-50px, 0px);
  }
  80% {
    -webkit-transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(0px, 0px);
    transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(0px, 0px);
  }
  0% {
    -webkit-transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(0px, 0px);
    transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(0px, 0px);
  }
  100% {
    -webkit-transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(0px, 0px);
    transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(0px, 0px);
  }
}
@keyframes el_2wOLZwDZkS_8Xm-vEExA_Animation {
  10% {
    -webkit-transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(0px, 0px);
    transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(0px, 0px);
  }
  40% {
    -webkit-transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(50px, 0px);
    transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(50px, 0px);
  }
  60% {
    -webkit-transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(-50px, 0px);
    transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(-50px, 0px);
  }
  80% {
    -webkit-transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(0px, 0px);
    transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(0px, 0px);
  }
  0% {
    -webkit-transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(0px, 0px);
    transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(0px, 0px);
  }
  100% {
    -webkit-transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(0px, 0px);
    transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
      translate(0px, 0px);
  }
}
@-webkit-keyframes el_EHreB5gjp6_ea6Pnd1ln_Animation {
  10% {
    -webkit-transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(0px, 0px);
    transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(0px, 0px);
  }
  30% {
    -webkit-transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(50px, 0px);
    transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(50px, 0px);
  }
  60% {
    -webkit-transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(-50px, 0px);
    transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(-50px, 0px);
  }
  80% {
    -webkit-transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(0px, 0px);
    transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(0px, 0px);
  }
  0% {
    -webkit-transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(0px, 0px);
    transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(0px, 0px);
  }
  100% {
    -webkit-transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(0px, 0px);
    transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(0px, 0px);
  }
}
@keyframes el_EHreB5gjp6_ea6Pnd1ln_Animation {
  10% {
    -webkit-transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(0px, 0px);
    transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(0px, 0px);
  }
  30% {
    -webkit-transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(50px, 0px);
    transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(50px, 0px);
  }
  60% {
    -webkit-transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(-50px, 0px);
    transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(-50px, 0px);
  }
  80% {
    -webkit-transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(0px, 0px);
    transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(0px, 0px);
  }
  0% {
    -webkit-transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(0px, 0px);
    transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(0px, 0px);
  }
  100% {
    -webkit-transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(0px, 0px);
    transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
      translate(0px, 0px);
  }
}
.btn-video * {
  -webkit-animation-duration: 1s;
  animation-duration: 1s;
  -webkit-animation-play-state: running;
  animation-play-state: running;
  -webkit-animation-timing-function: cubic-bezier(0, 0, 1, 1);
  animation-timing-function: cubic-bezier(0, 0, 1, 1);
}
#icon-video_el_Jad_8B4mL2 {
  fill: none;
  stroke: #01ffde;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-miterlimit: 10;
}
#icon-video_el_EHreB5gjp6 {
  fill: #01ffde;
  opacity: 1;
}
.btn-video:hover #icon-video_el_EHreB5gjp6 {
  -webkit-animation-name: el_EHreB5gjp6_Animation;
  animation-name: el_EHreB5gjp6_Animation;
}
#icon-video_el_2wOLZwDZkS {
  fill: none;
  stroke: #01ffde;
  stroke-width: 1.732;
  stroke-linecap: round;
  stroke-miterlimit: 10;
  opacity: 1;
}
.btn-video:hover #icon-video_el_2wOLZwDZkS {
  -webkit-animation-name: el_2wOLZwDZkS_Animation;
  animation-name: el_2wOLZwDZkS_Animation;
}
#icon-video_el_r6-rEYLJ94 {
  fill: none;
  stroke: #01ffde;
  stroke-width: 1.732;
  stroke-linecap: round;
  stroke-miterlimit: 10;
  opacity: 1;
}
.btn-video:hover #icon-video_el_r6-rEYLJ94 {
  -webkit-animation-name: el_r6-rEYLJ94_Animation;
  animation-name: el_r6-rEYLJ94_Animation;
}
#icon-video_el_LAoB5Vn5Xe {
  fill: none;
  stroke: #01ffde;
  stroke-width: 1.732;
  stroke-linecap: round;
  stroke-miterlimit: 10;
  opacity: 1;
}
.btn-video:hover #icon-video_el_LAoB5Vn5Xe {
  -webkit-animation-name: el_LAoB5Vn5Xe_Animation;
  animation-name: el_LAoB5Vn5Xe_Animation;
}
#icon-video_el_EHreB5gjp6_ea6Pnd1ln {
  -webkit-transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
    translate(0px, 0px);
  transform: translate(19.67px, 7.75px) translate(-19.67px, -7.75px)
    translate(0px, 0px);
}
.btn-video:hover #icon-video_el_EHreB5gjp6_ea6Pnd1ln {
  -webkit-animation-name: el_EHreB5gjp6_ea6Pnd1ln_Animation;
  animation-name: el_EHreB5gjp6_ea6Pnd1ln_Animation;
}
#icon-video_el_2wOLZwDZkS_8Xm-vEExA {
  -webkit-transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
    translate(0px, 0px);
  transform: translate(14.04px, 8.6px) translate(-14.04px, -8.6px)
    translate(0px, 0px);
}
.btn-video:hover #icon-video_el_2wOLZwDZkS_8Xm-vEExA {
  -webkit-animation-name: el_2wOLZwDZkS_8Xm-vEExA_Animation;
  animation-name: el_2wOLZwDZkS_8Xm-vEExA_Animation;
}
#icon-video_el_r6-rEYLJ94_Vwy-Z-1zv {
  -webkit-transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
    translate(0px, 0px);
  transform: translate(11.74px, 14.83px) translate(-11.74px, -14.83px)
    translate(0px, 0px);
}
.btn-video:hover #icon-video_el_r6-rEYLJ94_Vwy-Z-1zv {
  -webkit-animation-name: el_r6-rEYLJ94_Vwy-Z-1zv_Animation;
  animation-name: el_r6-rEYLJ94_Vwy-Z-1zv_Animation;
}
#icon-video_el_LAoB5Vn5Xe_fRposm_7o {
  -webkit-transform: translate(14.04px, 21px) translate(-14.04px, -21px)
    translate(0px, 0px);
  transform: translate(14.04px, 21px) translate(-14.04px, -21px)
    translate(0px, 0px);
}
.btn-video:hover #icon-video_el_LAoB5Vn5Xe_fRposm_7o {
  -webkit-animation-name: el_LAoB5Vn5Xe_fRposm_7o_Animation;
  animation-name: el_LAoB5Vn5Xe_fRposm_7o_Animation;
}
</style>
<style>
@-webkit-keyframes el_CxOhkiimWCL_OL3zd_hBa_Animation {
  10% {
    -webkit-transform: translate(32px, 32px) rotate(-360deg)
      translate(-32px, -32px);
    transform: translate(32px, 32px) rotate(-360deg) translate(-32px, -32px);
  }
  90% {
    -webkit-transform: translate(32px, 32px) rotate(0deg)
      translate(-32px, -32px);
    transform: translate(32px, 32px) rotate(0deg) translate(-32px, -32px);
  }
  0% {
    -webkit-transform: translate(32px, 32px) rotate(-360deg)
      translate(-32px, -32px);
    transform: translate(32px, 32px) rotate(-360deg) translate(-32px, -32px);
  }
  100% {
    -webkit-transform: translate(32px, 32px) rotate(0deg)
      translate(-32px, -32px);
    transform: translate(32px, 32px) rotate(0deg) translate(-32px, -32px);
  }
}
@keyframes el_CxOhkiimWCL_OL3zd_hBa_Animation {
  10% {
    -webkit-transform: translate(32px, 32px) rotate(-360deg)
      translate(-32px, -32px);
    transform: translate(32px, 32px) rotate(-360deg) translate(-32px, -32px);
  }
  90% {
    -webkit-transform: translate(32px, 32px) rotate(0deg)
      translate(-32px, -32px);
    transform: translate(32px, 32px) rotate(0deg) translate(-32px, -32px);
  }
  0% {
    -webkit-transform: translate(32px, 32px) rotate(-360deg)
      translate(-32px, -32px);
    transform: translate(32px, 32px) rotate(-360deg) translate(-32px, -32px);
  }
  100% {
    -webkit-transform: translate(32px, 32px) rotate(0deg)
      translate(-32px, -32px);
    transform: translate(32px, 32px) rotate(0deg) translate(-32px, -32px);
  }
}
.svgHover * {
  -webkit-animation-duration: 1s;
  animation-duration: 1s;
  -webkit-animation-play-state: running;
  animation-play-state: running;
  -webkit-animation-timing-function: cubic-bezier(0, 0, 1, 1);
  animation-timing-function: cubic-bezier(0, 0, 1, 1);
}
#icon-back_el_ou7BhwwYbn5 {
  fill: #8200ff;
}
#icon-back_el_U-HOdIybnAd {
  fill: #00ffda;
}
#icon-back_el_nl_x5XoJvBo {
  fill: #8200ff;
}
#icon-back_el_CxOhkiimWCL_OL3zd_hBa {
  -webkit-transform: translate(32px, 32px) rotate(-360deg)
    translate(-32px, -32px);
  transform: translate(32px, 32px) rotate(-360deg) translate(-32px, -32px);
}
.svgHover:hover #icon-back_el_CxOhkiimWCL_OL3zd_hBa {
  -webkit-animation-name: el_CxOhkiimWCL_OL3zd_hBa_Animation;
  animation-name: el_CxOhkiimWCL_OL3zd_hBa_Animation;
}
</style>