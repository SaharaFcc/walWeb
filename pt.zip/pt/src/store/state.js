const state = {
    lang: 'CN',
    showSwitch: false,
    sectionIndex: 0,
    commonLink: 'http://www.waltonchain.org/'
}
export default state