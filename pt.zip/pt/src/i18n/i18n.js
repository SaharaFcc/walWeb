import Vue from 'vue'
import VueI18n from 'vue-i18n'
Vue.use(VueI18n)

import cn from './langs/cn'
import en from './langs/en'
import kr from './langs/kr'

const i18n = new VueI18n({
  locale: localStorage.locale || 'cn',
  messages: {
    en: en,
    cn: cn,
    kr: kr
  },
  // 隐藏警告
  silentTranslationWarn: true
})

export default i18n
