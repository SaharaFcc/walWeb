export default {
    home: {
      headerOne: 'WTA',
      headerTwo: '솔루션',
      headerThree: '생태계',
      headerFour: '자료',
      headerFive: '백서',
      headerSix: '커뮤니티',
      headerSeven: 'WTC',
      headerTextOne: '글로벌 블록체인',
      headerTextTwo: '사물인터넷의 리더',
      prevText: '이전 페이지',
      nextText: '다음 페이지',
      aboutText: '월튼체인에 대하여',
      centerText: '경쟁력',
      planText: '프로젝트 계획',
      playText: '파트너십',
      linkText: 'Contact Us'
    },
    tab:{
        backText: '피드백 메일',
        downloadText: '다운로드',
        knowText: '업계 솔루션에 대한 이해가 필요하다면 연락주시기 바랍니다'
    },
    food:{
        monitorText: '자동 모니터링',
        wayText: '양방향 추적',
        chainText: '체인에 데이터 자동 업로드',
        titleOneText: 'WTC-FOOD 시스템',
        titleTwoText: '사례',
        tagOneText: '강력하고 편리한 데이터 수집',
        tagTwoText: '프로세스 정보 추적',
        tagThreeText: '신용안전증명',
        tagFourText: '식품안전보장',
        videoText: '소개 영상 보기',
        paraText: 'WTC-FOOD 시스템은 사물인터넷과 블록체인 기술을 핵심으로 모바일, 클라우드 컴퓨팅, 빅데이터 등의 과학기술과 결합하여 식품안전 생산 및 데이터 유통을 위한 사물인터넷 수집합니다. 데이터는 체인에 자동 업로드되고 글로벌 분포 관리가 가능한 추적 보증 시스템입니다.'
    },
    cloth:{
        storeText: '스마트 매장',
        chainText: '체인에 빅데이터 업로드',
        authText: '고급상품 보장',
        titleOneText: 'WTC-GARMENT 시스템',
        titleTwoText: '사례',
        tagOneText: '스마트 관리 프로세스',
        tagTwoText: '몰입식 쇼핑 체험',
        tagThreeText: '브랜드 가치 보장',
        tagFourText: '다양한 소비자 속성',
        videoText: '소개 영상 보기',
        paraTitleText: '공급 사슬 단계가 복잡하고 원가가 너무 높나요? SKU가 많고 물류창고의 문제를 통제하기 어려운가요?',
        paraContentText: "월튼체인의 세계 최초 블록체인 의류 시스템 'WTC-Garment'는 공급 사슬의 최적화, 창고 물류관리, 소비자 빅데이터 등 의류업계 다양한 영역에 응용되어 의류업계의 문제점들을 해결할 수 있습니다."
    },
    smn:{
        mainTitleText: '월튼체인 글로벌 생태 슈퍼 마스터 노드(SMN) 모집 계획',
        paraOneTitle: '모집 계획 소개',
        paraOneContent: '<p>월튼체인&nbsp;비즈니스&nbsp;생태계를&nbsp;개선하기&nbsp;위해&nbsp;월튼체인&nbsp;기금회는&nbsp;슈퍼&nbsp;마스터&nbsp;노드(Super Master Node, SMN)를&nbsp;모집하여&nbsp;국제커뮤니티의&nbsp;힘을&nbsp;일으키고&nbsp;우수한&nbsp;자체인&nbsp;프로젝트를&nbsp;육성하고자&nbsp;한다.&nbsp;월튼체인의&nbsp;기술&nbsp;발전에&nbsp;맞춰&nbsp;생태계&nbsp;건설은&nbsp;계속&nbsp;진행되고&nbsp;있다.&nbsp;본&nbsp;계획은&nbsp;보상&nbsp;및&nbsp;거버넌스&nbsp;메커니즘을&nbsp;규정하고&nbsp;자체인&nbsp;생태계와&nbsp;체인과&nbsp;체인을&nbsp;연결하는&nbsp;생태계의&nbsp;개방성&nbsp;확장을&nbsp;가속화하며&nbsp;월튼체인의&nbsp;자체인&nbsp;생태계를&nbsp;구축한다.&nbsp;이를&nbsp;통해&nbsp;많은&nbsp;사람들은&nbsp;가치&nbsp;사물인터넷과&nbsp;상용화&nbsp;서비스에&nbsp;관심을&nbsp;갖게&nbsp;되고&nbsp;인류는&nbsp;보다&nbsp;신뢰할&nbsp;수&nbsp;있는&nbsp;디지털&nbsp;생활에&nbsp;진입하게&nbsp;될&nbsp;것이다.</p><p>월튼체인의&nbsp;모체인-자체인&nbsp;형식의&nbsp;다체인&nbsp;구조를&nbsp;통해&nbsp;향후&nbsp;블록체인&nbsp;기술은&nbsp;여러&nbsp;업계에서&nbsp;활용될&nbsp;수&nbsp;있다.&nbsp;각&nbsp;업계의&nbsp;자체인은&nbsp;암호화되어&nbsp;안정적인&nbsp;사물인터넷&nbsp;데이터&nbsp;수집&nbsp;하드웨어&nbsp;설비를&nbsp;이용한다.&nbsp;그리고&nbsp;특정&nbsp;분야의&nbsp;업무&nbsp;로직을&nbsp;깊이&nbsp;융합하고&nbsp;개방되어&nbsp;여러&nbsp;업계도&nbsp;모두&nbsp;포괄할&nbsp;수&nbsp;있는&nbsp;메커니즘을&nbsp;형성한다. SMN&nbsp;노드는&nbsp;전&nbsp;세계&nbsp;자체인&nbsp;생태계의&nbsp;빠른&nbsp;번영을&nbsp;도울&nbsp;것이며&nbsp;업계를 뛰어넘는&nbsp;체인&nbsp;네트워크를&nbsp;형성할&nbsp;것이다.&nbsp;월튼체인의&nbsp;체인&nbsp;간&nbsp;메커니즘은&nbsp;모체인과&nbsp;자체인&nbsp;간에&nbsp;가치와&nbsp;데이터를&nbsp;효율적으로&nbsp;전송하고&nbsp;다체인&nbsp;네트워크를&nbsp;전체로&nbsp;융합하여&nbsp;업계를&nbsp;넘어선&nbsp;커다란&nbsp;블록체인&nbsp;생태계를&nbsp;형성한다. SMN은&nbsp;체인&nbsp;간&nbsp;거래를&nbsp;통해&nbsp;노드를&nbsp;확인하고&nbsp;담보권을&nbsp;기반으로&nbsp;하여&nbsp;체인&nbsp;간&nbsp;거래의&nbsp;효율성을&nbsp;높인다.</p><p>월튼체인&nbsp;기금회는&nbsp;1,000만&nbsp;개의&nbsp;WTC를&nbsp;투자하여&nbsp;‘월튼체인&nbsp;글로벌&nbsp;생태계&nbsp;육성&nbsp;기금 (&nbsp;Waltonchain Global Ecosystem Incubation Fund, WGEIF)’을&nbsp;만들고&nbsp;이를&nbsp;우수한&nbsp;자체인&nbsp;프로젝트&nbsp;육성에&nbsp;사용하고자&nbsp;한다.&nbsp;동시에&nbsp;55만&nbsp;개의&nbsp;WTC를&nbsp;SMN&nbsp;추천인을&nbsp;보상하는데&nbsp;사용한다.&nbsp;기금회는&nbsp;현재&nbsp;월튼체인&nbsp;글로벌&nbsp;노드&nbsp;분포에&nbsp;의거하여&nbsp;아시아&nbsp;30명,&nbsp;미주&nbsp;30명,&nbsp;유럽&nbsp;15명,&nbsp;호주&nbsp;15명,&nbsp;아프리카&nbsp;5명의&nbsp;SMN를&nbsp;모집한다.&nbsp;만일&nbsp;노드&nbsp;분포&nbsp;장소에&nbsp;변화가&nbsp;생기면&nbsp;계획도&nbsp;변경될&nbsp;수&nbsp;있어&nbsp;이는&nbsp;별도&nbsp;서면으로&nbsp;통지할&nbsp;예정이다.</p>',
        paraTwoTitle: '모집 유형',
        paraTwoContent: '<p>커뮤니티&nbsp;사용자&nbsp;-&nbsp;글로벌&nbsp;월튼체인&nbsp;커뮤니티&nbsp;지지자</p><p>기업&nbsp;사용자&nbsp;-&nbsp;월튼체인의&nbsp;새로운&nbsp;비즈니스&nbsp;생태계&nbsp;참여자</p><p>연구개발팀&nbsp;-&nbsp;글로벌&nbsp;월튼체인&nbsp;기술&nbsp;혁신&nbsp;개발자</p><p>학술팀&nbsp;-&nbsp;글로벌&nbsp;월튼체인&nbsp;기술&nbsp;연구원</p><p>투자&nbsp;기관&nbsp;-&nbsp;글로벌&nbsp;월튼체인&nbsp;자본&nbsp;지지자</p>',
        paraThreeTitle: 'SMN 권한 및 기능',
        paraThreeContent: '<p>1.&nbsp;자체인&nbsp;프로젝트&nbsp;우선&nbsp;추천권.&nbsp;자체인&nbsp;프로젝트를&nbsp;추천하고&nbsp;육성하면&nbsp;그에&nbsp;상응한&nbsp;보상을&nbsp;받는다.</p><p>2.&nbsp;자체인&nbsp;프로젝트&nbsp;투표권. ‘월튼체인&nbsp;글로벌&nbsp;생태계&nbsp;육성기금’이&nbsp;자체인&nbsp;프로젝트&nbsp;육성&nbsp;여부를&nbsp;결정할&nbsp;때&nbsp;모든&nbsp;SMN는&nbsp;육성&nbsp;제안서에&nbsp;투표할&nbsp;권리를&nbsp;얻는다.&nbsp;찬성투표수가&nbsp;유효&nbsp;투표&nbsp;수의&nbsp;3분의&nbsp;1&nbsp;이상이면&nbsp;통과한&nbsp;것으로&nbsp;간주한다. SMN&nbsp;결정투표는&nbsp;노드&nbsp;한&nbsp;개&nbsp;당&nbsp;한&nbsp;개의&nbsp;투표권을&nbsp;받게&nbsp;되고&nbsp;투표를&nbsp;포기하거나&nbsp;기간을&nbsp;넘긴&nbsp;경우에는&nbsp;기권표로&nbsp;간주한다.</p><p>3.&nbsp;교차체인&nbsp;거래를&nbsp;통해&nbsp;노드를&nbsp;확인하고&nbsp;교차체인&nbsp;거래의&nbsp;안전하고&nbsp;효율적인&nbsp;작동을&nbsp;보장한다.</p>',
        paraFourTitle: 'SMN 인증 자격',
        paraFourContent: '<p>1.10만&nbsp;개&nbsp;이상의&nbsp;WTC&nbsp;보유자.&nbsp;토큰&nbsp;스왑&nbsp;전에&nbsp;이더리움&nbsp;주소에&nbsp;보관해&nbsp;두고&nbsp;스왑&nbsp;후에는&nbsp;월튼&nbsp;지갑&nbsp;주소에&nbsp;저장한다.</p><p>2.&nbsp;5만&nbsp;개&nbsp;이상의&nbsp;WTC를&nbsp;보유하고&nbsp;있는&nbsp;신청자는&nbsp;BTC/ETH를&nbsp;사용하여&nbsp;WTC가&nbsp;유통되지&nbsp;않은&nbsp;부분에&nbsp;대해&nbsp;신청일의&nbsp;바이낸스&nbsp;거래소에서&nbsp;WTC/BTC, WTC/ETH MA20(처음&nbsp;20일간의&nbsp;균일가, UTC+8)&nbsp;가격으로&nbsp;WTC를&nbsp;구매할&nbsp;수&nbsp;있다. GMN은&nbsp;5%&nbsp;할인&nbsp;받을&nbsp;수&nbsp;있다.&nbsp;구매를&nbsp;원하는&nbsp;경우&nbsp;월튼체인의&nbsp;공식&nbsp;웹&nbsp;사이트&nbsp;내&nbsp;링크를&nbsp;통해&nbsp;신청서를&nbsp;제출해야&nbsp;한다.</p><p>3. SMN&nbsp;인증&nbsp;성공&nbsp;후&nbsp;SMN은&nbsp;10만&nbsp;WTC를&nbsp;계속&nbsp;가지고&nbsp;있어야&nbsp;하고&nbsp;WTC가&nbsp;10만&nbsp;개&nbsp;미만인&nbsp;경우에는&nbsp;자동으로&nbsp;SMN&nbsp;자격을&nbsp;포기한&nbsp;것으로&nbsp;간주한다.</p>',
        paraFiveTitle: 'SMN 보상 메커니즘과 배포',
        paraFiveContent: '<p style="color:#8200ff;">SMN&nbsp;보상&nbsp;배포</p><p>1.&nbsp;월튼체인&nbsp;기금회는&nbsp;1,000만&nbsp;개&nbsp;WTC를&nbsp;투자하여&nbsp;‘월튼체인&nbsp;글로벌&nbsp;생태계&nbsp;육성&nbsp;기금’을&nbsp;설립했고&nbsp;전&nbsp;세계&nbsp;우수한&nbsp;자체인&nbsp;프로젝트&nbsp;50개를&nbsp;육성하는데&nbsp;사용할&nbsp;것이다.&nbsp;자체인&nbsp;프로젝트는&nbsp;WTC&nbsp;투자만&nbsp;받을&nbsp;수&nbsp;있다.</p><p>2.&nbsp;각&nbsp;자체인&nbsp;프로젝트는&nbsp;육성&nbsp;요구&nbsp;및&nbsp;제휴&nbsp;범위에&nbsp;따라&nbsp;자체인&nbsp;토큰을&nbsp;프로젝트&nbsp;개발을&nbsp;위해&nbsp;최대&nbsp;10&nbsp;만개의&nbsp;WTC로&nbsp;교환할&nbsp;수&nbsp;있다.&nbsp;각&nbsp;자체인&nbsp;프로젝트의&nbsp;투자&nbsp;금액은&nbsp;SMN&nbsp;투표&nbsp;상황에&nbsp;따라&nbsp;결정되며&nbsp;세부&nbsp;사항은&nbsp;서면으로&nbsp;통지한다.</p><p>3.&nbsp;월튼체인&nbsp;기금회는&nbsp;SMN&nbsp;추천인에게&nbsp;보상으로&nbsp;55만&nbsp;개의&nbsp;WTC를&nbsp;지급한다.</p><p style="color:#8200ff;">SMN&nbsp;보상&nbsp;메커니즘</p><p>1. SMN이&nbsp;자체인&nbsp;프로젝트를&nbsp;성공적으로&nbsp;추천하게&nbsp;되면&nbsp;월튼체인&nbsp;글로벌&nbsp;생태계&nbsp;육성&nbsp;기금회는&nbsp;투자를&nbsp;통해&nbsp;최고&nbsp;10만&nbsp;개의&nbsp;자체인&nbsp;토큰을&nbsp;얻게&nbsp;되는데&nbsp;이&nbsp;토큰은&nbsp;다음과&nbsp;같은&nbsp;용도로&nbsp;사용된다.</p><p>5%는&nbsp;온라인으로&nbsp;에어드랍한다.</p><p>30%는&nbsp;SMN&nbsp;보상에&nbsp;사용된다. (그중&nbsp;10 %는&nbsp;추천&nbsp;프로젝트의&nbsp;SMN이&nbsp;우선적으로&nbsp;받으며&nbsp;나머지&nbsp;20 %는&nbsp;모든&nbsp;SMN들이&nbsp;균등하게&nbsp;나눠&nbsp;받는다.)</p><p>65%는&nbsp;월튼체인의&nbsp;생태계&nbsp;건설에&nbsp;사용된다.</p><p>2.&nbsp;매년&nbsp;누적&nbsp;추천&nbsp;자체인&nbsp;수가&nbsp;가장&nbsp;많은&nbsp;SMN은(최소&nbsp;5개&nbsp;이상&nbsp;추천) ‘월튼체인&nbsp;글로벌&nbsp;생태계&nbsp;육성&nbsp;기금’에서&nbsp;500만&nbsp;달러에&nbsp;해당하는&nbsp;자체인&nbsp;토큰을&nbsp;받는다.</p><p>3.&nbsp;무료로&nbsp;월튼체인&nbsp;정상회담,&nbsp;연례&nbsp;행사&nbsp;등에&nbsp;참가할&nbsp;자격을&nbsp;얻는다.</p><p>4. 제2기&nbsp;월튼체인&nbsp;기금회의&nbsp;이사로&nbsp;지명될&nbsp;자격을&nbsp;얻는다.</p><p>5.&nbsp;한국&nbsp;월튼체인연구교육원의&nbsp;학습&nbsp;자격을&nbsp;얻는다.</p><p>6.&nbsp;월튼체인&nbsp;관련&nbsp;제품의&nbsp;판매&nbsp;대행&nbsp;권한을&nbsp;받는다.</p><p style="color:#8200ff;">SMN&nbsp;추천인&nbsp;보상&nbsp;메커니즘</p><p>1. SMN을&nbsp;성공적으로&nbsp;추천한&nbsp;SMN&nbsp;추천인은&nbsp;한&nbsp;명당&nbsp;2,600 WTC를&nbsp;받을&nbsp;수&nbsp;있고&nbsp;다른&nbsp;사람이&nbsp;다른&nbsp;SMN을&nbsp;성공적으로&nbsp;추천하면&nbsp;이&nbsp;SMN&nbsp;추천인은&nbsp;60 WTC를&nbsp;추가로&nbsp;받는다.</p><p>2.&nbsp;누적&nbsp;추천&nbsp;SMN(최소&nbsp;5명&nbsp;이상&nbsp;추천)이&nbsp;제일&nbsp;많은&nbsp;SMN&nbsp;추천인은&nbsp;‘월튼체인&nbsp;글로벌&nbsp;생태계&nbsp;육성&nbsp;기금’에서&nbsp;100만&nbsp;달러에&nbsp;해당하는&nbsp;자체인&nbsp;토큰을&nbsp;받을&nbsp;수&nbsp;있다.</p><p>3. SMN&nbsp;추천인이&nbsp;없는&nbsp;경우&nbsp;SMN&nbsp;본인이나&nbsp;기관이&nbsp;보상을&nbsp;받는다.</p><p>4.&nbsp;무료로&nbsp;월튼체인&nbsp;정상회담,&nbsp;연례&nbsp;행사&nbsp;등에&nbsp;참가할&nbsp;자격을&nbsp;얻는다.</p><p>5.&nbsp;한국&nbsp;월튼체인연구교육원의&nbsp;학습&nbsp;자격을&nbsp;얻는다.</p><p>6.&nbsp;월튼체인&nbsp;관련&nbsp;제품의&nbsp;판매&nbsp;대행&nbsp;권한을&nbsp;받는다.</p><p><br></p><p>*&nbsp;주의&nbsp;:&nbsp;SMN&nbsp;추천인은&nbsp;월튼체인에&nbsp;SMN&nbsp;유저&nbsp;추천에&nbsp;성공한&nbsp;사람을&nbsp;뜻한다.</p><p><img style="max-width:100%" src="http://www.waltonchain.org/kr/wed/kr/Uploads/2018-12-19/5c19fa41bbf92.jpg" alt="" width="1080" height="720" title="" align=""> </p>'
    },
    childChain:{
        paraOneTitle: '자체인 소개',
        paraOneContent: '<p>월튼체인은 모-자체인 기반의 체인간 비즈니스 생태계에서 자체인간의 데이터 유통과 가치 전달을 구현합니다.&nbsp;<br>일반적으로 블록체인-사물인터넷 생태계의 데이터는 단일 생태계입니다. 각 생태계는 분리되어 있어 자체적으로 자기만의 데이터 생태계나 블록체인 구조를 구축합니다. 심지어 각 구조마다 다른 기술 체계를 사용하기도 합니다.&nbsp;<br>월튼체인의 가장 중요한 임무는 데이터를 연결하는 것입니다. 월튼체인의 생태계에서 모-자체인 형식의 다체인 구조는 블록체인 기술 업계의 발전 추세입니다. 새로운 업종의 자체인은 암호화된 안전한 사물인터넷 데이터를 이용하여 하드웨어 장비를 수집합니다. 그리고 특정 업계의 로직과 깊이 융합하여 개방식 확장 메커니즘을 형성합니다. 월튼체인은 전 세계에서 50개의 우수한 자체인 프로젝트를 육성하여 거대한 크로스 체인 생태계를 형성하고자 합니다.</p>'
    },
    whitePaper:{
        mainTitleText: '월튼체인을 논할 때 어떤 얘기들이 나올까요?',
        paraOneTitle: '월튼체인 백서 2.0',
        paraOneContent: '<p>2018년 9월 4일, 월튼체인이 백서 2.0을 발표했습니다. 백서에는 월튼체인의 비즈니스 생태계 작업 진행 상황을 단계적으로 정리하고 미래 비전과 시스템 건설을 분석한 내용이 안내되어 있습니다. 또한 합의 메커니즘 ‘WPoC(Waltonchain&nbsp;Proof of Contribution)’와 ‘체인 그룹’에 대해서도 확인할 수 있습니다.</p><p>월튼체인은 신뢰할 수 있는 메커니즘 속에서 효율적인 생활을 실현하기 위해 노력할 것입니다. 그래서 저희는 여러분들과 함께 백서를 연구해 더 많은 지혜로 더 많은 가능성을 발견하고자 합니다.</p>',
        btnText: '백서',
        paraTwoTitle: '백서보기',
        bookOneName: '한국어',
        bookTwoName: '영어',
        bookThreeName: '중국어(간체)',
        bookFourName: '중국어(번체)',
        bookTimeText: '갱신일자 2018.10.17',
        videoText: '소개 동영상 보기'
    },
    exchange:{
        paraOneText: '2017년 8월 월튼체인이 바이낸스에 상장한 이래로 전 세계 30+개의 플랫폼에서 WTC를 거래할 수 있습니다:',
        paraTwoText: 'WTC 메인넷 지원 플랫폼:',
        paraThreeText: 'ERC-20 WTC 메인넷 토큰스왑 플랫폼:'
    },
    sectionOne: {
        titleText: '<h3 style="letter-spacing: 2px;margin-bottom: 40px;">인류를 신뢰할 수 있는 디지털 생활로 <br>이끌어나갈 월튼체인</h3>',
        contentText: '<p style="margin-bottom: 70px;">블록체인과 사물인터넷을 결합한 가치사물인터넷의 생태계. 월튼체인은 블록체인 기술을 통해 인류를&nbsp;신뢰할&nbsp;수&nbsp;있는&nbsp;디지털&nbsp;생활로 이끌고 정보화 시대 사물인터넷 데이터와 서비스의 합의, 공치(共治), 공유, 연동을 실현하고자 한다.</p>',
        videoText: '소개 영상 보기'
    },
    sectionTwo: {
        tabTextOne: '다양한 분야의 응용',
        tabTextTwo: '소프트웨어와 하드웨어의 결합',
        tabTextThree: '크로스 체인 기술',
        expandText: '더보기',
        contentOneTitle: '<h3 style="font-size:24px;font-weight:bold;margin-bottom:30px;line-height:36px">현재 월튼체인은 이미 의류, 식품, 소장품, 물류 등의 분야에서 기술을 상용화하고 있다.</h3>',
        contentOneText: '월튼체인의 블록체인 기술과 RFID 하드웨어 시스템을 기반으로 구축된 의류 추적 시스템은 RFID 태그, RFID 스마트 리더기, 의류 자체인, 체인간 노드, 데이터 검증 플랫폼을 포함한다. 이 시스템은 생산, 물류, 보관, 판매 등의 단계에서 발생되는 데이터를 유통하고 데이터의 진위 여부를 확인할 수 있을 뿐만 아니라 각 의류를 추적할 수 있어 프로세스를 단순화하고 기업 비용을 줄이며 소비자 이익을 보장할 수 있다. 또한 소비자는 편리하게 구매한 의류의 신뢰성과 품질을 확인할 수 있다. 그중 KALTENDIN 생산, 창고 보관, 점포 시스템은 KALTENDIN 그룹이 RFID IoT 기술 및 블록체인 기술을 결합해 개발한 의류 산업 정보화 관리 시스템이다. RFID 태그를 사용해 상품 정보를 신속히 판독할 수 있고 블록체인 기술과 결합해 추적 정보를 체인에 업로드하여 위변조가 불가능하다. 월튼체인은 블록체인 기술 및 관련 하드웨어 장치를 기반으로 비디오 캡처 장비, 센서기, 스마트 단말, 식품 추적 자체인, 체인간 노드 및 데이터 검사 시스템 플랫폼을 포함한 식품 추적 시스템을 구축한다. 시스템이 정해지면 데이터는 스마트 단말 장치를 통해 자동으로 체인에 업로드되는데 수정은 불가능하다. 그리고 소비자는 시스템 플랫폼을 통해 관련 데이터를 확인할 수 있다. SI 양방향 추적 마케팅 플랫폼은 식품업계를 위해 개발한 전통 추적 시스템이다. 블록체인 기술 발전에 따라 Skynovo와 월튼체인은 추적 플랫폼을 블록체인+로 개조했고 위조를 방지하기 위해 추적 플랫폼에 있는 추적 정보를 체인에 업로드한다.월튼체인이 진행한 서비스 목록 : skynovo, huodull, KALTENDIN, fashion net, 브라질 PRODUTORAGRO, 브라질 Yandeh, 뉴질랜드 VOLCITY WINE, 뉴질랜드 MitoQ, 미국 Global eSolutions Group 등',
        contentTwoTitle: '<h3 style="font-size:24px;font-weight:bold;margin-bottom:30px;line-height:36px">월튼체인은 블록체인과 RFID 기술을 완벽하게 결합하기 때문에 <br>데이터의 출처를 신뢰할 수 있다.</h3>',
        contentTwoText: '<p style="line-height:22px;margin-bottom:30px;">사물인터넷 생태 네트워크 구축을 위한 데이터 처리를 위해 월튼체인이 해야 할 두 가지 일이 있다. 하나는 데이터 신뢰성 보장, 또 하나는 데이터 가치 유통이다. 월튼체인은 자체적으로 스마트 RFID 리더기를 개발해 데이터를 자동으로 수집, 처리하고 체인에 업로드할 수 있다. 동시에 지적재산권을 보유한 스마트 데이터 수집장치를 개발했는데 각종 센서 데이터, 오디오 및 비디오 데이터, 위치 정보 데이터 등을 자동으로 수집, 처리하고 체인에 업로드할 수 있다. 현재 대부분의 블록체인들은 하드웨어 없이 소프트웨어 솔루션만을 채택한다. 블록체인 기술이 데이터 변조 불가, 공개성과 투명성을 보장할 수는 있지만 현재 응용 솔루션은 하드웨어의 지원 없이 데이터의 진실성을 보장할 수 없다. 월튼체인의 특징은 블록체인 하드웨어 시스템을 실현하고 데이터의 진실성을 확보한다는 점이다. 일반적으로 블록체인-사물인터넷 생태계의 데이터는 단일 생태계이다. 각 생태계는 분리되어 있어 자체적으로 자기만의 데이터 생태계나 블록체인 구조를 구축한다. 심지어 각 구조마다 다른 기술 체계를 사용하기도 한다. 월튼체인의 주요 임무는 데이터를 연결하는 것이다. 월튼체인은 서로 다른 블록체인(자체인) 간의 데이터 순환, 검증 및 저장을 위해 소프트웨어와 하드웨어를 결합하고 맞춤형 데이터 모델, 체인 간 기술 및 월튼체인 WPoC 합의 메커니즘을 사용한다. 이러한 방식으로 월튼체인은 서로 다른 데이터를 연결할 수 있고 광범위한 데이터 흐름을 구현할 수 있다. 월튼체인은 사물인터넷 분야에서 신뢰할 수 있고 확장 및 이식이 가능한 데이터 가치 블록체인 생태계를 구축하기 위해 힘쓰고 있으며 데이터 장비 제조, 데이터 통신 연구 및 개발, 데이터 서비스를 통합하는 서비스 공급자가 되기 위해 노력하고 있다.</p>',
        contentThreeTitle: '<h3 style="font-size:24px;font-weight:bold;margin-bottom:30px;line-height:36px">월튼체인은 체인을 넘어선 생태계이기 때문에 다른 체인의 데이터를 공유할 수 있고 빠른 검색이 가능하다. </h3>',
        contentThreeText: '<p style="line-height:22px;margin-bottom:30px;">월튼체인은 모체인-자체인 구조의 체인을 넘어선 생태계이다. 다른 체인의 데이터에 접근하거나 데이터를 공유할 수 있고 효과적으로 빠른 검색이 가능하다. 월튼체인의 생태계에서는 모듈의 전문적 분배를 통해 모든 자체인들이 데이터를 정밀하게 저장하고 모체인 생태계에 업로드하며 조회할 수 있다. 월튼체인 합의 메커니즘 WPoC(Waltonchain Proof of Contribution)는 월튼체인 생태계의 건전한 발전을 위해 매우 중요하다. 그 세 가지 구성 요소는 PoW(Proof of Work), PoS(Proof of Stake), PoL(Proof of Labor)이다. PoL은 월튼체인 네트워크 중 자·모체인, 다른 자체인 간의 슈퍼 마스터 노드(SMN), 가디언 마스터 노드(GMN) 또는 마스터 노드(MN)에 대한 데이터 전송이나 토큰교환 행위의 작업 증명이다. 이 작업 증명은 작업량에 기반하여 월튼체인 기금의 부가적인(체인간 데이터 작업 증명) 보상을 받을 수 있다. 월튼체인 생태계는 합리적인 전송 수수료(GAS) 메커니즘을 통해 블록체인 자체를 보호하기 때문에 데이터 유통에 영향을 미치지 않고 체인간 데이터를 전송할 수 있다. 동시에 월튼체인 튜링 컴플리트(Turing-complete)를 유지할 수 있는 메커니즘이 필요한데 데이터의 특징을 이용해 해시값 또는 인덱스를 추출하고 월튼체인의 메인체인에 저장함으로써 향후 월튼체인 데이터 검색 시 체인 간 인덱싱 메커니즘을 통해 필요한 데이터를 빠르게 찾을 수 있고 체인 간 데이터 전송을 통해 신속하게 진위를 검증할 수 있다.</p>',
    },
    sectionThree: {
        tabTextOne: '토큰 응용',
        tabTextTwo: '데이터 유통',
        tabTextThree: '가치 유통',
        tabTextFour: '맞춤형 서비스',
        tabTextFive: '생태계 구축',
        contentOneTitle: '<h4 style="font-size:16px">메인넷 런칭, PC버전, 안드로이드, IOS 지갑 출시</h4>',
        contentOneText: '<p>월튼체인은 2018년에 모체인을 구축했고 동시에 월튼체인 지갑 앱을 런칭했다. 월튼체인 노드는 토큰을 상호교환할 수 있고 메인체인 유지에 참여할 수 있다.</p>',
        contentTwoTitle: '<h4 style="font-size:16px">체인에 데이터 업로드, 체인 간 데이터</h4>',
        contentTwoText: '<p>2018년 예술 소장품 체인인 프레이체인이 상용화되면서 소장품의 각종 데이터는 체인에 업로드되고 전송된다. 물류업계의 huodull은 자체인을 상용화해 물류의 데이터가 체인에 업로드되고 전송된다. 의류 업계의 KALTENDIN은 자체인을 상용화해 의류 데이터가 체인에 업로드되고 전송된다. 월튼체인은 더욱 다양한 영역의 자체인을 구축해 다른 업종의 데이터도 체인에 업로드되고 전송할 수 있다.</p>',
        contentThreeTitle: '<h4 style="font-size:16px">체인에 자동 업로드, 빅데이터 분석</h4>',
        contentThreeText: '<p>2018년 월튼체인은 체인 간 구조를 완성했다. 자체인을 모체인에 연결해 자체인의 데이터를 모체인에 업로드할 수 있고 자체인의 토큰은 체인 간 메커니즘을 통해 월튼체인의 토큰과 교환하고 더 나아가 다른 자체인의 토큰과도 교환할 수 있다. 가치는 체인에서 유통된다.</p>',
        contentFourTitle: '<h4 style="font-size:16px">모체인과 자체인 연결, 상호작용</h4>',
        contentFourText: '<p>체인 간 구조가 완성되면 모체인과 자체인이 연결돼 상호작용한다. 월튼체인은 2020년 이후 다양한 산업 분야에 맞춤형 서비스를 제공할 것이다. 또한 자체인의 노드는 자체인 토큰을 사용해 다른 자체인의 데이터를 조회하거나 서비스를 이용할 수 있다.</p>',
        contentFiveTitle: '<h4 style="font-size:16px">자체인과 모체인, 자체인간의 월튼체인 비즈니스 생태계 구축</h4>',
        contentFiveText: '<p>다섯 번째 단계는 생태계 구축이다. 위의 네 단계가 실현된 후 자체인과 모체인, 자체인 간에 월튼체인 비즈니스 생태를 구축한다.</p>'
    },
    sectionFive: {
        customerText: '고객서비스',
        mediaText: '제휴문의(매체)',
        onlineText: 'SMN고객서비스',
        businessText: '제휴문의(일반) ',
        leaveText: '문의',
        twitterText: 'Twitter',
        teleText: 'Telegram',
        faceText: 'Facebook',
        kaoText: 'Kaokao',
        naverText: 'Naver Blog'
    }
  }
  