export default {
    home: {
      headerOne: 'WTA (BLUE PAPER)',
      headerTwo: 'SOLUTIONS',
      headerThree: 'ECOSYSTEM',
      headerFour: 'INFO',
      headerFive: 'WHITE PAPER',
      headerSix: 'COMMUNITIES',
      headerSeven: 'WTC',
      headerTextOne: 'The Global Leader in',
      headerTextTwo: 'Blockchain + IoT',
      prevText: '上一页',
      nextText: '下一页',
      aboutText: 'About Waltonchain',
      centerText: 'Core Advantages',
      planText: 'Project Planning',
      playText: 'Partners',
      linkText: 'Contact Us'
    },
    tab:{
        backText: 'Feedback',
        downloadText: 'DOWNLOAD',
        knowText: 'To know about our solutions for your industry',
    },
    food:{
        monitorText: 'Automatic monitoring',
        wayText: 'Two-way traceability',
        chainText: 'Automatic data uploading to blockchain',
        titleOneText: 'WTC-Food System',
        titleTwoText: 'Case Presentation',
        tagOneText: 'Powerful and flexible data collection',
        tagTwoText: 'Process information traceability',
        tagThreeText: 'High credibility',
        tagFourText: 'Food safety assurance',
        videoText: 'Watch a Video',
        paraText: ' WTC-Food System adds up the Internet, cloud computing and big data to the IoT + blockchain core for IoT collection and automatic uploading of food safety, production and circulation data to blockchain, global distribution management and traceability. '
    },
    cloth:{
        storeText: 'Smart store',
        chainText: 'Big data uploading to blockchain',
        authText: 'Luxury goods authentication',
        titleOneText: 'WTC-Garment System',
        titleTwoText: 'Case Presentation',
        tagOneText: 'Full intelligentization of the management process',
        tagTwoText: 'Immersive shopping experience',
        tagThreeText: 'Brand value maintenance via authentication',
        tagFourText: 'Enrichment of consumer profiles',
        videoText: 'Watch a Video',
        paraTitleText: 'Having trouble with long and costly supply chains?',
        paraContentText: "Unable to control various SKUs and error rate in logistics and warehousing?<br>The world’s first blockchain-based clothing authenticity system WTC-Garment by Waltonchain is applied to all links of the clothing industry, such as supply chain optimization, warehousing and logistics management, and consumer big data extraction to fundamentally solve the common industry pain points."
    },
    smn:{
        paraOneTitle: 'Recruitment Program Introduction',
        paraOneContent: '<p>To enrich and improve the business ecology of Waltonchain, Waltonchain Foundation is about to recruit 99 Super Master Nodes worldwide to mobilize the global community for incubation and selection of high-quality child chains. To assist the development of the Waltonchain technology, this plan provides a set of incentive rules and an autonomous management mechanism aiming to accelerate the construction of the open and expansive child chain ecology and cross-chain ecology, attract more public attention to the Value IoT and related application implementation services and lead the humanity and lead human to enter the reliable digital life.</p><p>In the Waltonchain ecosystem, the parent chain&nbsp;+ child chains architecture with cross-industry expansion&nbsp;is the development trend of the blockchain technology.&nbsp;The child chains of various industries utilize innovative encrypted and secure IoT data collection hardware, integrate in-depth business logics of a specific industry&nbsp;and bring vitality to the open industry expansion mechanism. SMN nodes will form a hierarchical multi-chain network&nbsp;linking&nbsp;various industries&nbsp;to promote the child chain ecology prosperity worldwide. Waltonchain’s cross-chain mechanism allows efficient value and data circulation between the parent chain and multiple child chains, and integrate the multi-chain into a whole cross-industry blockchain ecology.&nbsp;An SMN is a cross-chain node that confirms cross-chain transactions and ensures their safety and efficiency.</p><p>Waltonchain Foundation invested 10 million WTC to establish Waltonchain Global Ecosystem Incubation Fund (WGEIF) to incubate 50 global high-quality child chains and provides 550,000 WTC to SMN references. Waltonchain Foundation plans to recruit 30 SMNs in Asia, 30 in the&nbsp;US, 19 in Europe, 15 in Australia and 5 in Africa based on the current global distribution of nodes. In the event of any change of the distribution&nbsp;that&nbsp;leads&nbsp;to the change of the program, a further written notice will be provided.</p>',
        paraTwoTitle: 'Recruitment Type',
        paraTwoContent: '<p>Community users — global Waltonchain community supporters</p><p>Business users — participants in the new Waltonchain business ecosystem</p><p>R&amp;D teams — global Waltonchain technology innovative developers</p><p>Academic teams — global Waltonchain technology researchers</p><p>Investment institutions — global Waltonchain capital supporters</p>',
        paraThreeTitle: 'SMN Permissions/Capabilities',
        paraThreeContent: '<p>1. Child Chain Projects Recommendation Priority.</p><p>After the recommendation&nbsp;and successful incubation of&nbsp;a child chain project, rewards will&nbsp;be given to the corresponding reference SMN.</p><p>2. Child Chain Voting Right.</p><p>When WGEIF proposes incubation of a certain child chain, all SMNs have the voting right on incubation proposals. A proposal shall be deemed passed when one third or more votes in favor are valid.&nbsp;One node&nbsp;has&nbsp;one vote. Abstain from voting or no vote within the set time shall be deemed vote abstention.</p><p>3. An SMN confirms&nbsp;nodes by running cross-chain transactions, ensures&nbsp;safe and efficient cross-chain transactions.</p>',
        paraFourTitle: 'SMN Qualification',
        paraFourContent: '<p>1. Applicants must hold not less&nbsp;than 100,000 WTC stored at an ERC20&nbsp;address before token swap&nbsp;and at a WTC Wallet address after the token swap.</p><p>2. Applicants holding&nbsp;not less than 50,000 WTC are&nbsp;qualified to subscribe for WTC exchange at the Binance exchange&nbsp;rate of WTC for BTC/ETH MA20&nbsp;(average closing price for the past&nbsp;20 days)&nbsp;on the application date.&nbsp;GMNs&nbsp;enjoy a 5 percent discount&nbsp;on the above price.&nbsp;Please submit your subscription application at the official&nbsp;Waltonchain website.</p><p>3. After confirming the SMN qualification, please ensure the address continues to hold not less than 100,000 WTC. An SMN holding&nbsp;less than 100,000 WTC will be automatically considered a waiver of the SMN identity.</p>',
        paraFiveTitle: 'Distribution of SMN Rewards',
        paraFiveContent: '<p style="color:#8200ff;">Distribution of SMN Rewards</p><p>1. Waltonchain Foundation invested 10 million WTC to establish WGEIF&nbsp;to incubate 50 global high-quality child chains. The child chain projects can only accept investment&nbsp;in WTC.</p><p>2. Based on the incubation needs and scope of cooperation, a&nbsp;child chain project can exchange child chain tokens&nbsp;for maximum&nbsp;of 100,000 WTC for&nbsp;project development purposes.&nbsp;The investment quota of each child&nbsp;chain project will be decided according to the voting of SMNs, and the details will be provided&nbsp;in written form.</p><p>3. Waltonchain Foundation provides 550,000 WTC to SMN references.</p><p style="color:#8200ff;">SMN Reward Mechanism</p><p>1. After a successful recommendation of a child chain project by SMN, the child chain token investment with value of no more&nbsp;than 100,000 WTC obtained by WGEIF will be used as follows:</p><ul><li>5% for a global&nbsp;airdrop;</li><li>30% for SMN rewards (an SMN reference enjoys 10%; the remaining 20% is split equally between all SMNs);</li><li>65% for Waltonchain ecosystem&nbsp;construction.</li></ul><p>2. SMN with the highest annual total&nbsp;number of child chain recommendations&nbsp;(at least 5 child chains&nbsp;recommended) will get a reward equal to&nbsp;5,000,000 USD in child chain tokens form WGEIF.</p><p>3. SMNs&nbsp;will have the privilege&nbsp;to attend the Waltonchain Summit, annual meetings&nbsp;and other events&nbsp;free of charge.</p><p>4. SMNs will&nbsp;be qualified for the 2<sup>nd</sup> term Director of Waltonchain Foundation.</p><p>5. SMNs will&nbsp;be qualified for priority to study at Walton Blockchain Institute in Korea.</p><p>6. SMNs will be qualified for priority to obtain Sales Agency&nbsp;rights&nbsp;for&nbsp;the relevant Waltonchain products.</p><p style="color:#8200ff;">SMN Reference Reward Mechanism</p><p>1. A reference who successfully recommended an&nbsp;SMN obtains&nbsp;2600 WTC and will continue to obtain extra 60 WTC when a new SMN joins&nbsp;after a successful recommendation by others.</p><p>2. A reference with the highest total&nbsp;number of SMN recommendations&nbsp;(at least 5 SMNs&nbsp;recommended) will get a reward equal&nbsp;to&nbsp;1,000,000 USD in&nbsp;child chain tokens&nbsp;form WGEIF.</p><p>3. When an&nbsp;SMN has no reference,&nbsp;the recommendation reward is obtained by the SMN itself or by&nbsp;its&nbsp;organization.</p><p>4. An&nbsp;SMN&nbsp;reference&nbsp;will be qualified to attend the Waltonchain Summit, annual meetings and other events free of charge.</p><p>5. An&nbsp;SMN&nbsp;reference&nbsp;will be qualified for priority to study at&nbsp;Walton Blockchain Institute in Korea.</p><p>6. An SMN reference will be qualified for priority to obtain Sales Agency&nbsp;rights&nbsp;for&nbsp;the relevant Waltonchain products.</p><p style="text-align:center;"><img src="http://www.waltonchain.org/en/Uploads/2019-01-15/5c3d985cbc0cd.png" title="from clipboard" alt="from clipboard"></p><p><strong>*Note:</strong> An&nbsp;SMN reference refers to a user who successfully recommended&nbsp;an SMN to Waltonchain.</p>',
        paraSixTitle: 'SMN List',
        paraSixContent: '<img style="max-width:100%;" src="http://www.waltonchain.org/en/Uploads/2019-01-15/5c3d977c55d4c.png" title="from clipboard" alt="from clipboard">'
    },
    childChain:{
        paraOneTitle: 'Public Child Chains Introduction',
        paraOneContent: '<p>Waltonchain is a cross-chain ecosystem where the parent chain and child chains serve as the framework. In this cross-chain ecosystem, data circulation and value transfer can be realized between child chains.</p><p>In general, data in a blockchain + IoT ecosystem is a simple ecosystem. Parts of the ecosystem are fragmented. Different domains build their own data ecosystem around their data, or build their own blockchain architecture. Blockchains may even adopt different structure and technical systems.</p><p>The main aim of Waltonchain is to connect data. In the Waltonchain ecosystem, the multi-chain architecture formed by the parent chain and child chains follows the development trend of cross-industry coverage in the blockchain technology. The innovative child chains for various industries utilize the encrypted and secure IoT data acquisition hardware to deeply integrate the business logic of specific industries and form an open industry expansion mechanism with strong vitality. Waltonchain is committed to incubation of 50 outstanding global child chain projects to build a massive cross-industry blockchain ecosystem.</p>',
        paraTwoContent: 'DMTC is the Global Eco-agriculture Application Traceability Chain which combines Smart Agriculture, Smart Micromarket, and Innovative Retail. On the base platform of Waltonchain, it solves a series of pain points for agricultural products from planting, production, warehousing, and logistics to customer terminals and after sales service. DMTC comprehensively creates an ecosystem of Smart Agriculture.',
        detailText: 'Details'
    },
    whitePaper:{
        mainTitleText: 'The Innovation Redesigned: Waltonchain 101 What exactly is Waltonchain?',
        paraOneTitle: 'Waltonchain White Paper V 2.0',
        paraOneContent: '<p><span style="line-height:1;">On September 4, 2018, Waltonchain officially released White Paper V2.0. It is not only a periodic report on the business ecosystem construction progress, but also a deep interpretation of the future vision of Waltonchain. It presents the most sincere, valuable and imaginative consensus mechanism available today, WPoC (Waltonchain Proof of Contribution), and puts forward the unprecedented Chain Cluster concept.</span> </p><p><span style="line-height:1;">The various projects Waltonchain has been working on have one simple idea at their core: to lead humanity into a reliable digital life, establish a brand new sustainable business ecosystem with all things interconnected via the blockchain technology. With our trust mechanism, human life will become more productive. We invite everyone to read our white paper and discover the potential of Waltonchain!</span> </p>',
        btnText: 'Browse the White Paper',
        paraTwoTitle: 'Read',
        bookOneName: 'English',
        bookTwoName: 'Chinese',
        bookThreeName: 'Chinese Traditional',
        bookFourName: 'Korean',
        bookTimeText: 'Update date 2018-10-17',
        videoText: 'Watch a Video Introduction'
    },
    exchange:{
        paraOneText: 'Since its listing on one of the world’s major cryptocurrency exchanges Binance in August 2017, Waltoncoin (WTC) has entered 30+ cryptocurrency exchanges globally.',
        paraTwoText: 'Platforms supporting mainnet WTC coins:',
        paraThreeText: 'Platforms performing automatic swap of ERC-20 WTC tokens to mainnet WTC coins:'
    },
    sectionOne: {
        titleText: '<h3 style="letter-spacing: 2px;margin-bottom: 40px;">Waltonchain: Leading humanity to a reliable digital life.</h3>',
        contentText: '<p style="margin-bottom: 70px;">Waltonchain project is named after Charles Walton (1921—2011), the famous inventor of RFID technology.<br><br>Waltonchain is the underlying public business ecochain. It resorts to RFID technology to create a unique combination of blockchain and the Internet of Things (IoT). On this ecochain, merchants can create customized child chains and monitor production, logistics, warehousing and retail circulation of all commodities. As a business ecochain, Waltonchain ensures that all data on it is authentic and credible. With the self-developed reader chip and tag chip, all data of physical commodities in circulation is automatically recorded to blockchain. Thus Waltonchain avoids human interference, minimizes the data tampering possibility and creates a fair, transparent, traceable and credible new-generation business ecosystem.</p>',
        videoText: '观看视频介绍'
    },
    sectionTwo: {
        tabTextOne: 'Multi-scenario Application',
        tabTextTwo: 'Hardware & Software Integration',
        tabTextThree: 'Cross-chain Technology',
        expandText: '点击展开',
        contentOneTitle: '<h3 style="font-size:24px;font-weight:bold;margin-bottom:30px;line-height:36px">Waltonchain has been implementing technical applications in the clothing, food, collection, logistics and other industries.</h3>',
        contentOneText: '<p style="line-height:22px;margin-bottom:30px;">The clothing traceability authentication system based on the Waltonchain blockchain technology and relevant RFID hardware system includes RFID tags, smart RFID reader-writers, a clothing child chain, cross-chain nodes and an inspection system platform for data applications. The system can facilitate data circulation in production, logistics, warehousing, sales and other links; it ensures data authenticity and traceability of each garment. It can simplify the process, reduce costs for enterprises and ensure consumers’ interests by allowing them to check authenticity and quality of the purchased clothes easily. The KALTENDIN Production, Warehousing and Store System is an information management system for the clothing industry developed by KALTENDIN Group through adoption of the RFID IoT technology and blockchain. It utilizes RFID tags to read commodity information quickly and the blockchain technology to link traceability information and ensure it is tamperproof.</p><p>The food traceability system based on the Waltonchain blockchain technology and relevant hardware includes video collecting equipment, sensors, smart terminals, a food traceability child chain, cross-chain nodes and a data inspection system platform. After adopting the system, data hashes can be extracted and uploaded to blockchain automatically through smart terminals to ensure that the data is tamperproof. Consumers can easily check the relevant data through the data inspection system platform. Waltonchain technical team developed the S.I. Two-way Traceability Marketing Platform targeted at traditional traceability systems in the food industry. Waltonchain performs the Blockchain+ transformation of traceability platforms: traceability information is uploaded to blockchain to ensure tamper protection.</p><p>Skynovo, Huodull, KALTENDIN, Freyrchain, ProdutorAgro (Brazil), Volcity Wine (New Zealand), MitoQ (New Zealand), and Global eSolutions Group (USA) are among Waltonchain customers.</p>',
        contentTwoTitle: '<h3 style="font-size:24px;font-weight:bold;margin-bottom:30px;line-height:36px">Waltonchain seamlessly integrates Blockchain and RFID to ensure data reliability right from the source.</h3>',
        contentTwoText: '<p style="line-height:22px;margin-bottom:30px;">In acquisition, perception and processing of all available data in the IoT or an ecosystem network, Waltonchain mainly focuses on two aspects:1) data reliability; 2) data value circulation.</p><p>The Waltonchain technical team has developed a smart RFID reader-writer with independent intellectual property rights, which can collect data, process it and upload to blockchain automatically. We also developed a smart data collecting device with independent intellectual property rights, which automatically collects, processes and uploads various sensor data, audio and video, location information, etc. to blockchain.</p><p>The existing blockchain applications mostly adopt software solutions and lack hardware support. Although the blockchain technology can guarantee data tamper protection, openness and transparency, because of the lack of hardware support the existing applied solutions cannot guarantee authenticity and reliability of data sources. The key feature of Waltonchain is implementation of a blockchain hardware system ensuring that data is authentic and reliable from the source.</p><p>In general, data in a blockchain + IoT ecosystem is also a simple ecosystem. Parts of the ecosystem are fragmented. Different domains build their own data ecosystem around their data, or build their own blockchain architecture. Even blockchains may adopt different structure and technical systems. The main aim of Waltonchain is to connect data. We use integrated hardware and software, smart contracts with data customization, the Waltonchain cross-chain technology and WPoC consensus mechanism to achieve data integration, circulation, verification and storage between different blockchains (child chains) and thus connect different data sources and obtain wide data circulation.</p><p>The Waltonchain team has been committed to establishing a complete, reliable, credible, scalable and transferable data-value-oriented blockchain ecosystem of the Internet of Everything and strives to make Waltonchain an integrated data collection equipment manufacturer, data communication researcher and developer, and data service provider.</p>',
        contentThreeTitle: '<h3 style="font-size:24px;font-weight:bold;margin-bottom:30px;line-height:36px">Waltonchain’s outstanding cross-chain ecosystem brings cross-chain data co-sharing together with effective and fast indexing.</h3>',
        contentThreeText: '<p style="line-height:22px;margin-bottom:30px;">Waltonchain is a cross-chain ecosystem where the parent chain and child chains serve as the framework. Here data can access data on other chains, thus realizing cross-chain data co-sharing and effective and quick indexing. In the large multi-chain and cross-chain ecosystem of Waltonchain, each child chain can accurately store its own data and upload it to the big parent chain ecosystem to realize cross-chain query through data union and professional distribution of modules.</p><p>Waltonchain consensus mechanism WPoC (Waltonchain Proof of Contribution) is one of the important mechanisms to maintain the benign development of the Waltonchain ecosystem. WPoC includes three components: PoW (Proof of Work) + PoS (Proof of Stake) + PoL (Proof of Labor). PoL is a brand new consensus mechanism for data transmission and token exchange between various parent chain, child chain and cross-child-chain nodes on the Waltonchain network, i.e. SMN (Super Master Nodes), GMN (Guardian Master Nodes) and MN (Master Nodes).</p><p>The whole Waltonchain ecosystem ensures blockchain self-protection through calculation and tokenization based on the reasonable fuel (Gas) mechanism. Therefore it is necessary to both realize cross-chain transmission without affecting data circulation and maintain the Turing complete ecosystem mechanism of Waltonchain. It is realized in cross-chain data transmission: extraction of hashes or indices basing on data features and storage on the Waltonchain parent chain makes it convenient to search for data in the Waltonchain network in the future. Using our cross-chain index mechanism, the required data can be found quickly; its authenticity can be verified quickly through cross-chain data.</p>'
    },
    sectionThree: {
        tabTextOne: 'Token Circulation',
        tabTextTwo: 'Data Circulation',
        tabTextThree: 'Value Circulation',
        tabTextFour: 'Customized Services',
        tabTextFive: 'Ecosystem Construction',
        contentOneTitle: '<h4 style="font-size:16px">Mainnet and apps for PC, Android and iOS are live</h4>',
        contentOneText: '<p>Waltonchain built, deployed and launched its parent chain and WTC Wallet client applications in 2018. Nodes on the Waltonchain maintain the parent chain and can exchange tokens.</p>',
        contentTwoTitle: '<h4 style="font-size:16px">Data uploading to the chain, cross-chain data</h4>',
        contentTwoText: '<p>In 2018, we focus on the implementation of: the art collection chain Freyrchain uploading to blockchain and transmitting all kinds of collection data; the logistics project Huodull uploading to blockchain and transmitting all kinds of online logistics data; the clothing project KALTENDIN uploading to blockchain and transmitting all kinds of clothing industry data. Waltonchain will enter more child chain domains and upload data from different industries to blockchain for circulation.</p>',
        contentThreeTitle: '<h4 style="font-size:16px">Auto uploading to the chain, data applications</h4>',
        contentThreeText: '<p>Waltonchain is about to complete and deploy the cross-chain architecture. It connects the parent chain and child chains; child chain data can be uploaded to the parent chain. Using the cross-chain mechanism, child chain tokens are exchanged for WTC and can be further exchanged for other child chain tokens, thus value circulates on blockchain.</p>',
        contentFourTitle: '<h4 style="font-size:16px">Parent &amp; child chain connection and interaction</h4>',
        contentFourText: '<p>After the completion of the cross-chain architecture, the parent chain and child chains connect and interact. Waltonchain has started to provide customized services for various industries. Meanwhile, child chain nodes will query information or use services on other child chains simply by using child chain tokens.</p>',
        contentFiveTitle: '<h4 style="font-size:16px">Ecosystem Construction</h4>',
        contentFiveText: '<p>After the above four steps, the Waltonchain business ecosystem is formed via the parent-child and child-child chain integration.</p>'
    },
    sectionFive: {
        customerText: 'Customer Service',
        mediaText: 'Media Cooperation',
        onlineText: 'SMN Service',
        businessText: 'Business Development',
        leaveText: '留言板',
        teleText: 'Telegram',
        redditText: 'Reddit',
        twitterText: 'Twitter',
        mText: 'Medium',
        tubeText: 'Youtube'
    }
  }
  