export default {
    home: {
      headerOne: 'WTA (蓝皮书)',
      headerTwo: '方案',
      headerThree: '生态',
      headerFour: '资讯',
      headerFive: '白皮书',
      headerSix: '全球社区',
      headerSeven: 'WTC',
      headerTextOne: '全球区块链物联网',
      headerTextTwo: '领导者',
      prevText: '上一页',
      nextText: '下一页',
      aboutText: '关于沃尔顿链',
      centerText: '核心优势',
      planText: '项目规划',
      playText: '合作伙伴',
      linkText: '联系我们',
    },
    tab:{
        knowText: ''
    },
    sectionOne: {
        titleText: '<h3 style="letter-spacing: 2px;margin-bottom: 40px;">沃尔顿链引领人类全面进入可信赖的数字化生活</h3>',
        contentText: '<p style="margin-bottom: 70px;">2016年11月30日，RFID技术发明者查理·沃尔顿（Charlie Walton）逝世5周年，为纪念这位伟大的科学家，项目于当日创立，并正式命名为沃尔顿链Waltonchain。<br><br>沃尔顿链(Waltonchain) 是一条底层的商业生态公有链。 作为区块链物联网的领导者，沃尔顿链独特地将区块链技术与RFID技术结合。在此链上，商家可以根据自己的需求建立各式各样的子链,对所有商品的生产、物流、仓储、零售的流转全过程进行监控。沃尔顿链作为典型的商业生态链，其主要特征是保障所有的数据( 含物权归属数据，商品流转数据等)真实可信。通过自主研发的读卡器芯片和标签芯片，实现线下实物商品在流转过程中的所有数据能够自动快速上链，避免人为干扰，最大程度地降低数据篡改的可能性，从而打造一个公平、 透明、可溯源、真实、可信的新一代商业生态圈。</p>',
        videoText: '观看视频介绍'
    },
    sectionTwo: {
        tabTextOne: '多场景应用',
        tabTextTwo: '软硬件结合',
        tabTextThree: '跨链技术',
        expandText: '点击展开',
        contentOneTitle: '<h3 style="font-size:24px;font-weight:bold;margin-bottom:30px;line-height:36px">目前，沃尔顿链已经在服装、食品、收藏品、物流等领域进行技术落地应用。</h3>',
        contentOneText: '<p style="line-height:22px;margin-bottom:30px;">基于沃尔顿链区块链技术及相关的 RFID 硬件系统实现的服装溯源保真系统，包括 RFID 标签，RFID 智能读写器，服装子链，跨链节点，数据应用查验系统平台。该系统可以打通生产、物流、仓储，销售等环节的数据流转，并且保证数据真实，保证每件服装都可追溯，既可以简化流程，降低企业成本，还可以保证消费者的利益，消费者可以很方便查验所购服装的真伪，以及品质。其中卡尔丹顿生产、仓储、门店系统是卡尔丹顿集团结合 RFID 物联网技术及区块链技术开发的服装行业信息化管理系统。使用 RFID 标签实现商品信息的快速读取，结合区块链技术实现溯源信息上链，确保溯源信息防篡改。<br>基于沃尔顿链区块链技术及相关硬件设备实现的一套食品溯源系统，包括视频采集设备，传感器，智能终端，食品溯源子链，跨链节点，及数据查验系统平台。采用该系统后，可以通过智能终端设备，自动将采集数据抽取指纹上链，确保数据不可篡改，并且消费者可通过查验系统平台非常方便查验相关的数据。其中 S.I.双向溯源营销平台是沃尔顿技术团队针对食品行业开发的传统溯源系统，随着区块链技术的发展，沃尔顿链对其溯源平台进行区块链+改造，将溯源平台上的溯源信息上链，确保溯源信息防篡改。<br>沃尔顿链目前服务过的客户包括凯斯诺、货兜、卡尔丹顿、时尚星球、巴西PRODUTORAGRO、巴西Yandeh、新西兰VOLCITY WINE、新西兰 MitoQ、美国 Global eSolutions Group等。</p>',
        contentTwoTitle: '<h3 style="font-size:24px;font-weight:bold;margin-bottom:30px;line-height:36px">沃尔顿链完美地将区块链与RFID技术结合，确保数据从源头开始就是可靠的。</h3>',
        contentTwoText: '<p style="line-height:22px;margin-bottom:30px;">面向物联网或生态网络，面向所有的可获取、感知和处理的数据，沃尔顿链主要做好两件事：第一件就是要确保数据可信；第二件就是要保证数据价值流通。<br>沃尔顿链技术团队研发出一种自主知识产权的智能 RFID 读写器设备，可实现数据自动采集，处理，数据上链。同时还研发了一种自主知识产权的智能数据采集设备，可以实现各种传感器数据、音视频数据，位置信息数据等自动采集，处理，数据上链。<br>现有区块链应用缺少硬件支撑，大多是采用软件的方案。虽然区块链技术可以保证数据不可篡改，公开透明，但是现有应用方案，缺少硬件支撑，无法保证数据源头是真实可靠的。沃尔顿链的一大特点是实现了一种区块链硬件系统，确保数据从源头开始就是真实可靠的。<br>通常区块链-物联网生态的数据都是单一生态，彼此生态区域是割裂的，不同的领域围绕自己的数据构建自己的数据生态，或者构建自己的区块链架构，甚至链也是采用不同结构不同技术体系。沃尔顿链首要任务就是要把数据联通起来。我们的做法就是采用软硬融合、数据定制合约模式、跨链技术以及沃尔顿 WPoC共识机制实现针对不同区块链（子链）间数据的融合流通、验证和存储。这样的话，我们既可以实现不同数据源的连通，又可以实现数据广泛的流动。<br>沃尔顿团队和社区一直致力于面向泛物联网领域中建立起可靠、可信、可扩展、可移植的数据价值区块链的全生态体系，努力做到集数据设备制造、数据通信研发、数据服务提供的综合服务商。</p>',
        contentThreeTitle: '<h3 style="font-size:24px;font-weight:bold;margin-bottom:30px;line-height:36px">沃尔顿链独有的跨连生态，实现跨链数据的共享和有效的快速索引。</h3>',
        contentThreeText: '<p style="line-height:22px;margin-bottom:30px;">沃尔顿链是以母子链为架构的跨链生态，这让数据在不同的链上也能访问其它链的数据，实现跨链数据的共享和有效的快速索引。在沃尔顿链的多链和跨链大生态下，通过数据的合纵连横，模块的专业化分配，每条子链都能够精准地存储自身数据，并上传到母链大生态，实现跨链查询。<br>沃尔顿链共识机制 WPoC（Waltonchain Proof of Contribution），是一种维系沃尔顿链生态体系良性发展的重要机制之一，主要有三个重要组成部分：PoW（Proof of Work）+PoS（Proof of Stake）+PoL（Proof of Labor）。其中，PoL是一种全新的，针对沃尔顿链网中各个子母链、不同子链间的跨链节点SMN（Super Master Node）、GMN（Guardian Master Node）或 MN（Master Node）进行数据传输或通证交换等行为的工作证明。<br>由于整个沃尔顿链生态体系通过合理的燃料（GAS）机制计算以及通证化来保障区块链实现自我保护，因此需要这种既不影响数据流通，实现跨链传输，同时又不能降低沃尔顿链图灵完备的生态机制，其具体表现为跨链传输数据——利用数据特征来提取哈希指纹或索引存放沃尔顿主链，方便日后在搜索沃尔顿链网的数据时，通过我们跨链索引的机制可以快速的找到所需要的数据，并且通过跨链的数据可以快速的验证其真实性。</p>'
    },
    sectionThree: {
        tabTextOne: '通证应用',
        tabTextTwo: '数据流通',
        tabTextThree: '价值流通',
        tabTextFour: '定制服务',
        tabTextFive: '生态建成',
        contentOneTitle: '<h4 style="font-size:16px">上线主网，PC端钱包、安卓版钱包、IOS版钱包</h4>',
        contentOneText: '<p>沃尔顿链于 2018 年搭建、部署并上线了母链，同时还研发、上线沃尔顿链的客户端应用，沃尔顿链上的节点能相互交换通证并参与到主链的维护当中。</p>',
        contentTwoTitle: '<h4 style="font-size:16px">数据上链，跨链传输</h4>',
        contentTwoText: '<p>2018 年专注于艺术收藏品的弗雷尔链落地，收藏品的各种数据上链传输；专注于物流行业的货兜项目落地，物流线上的种种数据上链传输；专注于服装行业的卡尔丹顿项目落地，服装行业的数据上链传输；沃尔顿链会接入更多领域的子链，不同行业的数据也将上链传输。</p>',
        contentThreeTitle: '<h4 style="font-size:16px">自动上链，数据应用</h4>',
        contentThreeText: '<p>沃尔顿链即将完成并部署了跨链的架构，子链与母链连接起来，子链上的数据能上传到母链上，子链的通证通过跨链机制与沃尔顿链的通证互换，并可进一步与其它子链的通证互换。价值在链上流通起来。</p>',
        contentFourTitle: '<h4 style="font-size:16px">母链与子链之间的联通、交互</h4>',
        contentFourText: '<p>跨链结构完成后，母链与子链之间连通、交互。沃尔顿链已向各行业开始提供定制的服务，同时，某条子链上的节点只需使用子链上的通证便可以查询其它子链上的资料或使用其它子链上的服务。</p>',
        contentFiveTitle: '<h4 style="font-size:16px">子链与母链、子链与子链之间构成沃尔顿链商业生态</h4>',
        contentFiveText: '<p>实现了上述四个步骤后，子链与母链，子链与子链间构成了沃尔顿链的商业生态。</p>'
    },
    sectionFive: {
        customerText: '客服中心',
        mediaText: '媒体合作',
        onlineText: 'SMN专线',
        businessText: '商务BD',
        leaveText: '留言板',
        groupWechatText: '微信公众号',
        customerWechatText: '客服微信',
        teleText: 'Telegram',
        xinlangText: '新浪微博',
        redditText: 'Reddit'
    }
  }
  