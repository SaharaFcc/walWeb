export default {
    home: {
      headerOne: 'WTA (BLUE PAPER)',
      headerTwo: 'SOLUTIONS',
      headerThree: 'ECOSYSTEM',
      headerFour: 'INFO',
      headerFive: 'WHITE PAPER',
      headerSix: 'COMMUNITIES',
      headerSeven: 'WTC',
      headerTextOne: 'The Global Leader in',
      headerTextTwo: 'Blockchain + IoT',
      prevText: '上一页',
      nextText: '下一页',
      aboutText: 'About Waltonchain',
      centerText: 'Core Advantages',
      planText: 'Project Planning',
      playText: 'Partners',
      linkText: 'Contact Us'
    },
    sectionOne: {
        titleText: '<h3 style="letter-spacing: 2px;margin-bottom: 40px;">Waltonchain: Leading humanity to a reliable digital life.</h3>',
        contentText: '<p style="margin-bottom: 70px;">Waltonchain project is named after Charles Walton (1921—2011), the famous inventor of RFID technology.<br><br>Waltonchain is the underlying public business ecochain. It resorts to RFID technology to create a unique combination of blockchain and the Internet of Things (IoT). On this ecochain, merchants can create customized child chains and monitor production, logistics, warehousing and retail circulation of all commodities. As a business ecochain, Waltonchain ensures that all data on it is authentic and credible. With the self-developed reader chip and tag chip, all data of physical commodities in circulation is automatically recorded to blockchain. Thus Waltonchain avoids human interference, minimizes the data tampering possibility and creates a fair, transparent, traceable and credible new-generation business ecosystem.</p>',
        videoText: '观看视频介绍'
    },
    sectionTwo: {
        tabTextOne: 'Multi-scenario Application',
        tabTextTwo: 'Hardware & Software Integration',
        tabTextThree: 'Cross-chain Technology',
        expandText: '点击展开',
        contentOneTitle: '<h3 style="font-size:24px;font-weight:bold;margin-bottom:30px;line-height:36px">Waltonchain has been implementing technical applications in the clothing, food, collection, logistics and other industries.</h3>',
        contentOneText: '<p style="line-height:22px;margin-bottom:30px;">The clothing traceability authentication system based on the Waltonchain blockchain technology and relevant RFID hardware system includes RFID tags, smart RFID reader-writers, a clothing child chain, cross-chain nodes and an inspection system platform for data applications. The system can facilitate data circulation in production, logistics, warehousing, sales and other links; it ensures data authenticity and traceability of each garment. It can simplify the process, reduce costs for enterprises and ensure consumers’ interests by allowing them to check authenticity and quality of the purchased clothes easily. The KALTENDIN Production, Warehousing and Store System is an information management system for the clothing industry developed by KALTENDIN Group through adoption of the RFID IoT technology and blockchain. It utilizes RFID tags to read commodity information quickly and the blockchain technology to link traceability information and ensure it is tamperproof.</p><p>The food traceability system based on the Waltonchain blockchain technology and relevant hardware includes video collecting equipment, sensors, smart terminals, a food traceability child chain, cross-chain nodes and a data inspection system platform. After adopting the system, data hashes can be extracted and uploaded to blockchain automatically through smart terminals to ensure that the data is tamperproof. Consumers can easily check the relevant data through the data inspection system platform. Waltonchain technical team developed the S.I. Two-way Traceability Marketing Platform targeted at traditional traceability systems in the food industry. Waltonchain performs the Blockchain+ transformation of traceability platforms: traceability information is uploaded to blockchain to ensure tamper protection.</p><p>Skynovo, Huodull, KALTENDIN, Freyrchain, ProdutorAgro (Brazil), Volcity Wine (New Zealand), MitoQ (New Zealand), and Global eSolutions Group (USA) are among Waltonchain customers.</p>',
        contentTwoTitle: '<h3 style="font-size:24px;font-weight:bold;margin-bottom:30px;line-height:36px">Waltonchain seamlessly integrates Blockchain and RFID to ensure data reliability right from the source.</h3>',
        contentTwoText: '<p style="line-height:22px;margin-bottom:30px;">In acquisition, perception and processing of all available data in the IoT or an ecosystem network, Waltonchain mainly focuses on two aspects:1) data reliability; 2) data value circulation.</p><p>The Waltonchain technical team has developed a smart RFID reader-writer with independent intellectual property rights, which can collect data, process it and upload to blockchain automatically. We also developed a smart data collecting device with independent intellectual property rights, which automatically collects, processes and uploads various sensor data, audio and video, location information, etc. to blockchain.</p><p>The existing blockchain applications mostly adopt software solutions and lack hardware support. Although the blockchain technology can guarantee data tamper protection, openness and transparency, because of the lack of hardware support the existing applied solutions cannot guarantee authenticity and reliability of data sources. The key feature of Waltonchain is implementation of a blockchain hardware system ensuring that data is authentic and reliable from the source.</p><p>In general, data in a blockchain + IoT ecosystem is also a simple ecosystem. Parts of the ecosystem are fragmented. Different domains build their own data ecosystem around their data, or build their own blockchain architecture. Even blockchains may adopt different structure and technical systems. The main aim of Waltonchain is to connect data. We use integrated hardware and software, smart contracts with data customization, the Waltonchain cross-chain technology and WPoC consensus mechanism to achieve data integration, circulation, verification and storage between different blockchains (child chains) and thus connect different data sources and obtain wide data circulation.</p><p>The Waltonchain team has been committed to establishing a complete, reliable, credible, scalable and transferable data-value-oriented blockchain ecosystem of the Internet of Everything and strives to make Waltonchain an integrated data collection equipment manufacturer, data communication researcher and developer, and data service provider.</p>',
        contentThreeTitle: '<h3 style="font-size:24px;font-weight:bold;margin-bottom:30px;line-height:36px">Waltonchain’s outstanding cross-chain ecosystem brings cross-chain data co-sharing together with effective and fast indexing.</h3>',
        contentThreeText: '<p style="line-height:22px;margin-bottom:30px;">Waltonchain is a cross-chain ecosystem where the parent chain and child chains serve as the framework. Here data can access data on other chains, thus realizing cross-chain data co-sharing and effective and quick indexing. In the large multi-chain and cross-chain ecosystem of Waltonchain, each child chain can accurately store its own data and upload it to the big parent chain ecosystem to realize cross-chain query through data union and professional distribution of modules.</p><p>Waltonchain consensus mechanism WPoC (Waltonchain Proof of Contribution) is one of the important mechanisms to maintain the benign development of the Waltonchain ecosystem. WPoC includes three components: PoW (Proof of Work) + PoS (Proof of Stake) + PoL (Proof of Labor). PoL is a brand new consensus mechanism for data transmission and token exchange between various parent chain, child chain and cross-child-chain nodes on the Waltonchain network, i.e. SMN (Super Master Nodes), GMN (Guardian Master Nodes) and MN (Master Nodes).</p><p>The whole Waltonchain ecosystem ensures blockchain self-protection through calculation and tokenization based on the reasonable fuel (Gas) mechanism. Therefore it is necessary to both realize cross-chain transmission without affecting data circulation and maintain the Turing complete ecosystem mechanism of Waltonchain. It is realized in cross-chain data transmission: extraction of hashes or indices basing on data features and storage on the Waltonchain parent chain makes it convenient to search for data in the Waltonchain network in the future. Using our cross-chain index mechanism, the required data can be found quickly; its authenticity can be verified quickly through cross-chain data.</p>'
    },
    sectionThree: {
        tabTextOne: 'Token Circulation',
        tabTextTwo: 'Data Circulation',
        tabTextThree: 'Value Circulation',
        tabTextFour: 'Customized Services',
        tabTextFive: 'Ecosystem Construction',
        contentOneTitle: '<h4 style="font-size:16px">Mainnet and apps for PC, Android and iOS are live</h4>',
        contentOneText: '<p>Waltonchain built, deployed and launched its parent chain and WTC Wallet client applications in 2018. Nodes on the Waltonchain maintain the parent chain and can exchange tokens.</p>',
        contentTwoTitle: '<h4 style="font-size:16px">Data uploading to the chain, cross-chain data</h4>',
        contentTwoText: '<p>In 2018, we focus on the implementation of: the art collection chain Freyrchain uploading to blockchain and transmitting all kinds of collection data; the logistics project Huodull uploading to blockchain and transmitting all kinds of online logistics data; the clothing project KALTENDIN uploading to blockchain and transmitting all kinds of clothing industry data. Waltonchain will enter more child chain domains and upload data from different industries to blockchain for circulation.</p>',
        contentThreeTitle: '<h4 style="font-size:16px">Auto uploading to the chain, data applications</h4>',
        contentThreeText: '<p>Waltonchain is about to complete and deploy the cross-chain architecture. It connects the parent chain and child chains; child chain data can be uploaded to the parent chain. Using the cross-chain mechanism, child chain tokens are exchanged for WTC and can be further exchanged for other child chain tokens, thus value circulates on blockchain.</p>',
        contentFourTitle: '<h4 style="font-size:16px">Parent &amp; child chain connection and interaction</h4>',
        contentFourText: '<p>After the completion of the cross-chain architecture, the parent chain and child chains connect and interact. Waltonchain has started to provide customized services for various industries. Meanwhile, child chain nodes will query information or use services on other child chains simply by using child chain tokens.</p>',
        contentFiveTitle: '<h4 style="font-size:16px">Ecosystem Construction</h4>',
        contentFiveText: '<p>After the above four steps, the Waltonchain business ecosystem is formed via the parent-child and child-child chain integration.</p>'
    },
    sectionFive: {
        customerText: 'Customer Service',
        mediaText: 'Media Cooperation',
        onlineText: 'SMN Service',
        businessText: 'Business Development',
        leaveText: '留言板',
        groupWechatText: '微信公众号',
        customerWechatText: '客服微信',
        teleText: 'Telegram',
        xinlangText: '新浪微博',
        redditText: 'Reddit',
        twitterText: 'Twitter',
        mText: 'Medium',
        tubeText: 'Youtube'
    }
  }
  