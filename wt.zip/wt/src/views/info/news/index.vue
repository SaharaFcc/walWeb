<template>
  <div class="news">
    
  </div>
</template>
<script>
export default {
  name: "News",
  components: {},
  data() {
    return {};
  },
  mounted() {},
  methods: {},
};
</script>