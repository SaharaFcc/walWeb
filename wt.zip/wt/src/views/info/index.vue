<template>
  <div class="info">
    <router-view />
  </div>
</template>