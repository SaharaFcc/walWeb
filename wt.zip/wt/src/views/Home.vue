<template>
  <div class="home">
    <div class="button-mouse" v-if="currentSection !== 5">
      <div class="scroll"></div>
    </div>
    <svg-icon
      iconClass="back"
      className="back position-fixed cursor-btn"
      @click="backTop"
      v-if="currentSection !== 0"
    />
    <div class="scroll-items position-fixed d-flex" v-if="currentSection !== 0">
      <a
        class="cursor-btn"
        v-for="(item, index) in 6"
        :key="index"
        @click="changeSection(index)"
        :class="currentSection === index ? 'active' : ''"
      ></a>
    </div>
    <full-page :options="options" ref="fullpage" id="fullpage">
      <div
        class="section position-relative"
        v-lazy:background-image="{
          src:
            'http://www.waltonchain.org/en/Uploads/2018-12-20/5c1b6c49a27e9.gif',
        }"
      >
        <common-header />
        <div class="font-weight-bold text-center position-absolute navs-text">
          <span>{{ $t("home.headerTextOne") }}</span
          ><br />
          <span>{{ $t("home.headerTextTwo") }}</span>
        </div>
      </div>
      <div class="section position-relative">
        <div class="nav-humber">
          <div class="container d-flex justify-content-between">
            <div>{{ $t("home.aboutText") }}</div>
            <div></div>
          </div>
        </div>
        <div class="position-absolute">
          <div
            class="container d-flex justify-content-between align-items-center"
          >
            <div class="prevPage">
              <span class="link cursor-btn" @click="gotoprevpage">{{
                $t("home.prevText")
              }}</span>
              <span class="name"></span>
              <span class="index">01</span>
              /
              <span class="total">06</span>
            </div>
            <div>
              <div v-html="$t('sectionOne.titleText')"></div>
              <div v-html="$t('sectionOne.contentText')"></div>
            </div>
            <div class="nextPage">
              <span class="index">03</span>
              /
              <span class="total">06</span>
              <span class="name">{{ $t("home.centerText") }}</span>
              <span class="link cursor-btn" @click="gotonextpage">{{
                $t("home.nextText")
              }}</span>
            </div>
          </div>
          <div class="nav-video cursor-btn">
            {{ $t("sectionOne.videoText") }}
            <svg-icon iconClass="video" className="video" />
          </div>
        </div>
        <point-wave :num="1"/>
      </div>
      <div class="section position-relative">
        <div
          class="split-line position-absolute"
          :style="currentTab === 0 ? 'display:none' : 'display:block'"
        ></div>
        <div
          class="close-btn cursor-btn position-absolute"
          @click="closeTabContent"
          :style="currentTab === 0 ? 'display:none' : 'display:block'"
        >
          <i class="iconfont">&#xe601;</i>
        </div>
        <div class="nav-humber">
          <div class="container d-flex justify-content-between">
            <div>{{ $t("home.centerText") }}</div>
            <div></div>
          </div>
        </div>
        <div class="position-absolute">
          <div
            class="container d-flex justify-content-between align-items-center"
          >
            <div class="prevPage">
              <span class="link cursor-btn" @click="gotoprevpage">{{
                $t("home.prevText")
              }}</span>
              <span class="name">{{ $t("home.aboutText") }}</span>
              <span class="index">02</span>
              /
              <span class="total">06</span>
            </div>
            <div class="d-flex">
              <div class="text-center cursor-btn" @click="getTabContent(1)">
                <svg-icon iconClass="app" className="app" />
                <p>{{ $t("sectionTwo.tabTextOne") }}</p>
                <div v-if="currentTab === 0">
                  <img
                    v-lazy="
                      'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/youshi-down.png'
                    "
                    :key="'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/youshi-down.png'"
                  />
                  <div>
                    {{ $t("sectionTwo.expandText") }}
                  </div>
                </div>
              </div>
              <div class="text-center cursor-btn" @click="getTabContent(2)">
                <svg-icon iconClass="inter" className="inter" />
                <p>{{ $t("sectionTwo.tabTextTwo") }}</p>
                <div v-if="currentTab === 0">
                  <img
                    v-lazy="
                      'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/youshi-down.png'
                    "
                    :key="'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/youshi-down.png'"
                  />
                  <div>
                    {{ $t("sectionTwo.expandText") }}
                  </div>
                </div>
              </div>
              <div class="text-center cursor-btn" @click="getTabContent(3)">
                <svg-icon iconClass="tech" className="tech" />
                <p>{{ $t("sectionTwo.tabTextThree") }}</p>
                <div v-if="currentTab === 0">
                  <img
                    v-lazy="
                      'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/youshi-down.png'
                    "
                    :key="'http://www.waltonchain.org/en/Theme/wed/Public/images/icons/youshi-down.png'"
                  />
                  <div>
                    {{ $t("sectionTwo.expandText") }}
                  </div>
                </div>
              </div>
            </div>
            <div class="nextPage">
              <span class="index">04</span>
              /
              <span class="total">06</span>
              <span class="name">{{ $t("home.planText") }}</span>
              <span class="link cursor-btn" @click="gotonextpage">{{
                $t("home.nextText")
              }}</span>
            </div>
          </div>
          <div
            class="tab-content"
            :style="currentTab === 0 ? 'display:none' : 'display:block'"
          >
            <template v-if="currentTab === 1">
              <div v-html="$t('sectionTwo.contentOneTitle')"></div>
              <div v-html="$t('sectionTwo.contentOneText')"></div>
            </template>
            <template v-if="currentTab === 2">
              <div v-html="$t('sectionTwo.contentTwoTitle')"></div>
              <div v-html="$t('sectionTwo.contentTwoText')"></div>
            </template>
            <template v-if="currentTab === 3">
              <div v-html="$t('sectionTwo.contentThreeTitle')"></div>
              <div v-html="$t('sectionTwo.contentThreeText')"></div>
            </template>
          </div>
        </div>
        <point-wave :num="2"/>
      </div>
      <div class="section position-relative">
        <div class="nav-humber">
          <div class="container d-flex justify-content-between">
            <div>{{ $t("home.planText") }}</div>
            <div></div>
          </div>
        </div>
        <div class="position-absolute">
          <div
            class="container d-flex justify-content-between align-items-center"
          >
            <div class="prevPage">
              <span class="link cursor-btn" @click="gotoprevpage">{{
                $t("home.prevText")
              }}</span>
              <span class="name">{{ $t("home.centerText") }}</span>
              <span class="index">03</span>
              /
              <span class="total">06</span>
            </div>
            <div>
              <div class="process-tabs d-flex">
                <div
                  class="text-center cursor-btn"
                  @mouseover="getProcessContent(1)"
                >
                  <svg-icon iconClass="token" className="token" />
                  <div class="circle"></div>
                  <p class="font-weight-bold">
                    {{ $t("sectionThree.tabTextOne") }}
                  </p>
                  <p class="font-weight-bold">1.0</p>
                </div>
                <div
                  class="text-center cursor-btn"
                  @mouseover="getProcessContent(2)"
                >
                  <svg-icon iconClass="data" className="data" />
                  <div class="circle"></div>
                  <p class="font-weight-bold">
                    {{ $t("sectionThree.tabTextTwo") }}
                  </p>
                  <p class="font-weight-bold">2.0</p>
                </div>
                <div
                  class="text-center cursor-btn"
                  @mouseover="getProcessContent(3)"
                >
                  <svg-icon iconClass="value" className="value" />
                  <div class="circle"></div>
                  <p class="font-weight-bold">
                    {{ $t("sectionThree.tabTextThree") }}
                  </p>
                  <p class="font-weight-bold">3.0</p>
                </div>
                <div
                  class="text-center cursor-btn"
                  @mouseover="getProcessContent(4)"
                >
                  <svg-icon iconClass="custom" className="custom" />
                  <div class="circle"></div>
                  <p class="font-weight-bold">
                    {{ $t("sectionThree.tabTextFour") }}
                  </p>
                  <p class="font-weight-bold">4.0</p>
                </div>
                <div
                  class="text-center cursor-btn"
                  @mouseover="getProcessContent(5)"
                >
                  <svg-icon iconClass="eco" className="eco" />
                  <div class="circle"></div>
                  <p class="font-weight-bold">
                    {{ $t("sectionThree.tabTextFive") }}
                  </p>
                  <p class="font-weight-bold">5.0</p>
                </div>
              </div>
              <div class="process-text">
                <template v-if="currentProcess === 1">
                  <div v-html="$t('sectionThree.contentOneTitle')"></div>
                  <div v-html="$t('sectionThree.contentOneText')"></div>
                </template>
                <template v-if="currentProcess === 2">
                  <div v-html="$t('sectionThree.contentTwoTitle')"></div>
                  <div v-html="$t('sectionThree.contentTwoText')"></div>
                </template>
                <template v-if="currentProcess === 3">
                  <div v-html="$t('sectionThree.contentThreeTitle')"></div>
                  <div v-html="$t('sectionThree.contentThreeText')"></div>
                </template>
                <template v-if="currentProcess === 4">
                  <div v-html="$t('sectionThree.contentFourTitle')"></div>
                  <div v-html="$t('sectionThree.contentFourText')"></div>
                </template>
                <template v-if="currentProcess === 5">
                  <div v-html="$t('sectionThree.contentFiveTitle')"></div>
                  <div v-html="$t('sectionThree.contentFiveText')"></div>
                </template>
              </div>
            </div>
            <div class="nextPage">
              <span class="index">05</span>
              /
              <span class="total">06</span>
              <span class="name">{{ $t("home.playText") }}</span>
              <span class="link cursor-btn" @click="gotonextpage">{{
                $t("home.nextText")
              }}</span>
            </div>
          </div>
        </div>
        <point-wave :num="3"/>
      </div>
      <div class="section position-relative">
        <div class="nav-humber">
          <div class="container d-flex justify-content-between">
            <div>{{ $t("home.playText") }}</div>
            <div></div>
          </div>
        </div>
        <div class="position-absolute">
          <div
            class="container d-flex justify-content-between align-items-center"
          >
            <div class="prevPage">
              <span class="link cursor-btn" @click="gotoprevpage">{{
                $t("home.prevText")
              }}</span>
              <span class="name">{{ $t("home.planText") }}</span>
              <span class="index">04</span>
              /
              <span class="total">06</span>
            </div>
            <div>
              <div class="d-flex justify-content-between">
                <div class="carousel-arrow d-flex">
                  <div
                    @click="cardPrev"
                    class="carousel-arrow-left text-center cursor-btn"
                  >
                    <i class="iconfont">&#xe603;</i>
                  </div>
                  <div
                    @click="cardNext"
                    class="carousel-arrow-right text-center cursor-btn"
                  >
                    <i class="iconfont">&#xe602;</i>
                  </div>
                </div>
                <div class="carousel-indicate d-flex align-items-center">
                  <div
                    v-for="(item, index) in 4"
                    :key="index"
                    class="cursor-btn"
                    :class="currentCard === index ? 'active' : ''"
                    @click="changeCard(index)"
                  ></div>
                </div>
              </div>
              <el-carousel
                trigger="click"
                height="330px"
                :autoplay="false"
                arrow="never"
                indicator-position="none"
                ref="cardShow"
                @change="getCard"
              >
                <el-carousel-item v-for="(item, index) in imgData" :key="index">
                  <div
                    v-for="(item2, index2) in item.imgList"
                    :key="index2"
                    class="cursor-btn"
                  >
                    <img v-lazy="item2" :key="item2" />
                  </div>
                </el-carousel-item>
              </el-carousel>
            </div>
            <div class="nextPage">
              <span class="index">06</span>
              /
              <span class="total">06</span>
              <span class="name">{{ $t("home.linkText") }}</span>
              <span class="link cursor-btn" @click="gotonextpage">{{
                $t("home.nextText")
              }}</span>
            </div>
          </div>
        </div>
        <point-wave :num="4"/>
      </div>
      <div class="section position-relative">
        <div class="nav-humber">
          <div class="container d-flex justify-content-between">
            <div>{{ $t("home.linkText") }}</div>
            <div></div>
          </div>
        </div>
        <div class="position-absolute">
          <div
            class="container d-flex justify-content-between align-items-center"
          >
            <div class="prevPage">
              <span class="link cursor-btn" @click="gotoprevpage">{{
                $t("home.prevText")
              }}</span>
              <span class="name">{{ $t("home.playText") }}</span>
              <span class="index">05</span>
              /
              <span class="total">06</span>
            </div>
            <div>
              <div class="d-flex">
                <div>
                  <p class="font-weight-bold">
                    {{ $t("sectionFive.customerText") }}
                  </p>
                  <p>services@waltonchain.org</p>
                </div>
                <div>
                  <p class="font-weight-bold">
                    {{ $t("sectionFive.mediaText") }}
                  </p>
                  <p>info@waltonchain.org</p>
                </div>
                <div>
                  <p class="font-weight-bold">
                    {{ $t("sectionFive.onlineText") }}
                  </p>
                  <p>smn@waltonchain.org</p>
                </div>
                <div>
                  <p class="font-weight-bold">
                    {{ $t("sectionFive.businessText") }}
                  </p>
                  <p>business@waltonchain.org</p>
                </div>
              </div>
              <div class="leave-btn cursor-btn position-relative">
                {{ $t("sectionFive.leaveText") }}
                <i class="iconfont">&#xe61a;</i>
              </div>
              <div class="d-flex">
                <div class="text-center cursor-btn">
                  <i class="iconfont">&#xe600;</i>
                  <p>{{ $t("sectionFive.twitterText") }}</p>
                </div>
                <div class="text-center cursor-btn">
                  <i class="iconfont">&#xe667;</i>
                  <p>{{ $t("sectionFive.redditText") }}</p>
                </div>
                <div class="text-center cursor-btn">
                  <i class="iconfont">&#xe62d;</i>
                  <p>{{ $t("sectionFive.teleText") }}</p>
                </div>
                <div class="text-center cursor-btn">
                  <i class="iconfont">&#xe6a7;</i>
                  <p>{{ $t("sectionFive.mText") }}</p>
                </div>
                <div class="text-center cursor-btn">
                  <i class="iconfont iconyoutube"></i>
                  <p>{{ $t("sectionFive.tubeText") }}</p>
                </div>
              </div>
            </div>
            <div class="nextPage"></div>
          </div>
        </div>
        <point-wave :num="5"/>
      </div>
    </full-page>
  </div>
</template>
<script>
import { mapState, mapGetters, mapMutations } from "vuex";
import PointWave from "@/components/PointWave/index.vue";
import CommonHeader from "@/components/common/CommonHeader.vue";
export default {
  name: "Home",
  components: {
    PointWave,
    CommonHeader,
  },
  data() {
    return {
      currentSection: 0,
      currentTab: 0,
      currentProcess: 1,
      currentCard: 0,
      options: {
        licenseKey: "OPEN-SOURCE-GPLV3-LICENSE",
        afterLoad: this.afterLoad,
        lockAnchors: true,
        anchors: ["page1", "page2", "page3", "page4", "page5", "page6"],
        normalScrollElements: ".tab-content",
      },
      imgData: [
        {
          imgList: [
            "http://www.waltonchain.org/en/Uploads/2019-05-31/5cf12abfab4ae.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-18/5c18cae0bff10.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-18/5c18cb1403266.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-18/5c18cb22d8971.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-10/5c0e09ccc9bbd.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-10/5c0e494f57642.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-10/5c0e495206c58.jpg",
            "http://www.waltonchain.org/en/Uploads/2020-09-14/5f5f1eb16b5d2.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c136810dc678.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c136829a1a13.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c13683a04393.jpg",
            "http://www.waltonchain.org/en/Uploads/2019-11-19/5dd3c63703488.png",
          ],
        },
        {
          imgList: [
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c1368476beee.jpg",
            "http://www.waltonchain.org/en/Uploads/2019-11-27/5dddebe24ee71.png",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c13687a00e23.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c13688886c70.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c13689c35a13.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c1368ae657af.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c1368c4a1f4d.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c1368dfc20d1.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c136901bf59f.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c13691adbb48.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c13693e19ff5.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c13694dcf866.jpg",
          ],
        },
        {
          imgList: [
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c136966cb495.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-17/5c174a746ea05.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c1369ad8b804.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c1369bf29ff5.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c1369d5c9f0f.jpg",
            "http://www.waltonchain.org/en/Uploads/2019-09-09/5d75ed99dbad3.jpg",
            "http://www.waltonchain.org/en/Uploads/2018-12-14/5c136a15a3796.jpg",
            "http://www.waltonchain.org/en/Uploads/2020-05-14/5ebd0a46d39ad.jpg",
            "http://www.waltonchain.org/en/Uploads/2020-05-14/5ebd0aa1aee92.jpg",
            "http://www.waltonchain.org/en/Uploads/2020-05-14/5ebd0adee94f2.jpg",
            "http://www.waltonchain.org/en/Uploads/2020-05-14/5ebd0af67aca7.jpg",
            "http://www.waltonchain.org/en/Uploads/2020-05-14/5ebd0a59cf7fc.jpg",
          ],
        },
        {
          imgList: [
            "http://www.waltonchain.org/en/Uploads/2020-06-15/5ee722400d122.jpg",
            "http://www.waltonchain.org/en/Uploads/2020-06-15/5ee71b590875e.jpg",
            "http://www.waltonchain.org/en/Uploads/2020-07-27/5f1e931701ce4.jpg",
            "http://www.waltonchain.org/en/Uploads/2020-07-27/5f1e932e24629.jpg",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
          ],
        },
      ],
    };
  },
  computed: {
    ...mapGetters(["sectionIndex"]),
  },
  methods: {
    ...mapMutations(["SET_SECTIONINDEX"]),
    //回到顶部
    backTop() {
      this.gotopage(0);
    },
    //获取幻灯片索引
    getCard(index) {
      this.currentCard = index;
    },
    //手动触发幻灯片切换
    changeCard(index){
      this.$refs.cardShow.setActiveItem(index)
    },
    //前一个幻灯片
    cardPrev() {
      this.$refs.cardShow.prev();
    },
    //后一个幻灯片
    cardNext() {
      this.$refs.cardShow.next();
    },
    //关闭Tab内容
    closeTabContent() {
      this.currentTab = 0;
    },
    //获取Tab内容
    getTabContent(tabNum) {
      this.currentTab = tabNum;
    },
    //获取Process内容
    getProcessContent(processNum) {
      this.currentProcess = processNum;
    },
    //切换Section模块
    changeSection(index) {
      this.currentSection = index;
      this.gotopage(index);
    },
    //跳转前一个Section模块
    gotoprevpage() {
      fullpage_api.moveSectionUp();
    },
    //跳转后一个Section模块
    gotonextpage() {
      fullpage_api.moveSectionDown();
    },
    //跳转指定Section模块
    gotopage(index) {
      fullpage_api.moveTo("page" + (index + 1), 1);
    },
    afterLoad(anchorLink, index) {
      console.log("index:", index.index);
      this.currentSection = index.index;
      this.SET_SECTIONINDEX(index.index);
    },
    next() {
      // 向下滚动一页
      this.$refs.fullpage.api.moveSectionDown();
    },
  },
};
</script>
<style lang="scss" scoped>
.home {
  #fullpage {
    .section {
      background-color: #100619;
      background-size: cover;
      .container {
        max-width: 1640px;
      }
      div.navs-text {
        font-size: 80px;
        line-height: 100px;
        color: #fff;
        letter-spacing: 5px;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
      }
      .tab-content {
        height: 350px;
        padding: 0px 30px;
        overflow-y: auto;
        max-width: 900px;
        margin: 0px auto;
        font-size: 14px;
        margin-top: 25px;
        transition: 0.9s ease;
        transform: translateY(0);
        opacity: 1;
      }
      .nav-humber {
        color: #fff;
        font-size: 36px;
        height: 140px;
        line-height: 140px;
        border-bottom: 1px solid rgba(153, 153, 153, 0.23);
        & + div {
          color: #fff;
          width: 100%;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          z-index: 999;
          .container {
            & > div {
              &:nth-of-type(2) {
                max-width: 580px;
              }
              span {
                &.total {
                  padding: 0px 5px;
                }
                &.index {
                  padding: 0px 5px;
                  color: #8200ff;
                }
                &.name {
                  padding: 0px 12px;
                }
              }
            }
          }
        }
      }
      .nav-video {
        font-size: 14px;
        text-indent: 608px;
        color: #00ffda;
        &:hover {
          color: #fff;
        }
      }
      &:nth-of-type(3) {
        div.split-line {
          width: 100%;
          height: 1px;
          background-color: #333;
          box-shadow: 4px -13px 60px 8px #333;
          top: 415px;
          z-index: 1;
        }
        div.close-btn {
          width: 48px;
          height: 48px;
          border-radius: 50%;
          padding: 10px 16px;
          background-color: #322641;
          left: 50%;
          top: 390px;
          transform: translateX(-50%);
          z-index: 9999;
          i {
            color: #8200ff;
            font-size: 42px;
            margin-top: -17px;
            margin-left: -12px;
            display: inline-block;
          }
        }
        .nav-humber {
          & + div {
            .container {
              & > div {
                &:nth-of-type(2) {
                  max-width: 980px;
                  margin: 100px auto 30px;
                  & > div {
                    width: 306px;
                    p {
                      color: #888;
                      margin: 20px 0px 30px;
                      font-size: 18px;
                    }
                    img + div {
                      font-size: 14px;
                    }
                  }
                }
              }
            }
          }
        }
      }
      &:nth-of-type(4) {
        .nav-humber {
          & + div {
            z-index: 2;
            .container {
              & > div {
                &:nth-of-type(2) {
                  max-width: 980px;
                  .process-tabs {
                    margin: 50px auto;
                    & > div {
                      min-width: 196px;
                      div.circle {
                        width: 10px;
                        height: 10px;
                        border-radius: 50%;
                        background: #8b8b8b;
                        margin: 26px auto 18px;
                      }
                      p {
                        &:first-of-type {
                          font-size: 16px;
                        }
                        &:last-of-type {
                          font-size: 30px;
                        }
                      }
                      &:hover div.circle {
                        background: #00ffda;
                      }
                      &:hover p {
                        color: #00ffda;
                      }
                    }
                  }
                }
              }
            }
          }
        }
        &::after {
          content: "";
          position: absolute;
          width: 100%;
          height: 0;
          border-bottom: 1px dashed rgba(130, 0, 255, 0.75);
          position: absolute;
          top: 343px;
          z-index: 1;
          opacity: 0.8;
        }
      }
      &:nth-of-type(5) {
        .nav-humber {
          & + div {
            .container {
              & > div {
                &:nth-of-type(2) {
                  width: 700px;
                  max-width: 700px;
                  &::after {
                    content: "";
                    width: 700px;
                    position: absolute;
                    border-bottom: 1px solid #333;
                    bottom: 0px;
                  }
                }
                .carousel-arrow {
                  margin-bottom: 10px;
                  & > div {
                    background: rgb(34, 34, 34);
                    width: 36px;
                    height: 25px;
                    border-radius: 20px;
                    margin-right: 20px;
                    i {
                      font-size: 20px;
                      color: #666;
                      font-weight: bold;
                      display: inline-block;
                      margin-top: -2px;
                    }
                  }
                }
                .carousel-indicate {
                  margin-bottom: 10px;
                  & > div {
                    width: 8px;
                    height: 8px;
                    border-radius: 50%;
                    background: rgb(33, 28, 28);
                    &.active {
                      background: rgb(102, 102, 102);
                    }
                    &:not(:last-of-type) {
                      margin-right: 8px;
                    }
                  }
                }
                /deep/ .el-carousel__item {
                  background: #000;
                  display: flex;
                  flex-wrap: wrap;
                  & > div {
                    width: 25%;
                    height: 110px;
                    border-top: 1px solid #333;
                    border-left: 1px solid #333;
                    &:nth-of-type(4),
                    &:nth-of-type(8),
                    &:nth-of-type(12) {
                      border-right: 1px solid #333;
                    }
                  }
                  img {
                    width: 173px;
                    filter: opacity(0.5);
                    &:hover {
                      transform: scale(0.9);
                    }
                  }
                }
              }
            }
          }
        }
      }
      &:nth-of-type(6) {
        .nav-humber {
          & + div {
            .container {
              & > div {
                &:nth-of-type(2) {
                  max-width: 750px;
                  margin: 0 auto;
                  & > div {
                    &:first-of-type {
                      flex-wrap: wrap;
                      & > div {
                        width: 360px;
                        p {
                          &:first-of-type {
                            font-size: 14px;
                            color: #8200ff;
                            margin: 0px;
                          }
                          &:last-of-type {
                            color: #555;
                            font-size: 14px;
                            margin-bottom: 30px;
                          }
                        }
                      }
                    }
                    &.leave-btn {
                      width: 130px;
                      height: 44px;
                      font-size: 18px;
                      background: #8200ff;
                      border-radius: 30px;
                      line-height: 44px;
                      margin: 30px 0px 80px;
                      padding-left: 55px;
                      i {
                        position: absolute;
                        font-size: 20px;
                        left: 25px;
                      }
                      & + div {
                        & > div {
                          &:not(:last-of-type) {
                            margin-right: 100px;
                          }
                          &:hover i {
                            display: inline-block;
                            transform: scale(0.9);
                            color: #00ffda;
                          }
                        }
                        i {
                          font-size: 35px;
                          color: #8200ff;
                        }
                        p {
                          color: #999;
                          font-size: 14px;
                          margin-top: 10px;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  .process-text {
    max-width: 550px;
    min-height: 240px;
    margin: 0px auto;
    padding: 30px;
    border-radius: 30px;
    background-color: rgba(130, 0, 255, 0.8);
    font-size: 14px;
    h4 {
      font-size: 16px;
    }
  }
  .scroll-items {
    width: 100%;
    bottom: 20px;
    z-index: 30;
    & > a {
      display: inline-block;
      width: calc((100% - 20px) / 6);
      height: 5px;
      background-color: #353535;
      &.active {
        background: #595959;
      }
      &:not(:first-of-type) {
        margin-left: 4px;
      }
    }
  }
  .button-mouse {
    position: absolute;
    width: 30px;
    height: 42px;
    bottom: 60px;
    left: 50%;
    margin-left: -12px;
    border-radius: 15px;
    border: 2px solid rgba(255, 255, 255, 0.5);
    animation: intro 1s;
    z-index: 99;
    .scroll {
      display: block;
      width: 3px;
      height: 8px;
      margin: 6px auto;
      border-radius: 4px;
      background: rgba(255, 255, 255, 0.5);
      animation: finger 1.2s infinite;
      z-index: 99;
    }
  }
  @keyframes intro {
    0% {
      opacity: 0;
      transform: translateY(40px);
    }
    100% {
      opacity: 1;
      transform: translateY(0);
    }
  }
  @keyframes finger {
    0% {
      opacity: 1;
    }
    100% {
      opacity: 0;
      transform: translateY(20px);
    }
  }
}
</style>