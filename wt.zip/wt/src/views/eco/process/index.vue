<template>
  <div class="process">
    <div class="process-head">
      <div>Waltonchain Business Process</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span class="currentRoute">Business Process</span>
        </div>
      </div>
    </div>
    <div class="process-content">
      <div class="container">
        <div>
          <img src="@/assets/images/eco/process/img_1.jpg" alt="" />
        </div>
        <div>
          <img src="@/assets/images/eco/process/img_2.png" alt="" />
        </div>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
export default {
  name: "Process",
};
</script>
<style lang="scss" scoped>
.process {
  .process-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 180px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &:first-of-type {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .process-content {
    padding: 50px 0px;
    img {
      max-width: 100%;
    }
  }
}
</style>