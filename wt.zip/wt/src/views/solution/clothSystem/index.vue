<template>
  <div class="clothSystem">
    <div class="clothSystem-head">
      <div>Blockchain + Clothing Industry Solution</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span class="currentRoute">Clothing Industry Solution</span>
        </div>
      </div>
    </div>
    <common-nav :navList="navList" :pageType="1" pageName="clothSystem" />
    <div class="traceAgriculture-content">
      <div class="traceAgriculture-icons">
        <div class="container d-flex justify-content-between">
          <div>
            <div class="icon">
              <img
                v-lazy="
                  'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b488299b2e.png'
                "
                :key="'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b488299b2e.png'"
              />
            </div>
            <div class="icon-text">Smart store</div>
          </div>
          <div>
            <div class="icon">
              <img
                v-lazy="
                  'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b4889dc736.png'
                "
                :key="'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b4889dc736.png'"
              />
            </div>
            <div class="icon-text">Big data uploading to blockchain</div>
          </div>
          <div>
            <div class="icon">
              <img
                v-lazy="
                  'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b488f96f35.png'
                "
                :key="'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b488f96f35.png'"
              />
            </div>
            <div class="icon-text">Luxury goods authentication</div>
          </div>
        </div>
      </div>
      <div class="introduction" id="introduction">
        <div class="container">
          <div class="content-title">WTC-Garment System</div>
          <div>
            <div
              class="introduction-cells justify-content-between d-flex flex-wrap"
            >
              <div>Full intelligentization of the management process</div>
              <div>Immersive shopping experience</div>
              <div>Brand value maintenance via authentication</div>
              <div>Enrichment of consumer profiles</div>
            </div>
            <div class="d-flex justify-content-center">
              <img
                v-lazy="
                  'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b48a90a6fb.jpg'
                "
                :key="'http://www.waltonchain.org/en/Uploads/2018-12-08/5c0b48a90a6fb.jpg'"
              />
            </div>
          </div>
        </div>
      </div>
      <div class="presentation" id="presentation">
        <div class="container">
          <div class="content-title">Case Presentation</div>
          <div class="presentation-media d-flex">
            <div class="position-relative col-md-7">
              <img
                src="@/assets/images/solution/foodSystem/img_media.jpg"
                alt=""
              />
              <div class="position-absolute cursor-btn">
                <div>
                  <img
                    src="@/assets/images/solution/foodSystem/img_video.png"
                    alt=""
                  />
                </div>
                <div>Watch a Video</div>
              </div>
            </div>
            <div class="col-md-5">
              <div class="font-weight-bold">
                Having trouble with long and costly supply chains?
              </div>
              <div>
                <p>
                  Unable to control various SKUs and error rate in logistics and
                  warehousing?
                </p>
                <p>
                  The world’s first blockchain-based clothing authenticity
                  system WTC-Garment by Waltonchain is applied to all links of
                  the clothing industry, such as supply chain optimization,
                  warehousing and logistics management, and consumer big data
                  extraction to fundamentally solve the common industry pain
                  points.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <el-backtop></el-backtop>
  </div>
</template>

<script>
import CommonNav from "@/components/common/CommonNav.vue";
export default {
  components: { CommonNav },
  name: "ClothSystem",
  data() {
    return {
      navList: [
        {
          name: "System Introduction",
          id: "introduction",
        },
        {
          name: "Case Presentation",
          id: "presentation",
        },
      ],
    };
  },
};
</script>
<style lang="scss" scoped>
.clothSystem {
  .clothSystem-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 180px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &:first-of-type {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .commonNav {
    /deep/ .nav {
      background: url("../../../assets/images/common/bg_nav.jpg") no-repeat;
      background-size: cover;
      box-shadow: 2.5px 4.33px 13px 0px rgba(0, 0, 0, 0.24);
      height: 170px;
    }
    /deep/ .container.position-relative {
      & > div {
        height: 55px;
      }
      line-height: 55px;
      & > div {
        width: 50%;
      }
    }
  }
  .traceAgriculture-content {
    padding: 80px 0px;
    & > div {
      .container {
        padding: 0px;
      }
      .content-title {
        font-size: 28px;
        color: #8200ff;
        font-weight: 600;
        margin-bottom: 20px;
      }
      p,
      div {
        font-size: 14px;
        color: #555;
        margin-bottom: 30px;
        line-height: 30px;
      }

      &.introduction {
        margin-top: 60px;
        .content-title + div {
          padding: 50px;
          border-radius: 30px;
          overflow: hidden;
          box-shadow: 5.5px 9.526px 59px 0px rgba(0, 0, 0, 0.24);
        }
        .introduction-cells {
          font-size: 14px;
          & > div {
            color: #8200ff;
            width: 510px;
            height: 40px;
            text-align: center;
            line-height: 40px;
            border: 1px solid #8200ff;
            margin-bottom: 10px;
          }
          & + div {
            margin-top: 30px;
          }
        }
      }
      &.presentation {
        padding: 80px 0px;
        background: url("../../../assets/images/solution/traceSystem/bg_presentation.jpg")
          no-repeat;
        background-size: cover;
        .content-title {
          margin-bottom: 60px;
        }
      }
      .presentation-media {
        & > div {
          padding: 0px;
          &:first-of-type {
            border-radius: 10px;
            &::before {
              content: "";
              position: absolute;
              top: 0;
              left: 0;
              height: 100%;
              width: 100%;
              background: rgba(0, 0, 0, 0.7);
              border-radius: 10px;
            }
            img {
              max-width: 100%;
              border-radius: 10px;
            }
            & > div {
              top: 50%;
              left: 50%;
              transform: translate(-50%, -50%);
              margin-bottom: 0px;
              & > div {
                text-align: center;
                color: #fff;
                font-size: 16px;
                margin-bottom: 0px;
                img {
                  margin-bottom: 8px;
                }
              }
            }
          }
          &:last-of-type {
            padding: 60px 40px 0px;
            div {
              font-size: 24px;
              margin-bottom: 5px;
            }
            p {
              font-size: 14px;
              margin-bottom: 0px;
            }
          }
        }
      }
      &.traceAgriculture-icons {
        padding: 0px;
        margin-bottom: 60px;
        .icon-text {
          font-size: 22px;
          font-weight: 600;
          color: #000;
        }
        .container {
          div {
            text-align: center;
            &:not(.icon) {
              margin-bottom: 0px;
            }
          }
        }
      }
    }
  }
}
</style>