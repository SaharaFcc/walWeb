const state = {
    lang: 'EN',
    showSwitch: false,
    sectionIndex: 0,
    commonLink: 'http://www.waltonchain.org/'
}
export default state