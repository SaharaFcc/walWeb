<template>
  <div id="app">
    <router-view/>
  </div>
</template>
<script>
import '@/assets/css/App.scss'
import '@/assets/css/loading.scss'
export default {
  name: 'App'
}
</script>
