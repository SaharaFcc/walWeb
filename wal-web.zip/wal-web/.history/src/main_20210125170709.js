import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import '@/icons'

import VueFullpage from 'vue-fullpage.js'
Vue.use(VueFullpage)

import { Icon,Backtop } from 'element-ui'
Vue.use(Icon)
Vue.use(Backtop)

import axios from 'axios'
Vue.prototype.$axios = axios

import VueParticles from 'vue-particles'
Vue.use(VueParticles)

import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.min.js'
import 'bootstrap/dist/js/bootstrap.bundle.min.js'

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
