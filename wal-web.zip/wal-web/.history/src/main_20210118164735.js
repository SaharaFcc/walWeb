import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import '@/icons'

import VueFullpage from 'vue-fullpage.js'
import 'fullpage.js/vendors/fullpage.min.css'
Vue.use(VueFullpage)

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
