import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('../views/Home.vue')
  },
  {
    path: '/wta',
    component: () => import('@/views/wta/index.vue'),
    children: [
      {
        path: 'bluePaper',
        name: 'BluePaper',
        component: () => import('@/views/wta/bluePaper/index.vue')
      },
      {
        path: 'appDownload',
        name: 'AppDownload',
        component: () => import('@/views/wta/appDownload/index.vue')
      }
    ]
  },
  {
    path: '/solution',
    component: () => import('@/views/solution/index.vue'),
    children: [
      {
        path: 'traceSystem',
        name: 'TraceSystem',
        component: () => import('@/views/solution/traceSystem/index.vue')
      },
      {
        path: 'collectSystem',
        name: 'CollectSystem',
        component: () => import('@/views/solution/collectSystem/index.vue')
      },
      {
        path: 'infoSystem',
        name: 'InfoSystem',
        component: () => import('@/views/solution/infoSystem/index.vue')
      },
      {
        path: 'foodSystem',
        name: 'FoodSystem',
        component: () => import('@/views/solution/foodSystem/index.vue')
      },
      {
        path: 'clothSystem',
        name: 'ClothSystem',
        component: () => import('@/views/solution/clothSystem/index.vue')
      }
    ]
  },
  // {
  //   path: '/ecoKirin',
  //   name: 'EcoKirin',
  //   component: () => import('../views/ecoKirin/index.vue')
  // },
  // {
  //   path: '/ecoSmn',
  //   name: 'EcoSmn',
  //   component: () => import('../views/ecoSmn/index.vue')
  // },
  // {
  //   path: '/ecoChain',
  //   name: 'EcoChain',
  //   component: () => import('../views/ecoChain/index.vue')
  // },
  // {
  //   path: '/ecoProcess',
  //   name: 'EcoProcess',
  //   component: () => import('../views/ecoProcess/index.vue')
  // },
  {
    path: '/whitePaper',
    name: 'WhitePaper',
    component: () => import('../views/whitePaper/index.vue')
  },
  {
    path: '/appPolicy',
    name: 'AppPolicy',
    component: () => import('../views/appPolicy/index.vue')
  },
  {
    path: '/walletPolicy',
    name: 'WalletPolicy',
    component: () => import('../views/walletPolicy/index.vue')
  },
  {
    path: '/useTerm',
    name: 'UseTerm',
    component: () => import('../views/useTerm/index.vue')
  },
  {
    path: '/summaryPolicy',
    name: 'SummaryPolicy',
    component: () => import('../views/summaryPolicy/index.vue')
  },
  {
    path: '/about',
    name: 'About',
    component: () => import('../views/About.vue')
  }
]

const router = new VueRouter({
  routes
})

export default router
