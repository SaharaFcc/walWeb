import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('../views/Home.vue')
  },
  {
    path: '/bluePaper',
    name: 'BluePaper',
    component: () => import('../views/bluePaper')
  },
  {
    path: '/appDownload',
    name: 'AppDownload',
    component: () => import('../views/appDownload')
  },
  {
    path: '/traceSystem',
    name: 'TraceSystem',
    component: () => import('../views/traceSystem')
  },
  {
    path: '/traceCloud',
    name: 'TraceCloud',
    component: () => import('../views/traceCloud')
  },
  {
    path: '/traceWarrant',
    name: 'TraceWarrant',
    component: () => import('../views/traceWarrant')
  },
  {
    path: '/traceAgriculture',
    name: 'TraceAgriculture',
    component: () => import('../views/traceAgriculture')
  },
  {
    path: '/about',
    name: 'About',
    component: () => import('../views/About.vue')
  }
]

const router = new VueRouter({
  routes
})

export default router
