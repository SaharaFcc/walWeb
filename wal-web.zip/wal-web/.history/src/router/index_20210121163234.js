import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('../views/Home.vue')
  },
  {
    path: '/wta',
    component: () => import('@/views/wta/index.vue'),
    children: [
      {
        path: 'bluePaper',
        name: 'BluePaper',
        component: () => import('@/views/wta/bluePaper/index.vue')
      },
      {
        path: 'appDownload',
        name: 'AppDownload',
        component: () => import('@/views/wta/appDownload/index.vue')
      }
    ]
  },
  {
    path: '/traceSystem',
    name: 'TraceSystem',
    component: () => import('../views/traceSystem/index.vue')
  },
  {
    path: '/traceCloud',
    name: 'TraceCloud',
    component: () => import('../views/traceCloud/index.vue')
  },
  {
    path: '/traceWarrant',
    name: 'TraceWarrant',
    component: () => import('../views/traceWarrant/index.vue')
  },
  {
    path: '/traceAgriculture',
    name: 'TraceAgriculture',
    component: () => import('../views/traceAgriculture/index.vue')
  },
  {
    path: '/traceCloth',
    name: 'TraceCloth',
    component: () => import('../views/traceCloth/index.vue')
  },
  {
    path: '/ecoKirin',
    name: 'EcoKirin',
    component: () => import('../views/ecoKirin/index.vue')
  },
  {
    path: '/ecoSmn',
    name: 'EcoSmn',
    component: () => import('../views/ecoSmn/index.vue')
  },
  {
    path: '/ecoChain',
    name: 'EcoChain',
    component: () => import('../views/ecoChain/index.vue')
  },
  {
    path: '/ecoProcess',
    name: 'EcoProcess',
    component: () => import('../views/ecoProcess/index.vue')
  },
  {
    path: '/whitePaper',
    name: 'WhitePaper',
    component: () => import('../views/whitePaper/index.vue')
  },
  {
    path: '/appPolicy',
    name: 'AppPolicy',
    component: () => import('../views/appPolicy/index.vue')
  },
  {
    path: '/walletPolicy',
    name: 'WalletPolicy',
    component: () => import('../views/walletPolicy/index.vue')
  },
  {
    path: '/useTerm',
    name: 'UseTerm',
    component: () => import('../views/useTerm/index.vue')
  },
  {
    path: '/summaryPolicy',
    name: 'SummaryPolicy',
    component: () => import('../views/summaryPolicy/index.vue')
  },
  {
    path: '/about',
    name: 'About',
    component: () => import('../views/About.vue')
  }
]

const router = new VueRouter({
  routes
})

export default router
