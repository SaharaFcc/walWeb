<template>
  <div id="app">
    <router-view/>
  </div>
</template>
<script>
import '@/assets/css/App.scss'
export default {
  name: 'App'
}
</script>
