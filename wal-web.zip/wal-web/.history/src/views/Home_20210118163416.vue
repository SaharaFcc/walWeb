<template>
  <div class="home">
    <full-page :options="options" ref="fullpage">
      <div class="section">
        page1
      </div>
      <div class="section">
        page2
      </div>
      <div class="section">
        page3
      </div>
    </full-page>
  </div>
</template>
<script>
export default {
  name: "Home",
  data() {
    return {
      options: {
        licenseKey: "OPEN-SOURCE-GPLV3-LICENSE",
        //是否显示导航，默认为false
        navigation: true,
        anchors: ['page1', 'page2', 'page3', 'page4'],
        //为每个section设置背景色
        // sectionsColor: [
        //   "#41b883",
        //   "#ff5f45",
        //   "#0798ec",
        //   "#fec401",
        //   "#1bcee6",
        //   "#ee1a59",
        //   "#2c3e4f",
        //   "#ba5be9",
        //   "#b4b8ab",
        // ],
      },
    };
  },
  components: {},
  methods: {
    next() {
      // 向下滚动一页
      this.$refs.fullpage.api.moveSectionDown();
    },
  },
};
</script>
<style lang="scss" scoped></style>
