<template>
  <div class="home wrap">
    <svg-icon iconClass="application" className="application_icon"/>
  </div>
</template>
<script>
export default {
  name: "Home",
  components: {},
};
</script>
<style lang="scss" scoped>
.fullscreen_icon{
  width: 100px;
  height: 100px;
}
.fullscreen_icon:hover{
  color: red;
  transition: all 3s;
}
</style>
