<template>
  <div class="home">
    <svg-icon iconClass="bubble" className="bubble"/>
  </div>
</template>
<script>
export default {
  name: 'Home',
  components: {}
}
</script>
