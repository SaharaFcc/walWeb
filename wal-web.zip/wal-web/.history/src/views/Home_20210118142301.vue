<template>
  <div class="home wrap">
    <svg-icon iconClass="bubble"/>
  </div>
</template>
<script>
export default {
  name: "Home",
  components: {},
};
</script>
