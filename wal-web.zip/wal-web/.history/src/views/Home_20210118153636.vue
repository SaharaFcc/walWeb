<template>
  <div class="home">
    <div class="fullPage" ref="fullPage">
      <div
        class="fullPageContainer"
        ref="fullPageContainer"
        @mousewheel="mouseWheelHandle"
        @DOMMouseScroll="mouseWheelHandle"
      >
        <div class="section section1">1</div>
        <div class="section section2">2</div>
        <div class="section section3">3</div>
        <div class="section section4">4</div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "Home",
  data(){
    return{
      fullpage: {
        current: 1,
        isScrolling: false,
        deltaY: 0
      }
    }
  },
  components: {},
  methods: {
    next(){
      
    }
  }
};
</script>
