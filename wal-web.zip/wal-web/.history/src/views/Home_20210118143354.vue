<template>
  <div class="home wrap">
    <svg-icon iconClass="bubble" className="icon"/>
  </div>
</template>
<script>
export default {
  name: "Home",
  components: {},
};
</script>
<style lang="scss" scoped>
.icon{
  width: 100px;
  height: 100px;
  color: red;
}
</style>
