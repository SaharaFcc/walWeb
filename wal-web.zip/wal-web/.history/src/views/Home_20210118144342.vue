<template>
  <div class="home wrap">
    <svg-icon iconClass="bubble" className="bubble_icon"/>
  </div>
</template>
<script>
export default {
  name: "Home",
  components: {},
};
</script>
<style lang="scss" scoped>
.bubble_icon{
  width: 100px;
  height: 100px;
  // color: red;
}
</style>
