<template>
  <div class="appDownload">
      <div class="appDownload-head"></div>
  </div>
</template>

<script>
export default {
  name: "AppDownload",
};
</script>