<template>
  <div class="appDownload">
    <div class="appDownload-head">
      <div>App Download</div>
      <div>
        <div>
          <i class="el-icon el-icon-location-outline"></i>
        </div>
        <div>
          <a>Home</a>
          <span class="splitLine">/</span>
          <span>WTA(Blue Paper)</span>
          <span class="splitLine">/</span>
          <span class="currentRoute"
            >Waltonchain Global Community Autonomy Blue Paper</span
          >
        </div>
      </div>
    </div>
    <common-nav :navList="navList" />
  </div>
</template>

<script>
import CommonNav from "@/components/common/CommonNav.vue";
export default {
  components: {
    CommonNav,
  },
  name: "AppDownload",
  data() {
    return {
      navList: [
        {
          name: "Android",
          id: "",
        },
        {
          name: "iOS",
          id: "",
        },
      ],
    };
  },
};
</script>
<style lang="scss" scoped>
.appDownload {
  .appDownload-head {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 180px;
    background: #000;
    text-align: center;
    & > div {
      display: flex;
      &:first-of-type {
        color: #8200ff;
        font-size: 35px;
        font-weight: 600;
        margin-bottom: 25px;
      }
      &:last-of-type {
        font-size: 14px;
        color: #8200ff;
        span {
          &.splitLine {
            margin: 0px 8px;
          }
          &.currentRoute {
            color: #fff;
          }
        }
      }
      i {
        font-size: 18px;
        margin-right: 8px;
      }
    }
  }
  .commonNav {
    /deep/ .nav {
      background: url("../../assets/images/common/bg_nav.jpg") no-repeat;
      background-size: cover;
      box-shadow: 2.5px 4.33px 13px 0px rgba(0, 0, 0, 0.24);
      height: 170px;
    }
    /deep/ .container {
      & > div {
        height: 55px;
      }
      line-height: 55px;
      & > div {
        width: 228px;
      }
    }
  }
}
</style>