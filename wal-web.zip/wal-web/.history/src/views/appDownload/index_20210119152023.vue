<template>
  <div class="appDownload">
      
  </div>
</template>

<script>
export default {
  name: "AppDownload",
};
</script>