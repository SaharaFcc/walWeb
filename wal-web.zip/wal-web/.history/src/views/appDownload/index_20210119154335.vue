<template>
  <div class="appDownload">
    <div class="appDownload-head"></div>
    <common-nav />
  </div>
</template>

<script>
import CommonNav from "@/components/common/CommonNav.vue";
export default {
  components: {
    CommonNav,
  },
  name: "AppDownload",
  data() {
    return {
      navList: [
        {
          name: "Android"
        },
      ],
    };
  },
};
</script>