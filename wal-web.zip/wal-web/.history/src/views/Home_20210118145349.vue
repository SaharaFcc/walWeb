<template>
  <div class="home wrap">
    <svg-icon iconClass="bubble" className="bubble_icon"/>
  </div>
</template>
<script>
export default {
  name: "Home",
  components: {},
};
</script>
<style lang="scss" scoped>
.bubble_icon{
  width: 100px;
  height: 100px;
  // color: red;
}
@-webkit-keyframes el_P7pZskq9FM_BHhscBjTM_Animation{ 
  10%{ 
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 0px);
  }
  30%{ 
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 10px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 10px);
  }
  50%{ 
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 0px);
  }
  70%{ 
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 0px);
  }
  100%{ 
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 0px);
  }
}
@keyframes el_P7pZskq9FM_BHhscBjTM_Animation{ 
  10%{ 
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 0px);
  }
  30%{ 
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 10px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 10px);
  }
  50%{ 
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 0px);
  }
  70%{ 
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 0px);
  }
  100%{ 
    -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 0px);
    transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 0px);
  }
}
.svgHover *{ 
  -webkit-animation-duration: 1s;
  animation-duration: 1s;
  -webkit-animation-play-state: running;
  animation-play-state: running;
  -webkit-animation-timing-function: cubic-bezier(0, 0, 1, 1);
  animation-timing-function: cubic-bezier(0, 0, 1, 1);
}
#el_QLJEshgSMh{ 
  fill: #8200FF;
}
#el_cc3JkLAXIf{ 
  fill: #00FFDA;
}
#el_P7pZskq9FM{ 
  fill: #8200FF;
}
#el_iu_WQqvKDl{ 
  display: none;
}
#el_OjVGKMBWBG{ 
  display: inline;
}
#el_VzX5ihUdFc{ 
  fill: #00FFDA;
}
#el_5O3BhGmGCY{ 
  fill: #00FFDA;
}
#el_E8hbrsI0JW{ 
  fill: #00FFDA;
}
#el_y7EgwBgS2O{ 
  fill: #8200FF;
}
#el_1FQcEcl_CB{ 
  display: none;
}
#el_JbuqEE4Wvz{ 
  display: inline;
}
#el_yLqZqBYqZK{ 
  fill: #8200FF;
}
#el_zaFRNRCS4yT{ 
  fill: #00FFDA;
}
#el_P7pZskq9FM_BHhscBjTM{ 
  -webkit-transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 0px);
  transform: translate(32.33px, 67.45px) translate(-32.33px, -67.45px) translate(0px, 0px);
}
.svgHover:hover #el_P7pZskq9FM_BHhscBjTM{ 
  -webkit-animation-name: el_P7pZskq9FM_BHhscBjTM_Animation;
  animation-name: el_P7pZskq9FM_BHhscBjTM_Animation;
}
</style>
