<template>
  <div class="home">
    <div class="sitemakers">
      
    </div>
  </div>
</template>

<script>
export default {
  name: 'Home',
  components: {}
}
</script>
