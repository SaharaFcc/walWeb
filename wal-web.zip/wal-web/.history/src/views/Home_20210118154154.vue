<template>
  <div class="home">
    <div class="fullPage" ref="fullPage">
      <div
        class="fullPageContainer"
        ref="fullPageContainer"
        @mousewheel="mouseWheelHandle"
        @DOMMouseScroll="mouseWheelHandle"
      >
        <div class="section section1">1</div>
        <div class="section section2">2</div>
        <div class="section section3">3</div>
        <div class="section section4">4</div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "Home",
  data(){
    return{
      fullpage: {
        current: 1,
        isScrolling: false,
        deltaY: 0
      }
    }
  },
  components: {},
  methods: {
    next(){
      let len = 4;
      if (this.fullpage.current + 1 <= len) {
        this.fullpage.current += 1;
        this.move(this.fullpage.current);
      }
    },
    pre(){
      if (this.fullpage.current - 1 > 0) {
        this.fullpage.current -= 1;
        this.move(this.fullpage.current);
      }
    },
    move(index){
      this.fullpage.isScrolling = true;
      this.directToMove(index);
      setTimeout(() => {
        this.fullpage.isScrolling = false;
      },1000)
    },
    directToMove(index){
      let height = this.$refs["fullPage"].clientHeight;
      let scrollPage = this.$refs["fullPageContainer"];
      let scrollHeight;
      scrollHeight= -(index - 1) * height + "px";
      scrollPage.style.transform = `translateY(${scrollHeight})`;
      this.fullpage.current = index;
    },
    mouseWheelHandle(event){
      let evt = event || window.event;
      if (evt.stopPropagation) {
        evt.stopPropagation();
      }else{
        evt.returnValue = false;
      }
      if (this.fullpage.isScrolling) {
        return false;
      }
      let e = event.originalEvent || event;
      this.fullpage.deltaY = e.deltaY || e.detail;
      if (this.fullpage.deltaY > 0) {
        this.next();
      }else if(this.fullpage.deltaY < 0){
        this.pre();
      }
    }
  }
};
</script>
