<template>
  <div class="home">
    <common-nav/>
    <full-page :options="options" ref="fullpage">
      <div class="section">
        page1
      </div>
      <div class="section">
        page2
      </div>
      <div class="section">
        page3
      </div>
    </full-page>
  </div>
</template>
<script>
import CommonNav from '@/components/common/CommonNav.vue';
export default {
  name: "Home",
  components:{
    CommonNav
  },
  data() {
    return {
      options: {
        licenseKey: "OPEN-SOURCE-GPLV3-LICENSE",
        afterLoad: this.afterLoad,
      },
    };
  },
  methods: {
    afterLoad(anchorLink ,index){
      console.log('anchorLink :',anchorLink ,',index:',index)
    },
    next() {
      // 向下滚动一页
      this.$refs.fullpage.api.moveSectionDown();
    },
  },
};
</script>
