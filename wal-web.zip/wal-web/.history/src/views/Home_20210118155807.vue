<template>
  <div class="home">
    <full-page :options="options" ref="fullpage">
      
    </full-page>
  </div>
</template>
<script>
export default {
  name: "Home",
  data() {
    return {};
  },
  components: {},
  methods: {},
};
</script>
<style lang="scss" scoped></style>
