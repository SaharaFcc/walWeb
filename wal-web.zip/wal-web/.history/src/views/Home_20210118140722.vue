<template>
  <div class="home">
    <svg-icon iconClass="bubble"/>
  </div>
</template>
<script>
export default {
  name: 'Home',
  components: {}
}
</script>
