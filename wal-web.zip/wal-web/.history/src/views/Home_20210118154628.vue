<template>
  <div class="home"></div>
</template>
<script>
export default {
  name: "Home",
  data() {
    return {};
  },
  components: {},
  methods: {},
};
</script>
<style lang="scss" scoped></style>
