<template>
  <div class="home">
    <full-page :options="options" ref="fullpage">
      <div class="section">
        page1
      </div>
      <div class="section">
        page2
      </div>
      <div class="section">
        page3
      </div>
    </full-page>
  </div>
</template>
<script>
export default {
  name: "Home",
  data() {
    return {
      options: {
        licenseKey: "OPEN-SOURCE-GPLV3-LICENSE",
        afterLoad: this.afterLoad
      },
    };
  },
  components: {},
  methods: {
    afterLoad(anchorLink ,index){
      console.log('anchorLink :',anchorLink ,',index:',index)
    },
    next() {
      // 向下滚动一页
      this.$refs.fullpage.api.moveSectionDown();
    },
  },
};
</script>
