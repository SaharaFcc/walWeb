<template>
  <div class="home">
    <div class="fullPage" ref="fullPage">
      <div class="fullPageContainer" ref="fullPageContainer"
      @mousewheel="mouseWheelHandle" 
      @DOMMouseScroll="mouseWheelHandle"  >
      <div class="section section1">1</div>
      <div class="section section2">2</div>
      <div class="section section3">3</div>
      <div class="section section4">4</div>
    </div>
  </div>
</template>
<script>
export default {
  name: "Home",
  components: {},
};
</script>
