<template>
  <div class="home">
    <svg-icon iconClass="fullscreen" className="fullscreen_icon"/>
  </div>
</template>
<script>
export default {
  name: 'Home',
  components: {}
}
</script>
