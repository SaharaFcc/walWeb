<template>
  <div class="home">
    <div class="sitemakers">
      <div class="wrap">
        <img src="@/assets/images/svgIcon/bubble.svg" alt="">
        <div class="light">
          <span class="glow"></span>
          <span class="flare"></span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Home',
  components: {}
}
</script>
