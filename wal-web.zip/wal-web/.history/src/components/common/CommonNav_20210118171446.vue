<template>
  <div class="commonNav"></div>
</template>

<script>
export default {
    name: 'CommonNav'
}
</script>

<style>

</style>