<template>
  <div class="commonNav">
    <div id="nav" class="nav" :class="{ 'fix-nav': navBarFixed }"></div>
  </div>
</template>

<script>
export default {
  name: "CommonNav",
  props:{
    navList:{
      type: Array
    }
  },
  data() {
    return {
      navBarFixed: false,
    };
  },
  mounted() {
    window.addEventListener("scroll", this.watchScroll);
  },
  methods: {
    watchScroll() {
      // 滚动的距离
      var scrollTop =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop;

      // 容器的高度
      var offsetTop = document.querySelector("#nav").offsetHeight;

      console.log("scrollTop=>", scrollTop, "  offsetTop=>", offsetTop);

      //  滚动的距离如果大于了元素到顶部的距离时，实现吸顶效果
      if (scrollTop > offsetTop) {
        this.navBarFixed = true;
      } else {
        this.navBarFixed = false;
      }
    },
  },
  destroyed() {
    window.removeEventListener("scroll", this.watchScroll);
  },
};
</script>
<style lang="scss" scoped>
.commonNav {
  .nav {
    width: 100%;
    height: 55px;
  }
  .fix-nav {
    position: fixed;
    top: 0;
    z-index: 999;
  }
}
</style>