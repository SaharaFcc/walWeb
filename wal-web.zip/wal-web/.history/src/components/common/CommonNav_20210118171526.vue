<template>
  <div class="commonNav" id="boxFixed" :class="{ is_fixed: isFixed }">
    <section class="header-box">
      <nav>
        <a>关于</a>
        <a>产品功能</a>
        <a>APP下载</a>
        <a>免费注册使用</a>
      </nav>
    </section>
  </div>
</template>

<script>
export default {
  name: "CommonNav",
};
</script>