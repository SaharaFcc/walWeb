<template>
  <div class="commonNav" id="boxFixed" :class="{'is_fixed' : isFixed}">

  </div>
</template>

<script>
export default {
    name: 'CommonNav'
}
</script>