<template>
  <div class="commonNav">
    <div id="nav" class="nav" :class="{ 'fix-nav': navBarFixed }">
      <div class="container">
        <div
          @click="anchor(nav.id,index)"
          class="position-relative cursor-btn"
          :class="anchorIndex === index ? 'active' : ''"
          v-for="(nav, index) in navList"
          :key="index"
        >
          {{}}
          {{ nav.name }}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "CommonNav",
  props: {
    navList: {
      type: Array,
    },
  },
  data() {
    return {
      navBarFixed: false,
      anchorIndex: -1
    };
  },
  mounted() {
    window.addEventListener("scroll", this.watchScroll);
  },
  methods: {
    //锚点链接
    anchor(anchorId,index){
      let anchorElement = document.getElementById(anchorId);
      this.anchorIndex = index
      if(anchorElement){
        anchorElement.scrollIntoView();
      }
    },
    watchScroll() {
      // 滚动的距离
      var scrollTop =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop;

      // 容器的高度
      var offsetTop = document.querySelector("#nav").offsetHeight;

      console.log("scrollTop=>", scrollTop, "  offsetTop=>", offsetTop);

      //  滚动的距离如果大于了元素到顶部的距离时，实现吸顶效果
      if (scrollTop > offsetTop) {
        this.navBarFixed = true;
      } else {
        this.navBarFixed = false;
      }
    },
  },
  destroyed() {
    window.removeEventListener("scroll", this.watchScroll);
  },
};
</script>
<style lang="scss" scoped>
.commonNav {
  .nav {
    width: 100%;
    height: 55px;
  }
  .fix-nav {
    position: fixed;
    top: 0;
    z-index: 999;
  }
  .container {
    max-width: 1140px;
    padding: 0px;
    display: flex;
    line-height: 55px;
    font-size: 16px;
    color: #333;
    & > div {
      text-align: center;
      width: 228px;
      height: 100%;
      background: #e6e6e6;
      &:not(:first-of-type) {
        &::before {
          content: "";
          display: block;
          border-left: 1px solid #fff;
          height: 100%;
          position: absolute;
          left: 0;
          top: 0;
          width: 1px;
        }
      }
      &::after {
        content: "";
        width: 0%;
        position: absolute;
        bottom: 0;
        left: 0;
        height: 3px;
        background: #8200ff;
        transition: 0.3s;
      }
      &:hover,
      &.active {
        background: #fff;
        color: #8200ff;
        &::after {
          width: 100%;
        }
      }
    }
  }
}
</style>