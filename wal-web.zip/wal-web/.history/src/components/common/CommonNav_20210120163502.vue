<template>
  <div class="commonNav">
    <div id="nav" class="nav" :class="{ 'fix-nav': navBarFixed }">
      <div class="mailto" v-if="pageType === 1">
        <div class="container d-flex justify-content-between">
          <template v-if="pageName === 'appDownload'">
            <div class="mailto-content d-flex">
              <div>
                <img src="@/assets/images/appDownload/email.png" alt="" />
              </div>
              <div>
                <div>Feedback</div>
                <div>
                  <a href="mailto:wallet@waltonchain.org"
                    >wallet@waltonchain.org</a
                  >
                </div>
              </div>
            </div>
          </template>
          <template
            v-if="
              pageName === 'traceSystem' ||
              pageName === 'traceCloud' ||
              pageName === 'traceWarrant' ||
              pageName === 'traceAgriculture' ||
              pageName === 'traceCloth'
            "
          >
            <div class="mailto-tip">
              To know about our solutions for your industry
            </div>
            <div class="mailto-content d-flex">
              <div>
                <img src="@/assets/images/appDownload/email.png" alt="" />
              </div>
              <div>
                <div>Contact Us</div>
                <div>
                  <a href="mailto:business@waltonchain.org"
                    >business@waltonchain.org</a
                  >
                </div>
              </div>
            </div>
          </template>
          <template v-if="pageName === 'ecoSmn'">
            <div class="mailto-tip">
              This program is valid from July 14, 2018 till December 31, 2018
              (UTC+8).
            </div>
            <div class="mailto-content font-weight-bold mailto-ecoSmn-content">
              <a
                href="http://www.waltonchain.org/en/Uploads/2018-12-28/5c25d8ace868f.docx"
                >Download Application Form</a
              >
            </div>
          </template>
        </div>
      </div>
      <div class="container position-relative">
        <div
          @click="anchor(nav.id, index)"
          class="position-relative cursor-btn"
          :class="anchorIndex === index ? 'active' : ''"
          v-for="(nav, index) in navList"
          :key="index"
        >
          {{ nav.name }}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "CommonNav",
  props: {
    navList: {
      type: Array,
    },
    pageType: {
      type: Number,
    },
    pageName: {
      type: String,
    },
  },
  data() {
    return {
      navBarFixed: false,
      anchorIndex: -1,
    };
  },
  mounted() {
    window.addEventListener("scroll", this.watchScroll);
  },
  methods: {
    //锚点链接
    anchor(anchorId, index) {
      let anchorElement = document.getElementById(anchorId);
      this.anchorIndex = index;
      if (anchorElement) {
        anchorElement.scrollIntoView({
          behavior: "smooth",
        });
      }
    },
    watchScroll() {
      // 滚动的距离
      var scrollTop =
        window.pageYOffset ||
        document.documentElement.scrollTop ||
        document.body.scrollTop;

      // 容器的高度
      var offsetTop = document.querySelector("#nav").offsetHeight;

      console.log("scrollTop=>", scrollTop, "  offsetTop=>", offsetTop);

      //  滚动的距离如果大于了元素到顶部的距离时，实现吸顶效果
      if (scrollTop > offsetTop) {
        this.navBarFixed = true;
      } else {
        this.navBarFixed = false;
      }
    },
  },
  destroyed() {
    window.removeEventListener("scroll", this.watchScroll);
  },
};
</script>
<style lang="scss" scoped>
.commonNav {
  .nav {
    width: 100%;
  }
  .fix-nav {
    position: fixed;
    top: 0;
    z-index: 999;
  }
  .mailto {
    width: 100%;
    margin: 35px 0px;
    .container {
      padding: 0px;
      & > div {
        height: 44px;
      }
      .mailto-tip {
        line-height: 44px;
        font-size: 18px;
        color: #555;
      }
      .mailto-content {
        & > div {
          &:last-of-type {
            margin-left: 8px;
            & > div {
              &:first-of-type {
                font-size: 14px;
                height: 14px;
                line-height: 14px;
              }
            }
          }
        }
        a {
          text-decoration: none;
          color: #8200ff;
          font-size: 20px;
        }
        &.mailto-ecoSmn-content {
          line-height: 44px;
          font-size: 14px;
          color: #8200ff;
          border: 2px solid #8200ff;
          padding: 0px 30px;
          border-radius: 30px;
        }
      }
    }
  }
  .container.position-relative {
    max-width: 1140px;
    padding: 0px;
    display: flex;
    font-size: 16px;
    color: #333;
    & > div {
      text-align: center;
      background: #e6e6e6;
      &:not(:first-of-type) {
        &::before {
          content: "";
          display: block;
          border-left: 1px solid #fff;
          height: 100%;
          position: absolute;
          left: 0;
          top: 0;
          width: 1px;
        }
      }
      &::after {
        content: "";
        width: 0%;
        position: absolute;
        bottom: 0;
        left: 0;
        height: 3px;
        background: #8200ff;
        transition: 0.3s;
      }
      &:hover,
      &.active {
        background: #fff;
        color: #8200ff;
        &::after {
          width: 100%;
        }
      }
    }
  }
}
</style>