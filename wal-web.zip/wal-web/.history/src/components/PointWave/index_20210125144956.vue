<template>
  <div class="pointWave"></div>
</template>

<script>
import * as THREE from "three";
export default {
  name: "PointWave",
  props: {
    amountX: {
      type: Number,
      default: 50,
    },
    amountY: {
      type: Number,
      default: 50,
    },
    color: {
      type: Number,
      default: 0xffffff,
    },
    top: {
      type: Number,
      default: 350,
    },
  },
  data() {
    return {
        
    };
  },
};
</script>
<style lang="scss" scoped>
.pointWave {
}
</style>