<template>
  <div class="pointWave">
    
  </div>
</template>

<script>
export default {
    name: 'PointWave'
}
</script>
<style lang="scss" scoped>
.pointWave{
    
}
</style>