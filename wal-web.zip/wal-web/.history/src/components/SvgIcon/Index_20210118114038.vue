<template>
  <svg :class="svgClass" aria-hidden="true" v-on="$listeners">
    <use :xlink:href="iconName" />
  </svg>
</template>
<script>
export default {
    name: 'SvgIcon',
    props:{
        
    },
    data(){
        return{

        }
    },
    computed:{

    }
}
</script>